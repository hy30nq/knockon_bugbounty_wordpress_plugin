jQuery( document ).ready(
	function ($) {
		$( '.color_picker' ).wpColorPicker();
	}
);
