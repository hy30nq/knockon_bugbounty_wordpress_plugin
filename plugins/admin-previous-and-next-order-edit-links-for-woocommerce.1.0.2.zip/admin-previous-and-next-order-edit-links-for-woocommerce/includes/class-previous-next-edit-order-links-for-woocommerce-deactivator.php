<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://github.com/CylasKiganda/previous-next-edit-order-links-for-woocommerce
 * @since      1.0.1
 *
 * @package    Previous_Next_Edit_Order_Links_For_Woocommerce
 * @subpackage Previous_Next_Edit_Order_Links_For_Woocommerce/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.1
 * @package    Previous_Next_Edit_Order_Links_For_Woocommerce
 * @subpackage Previous_Next_Edit_Order_Links_For_Woocommerce/includes
 * @author     Belo <belocodes@gmail.com>
 */
class Previous_Next_Edit_Order_Links_For_Woocommerce_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.1
	 */
	public static function deactivate() {

	}

}
