<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://github.com/CylasKiganda/previous-next-edit-order-links-for-woocommerce
 * @since      1.0.1
 *
 * @package    Previous_Next_Edit_Order_Links_For_Woocommerce
 * @subpackage Previous_Next_Edit_Order_Links_For_Woocommerce/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
