=== What Template ===
Contributors: ironprogrammer
Tags: template, admin bar, development, debug
Requires at least: 3.1
Tested up to: 6.6
Stable tag: 0.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds the current page's template name to the admin bar.


== Description ==

Adds the current page's template name to the admin bar.

Because this plugin reveals potentially sensitive information about the active theme, it is recommended for development environments only, and should not be enabled on a production site.


== Installation ==

Use the automatic installer on the 'Plugins' page, or upload the unzipped plugin directory to your `/wp-content/plugins/` directory and activate it.


== ChangeLog ==

= 0.1 =

* initial plugin version
