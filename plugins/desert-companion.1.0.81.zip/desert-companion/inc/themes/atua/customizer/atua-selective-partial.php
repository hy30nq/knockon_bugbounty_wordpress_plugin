<?php
// atua_hdr_left_text
function atua_hdr_left_text_render_callback() {
	return get_theme_mod( 'atua_hdr_left_text' );
}

// atua_hdr_social_title
function atua_hdr_social_title_render_callback() {
	return get_theme_mod( 'atua_hdr_social_title' );
}

// atua_hdr_email_title
function atua_hdr_email_title_render_callback() {
	return get_theme_mod( 'atua_hdr_email_title' );
}


// atua_hdr_email_subtitle
function atua_hdr_email_subtitle_render_callback() {
	return get_theme_mod( 'atua_hdr_email_subtitle' );
}

// atua_hdr_top_mbl_title
function atua_hdr_top_mbl_title_render_callback() {
	return get_theme_mod( 'atua_hdr_top_mbl_title' );
}

// atua_hdr_top_mbl_subtitle
function atua_hdr_top_mbl_subtitle_render_callback() {
	return get_theme_mod( 'atua_hdr_top_mbl_subtitle' );
}

// atua_about_right_ttl
function atua_about_right_ttl_render_callback() {
	return get_theme_mod( 'atua_about_right_ttl' );
}

// atua_about_right_subttl
function atua_about_right_subttl_render_callback() {
	return get_theme_mod( 'atua_about_right_subttl' );
}

// atua_about_right_text
function atua_about_right_text_render_callback() {
	return get_theme_mod( 'atua_about_right_text' );
}

// atua_service_ttl
function atua_service_ttl_render_callback() {
	return get_theme_mod( 'atua_service_ttl' );
}

// atua_service_subttl
function atua_service_subttl_render_callback() {
	return get_theme_mod( 'atua_service_subttl' );
}

// atua_service_text
function atua_service_text_render_callback() {
	return get_theme_mod( 'atua_service_text' );
}

// atua_features_ttl
function atua_features_ttl_render_callback() {
	return get_theme_mod( 'atua_features_ttl' );
}

// atua_features_subttl
function atua_features_subttl_render_callback() {
	return get_theme_mod( 'atua_features_subttl' );
}

// atua_features_text
function atua_features_text_render_callback() {
	return get_theme_mod( 'atua_features_text' );
}

// atua_features_btn_lbl
function atua_features_btn_lbl_render_callback() {
	return get_theme_mod( 'atua_features_btn_lbl' );
}

// atua_blog_ttl
function atua_blog_ttl_render_callback() {
	return get_theme_mod( 'atua_blog_ttl' );
}

// atua_blog_subttl
function atua_blog_subttl_render_callback() {
	return get_theme_mod( 'atua_blog_subttl' );
}

// atua_blog_text
function atua_blog_text_render_callback() {
	return get_theme_mod( 'atua_blog_text' );
}