<?php
// corpiva_service_ttl
function corpiva_service_ttl_render_callback() {
	return get_theme_mod( 'corpiva_service_ttl' );
}

// corpiva_service_subttl
function corpiva_service_subttl_render_callback() {
	return get_theme_mod( 'corpiva_service_subttl' );
}

// corpiva_service_btn_lbl
function corpiva_service_btn_lbl_render_callback() {
	return get_theme_mod( 'corpiva_service_btn_lbl' );
}

// corpiva_overview_right_ttl
function corpiva_overview_right_ttl_render_callback() {
	return get_theme_mod( 'corpiva_overview_right_ttl' );
}

// corpiva_overview_right_subttl
function corpiva_overview_right_subttl_render_callback() {
	return get_theme_mod( 'corpiva_overview_right_subttl' );
}

// corpiva_overview_right_text
function corpiva_overview_right_text_render_callback() {
	return get_theme_mod( 'corpiva_overview_right_text' );
}

// corpiva_features_ttl
function corpiva_features_ttl_render_callback() {
	return get_theme_mod( 'corpiva_features_ttl' );
}

// corpiva_features_text
function corpiva_features_text_render_callback() {
	return get_theme_mod( 'corpiva_features_text' );
}

// corpiva_features_btn_lbl
function corpiva_features_btn_lbl_render_callback() {
	return get_theme_mod( 'corpiva_features_btn_lbl' );
}

// corpiva_blog_ttl
function corpiva_blog_ttl_render_callback() {
	return get_theme_mod( 'corpiva_blog_ttl' );
}

// corpiva_blog_subttl
function corpiva_blog_subttl_render_callback() {
	return get_theme_mod( 'corpiva_blog_subttl' );
}

// corpiva_blog_text
function corpiva_blog_text_render_callback() {
	return get_theme_mod( 'corpiva_blog_text' );
}