<?php
// softme_hdr_left_ttl
function softme_hdr_left_ttl_render_callback() {
	return get_theme_mod( 'softme_hdr_left_ttl' );
}

// softme_hdr_left_text
function softme_hdr_left_text_render_callback() {
	return get_theme_mod( 'softme_hdr_left_text' );
}

// softme_hdr_email_title
function softme_hdr_email_title_render_callback() {
	return get_theme_mod( 'softme_hdr_email_title' );
}

// softme_hdr_top_ads_title
function softme_hdr_top_ads_title_render_callback() {
	return get_theme_mod( 'softme_hdr_top_ads_title' );
}

// softme_about_right_ttl
function softme_about_right_ttl_render_callback() {
	return get_theme_mod( 'softme_about_right_ttl' );
}

// softme_about_right_subttl
function softme_about_right_subttl_render_callback() {
	return get_theme_mod( 'softme_about_right_subttl' );
}

// softme_about_right_text
function softme_about_right_text_render_callback() {
	return get_theme_mod( 'softme_about_right_text' );
}

// softme_about_marque_text
function softme_about_marque_text_render_callback() {
	return get_theme_mod( 'softme_about_marque_text' );
}

// softme_service_ttl
function softme_service_ttl_render_callback() {
	return get_theme_mod( 'softme_service_ttl' );
}

// softme_service_subttl
function softme_service_subttl_render_callback() {
	return get_theme_mod( 'softme_service_subttl' );
}

// softme_service_text
function softme_service_text_render_callback() {
	return get_theme_mod( 'softme_service_text' );
}

// softme_features_ttl
function softme_features_ttl_render_callback() {
	return get_theme_mod( 'softme_features_ttl' );
}

// softme_features_subttl
function softme_features_subttl_render_callback() {
	return get_theme_mod( 'softme_features_subttl' );
}

// softme_features_text
function softme_features_text_render_callback() {
	return get_theme_mod( 'softme_features_text' );
}

// softme_blog_ttl
function softme_blog_ttl_render_callback() {
	return get_theme_mod( 'softme_blog_ttl' );
}

// softme_blog_subttl
function softme_blog_subttl_render_callback() {
	return get_theme_mod( 'softme_blog_subttl' );
}

// softme_blog_text
function softme_blog_text_render_callback() {
	return get_theme_mod( 'softme_blog_text' );
}

// softme_protect_right_ttl
function softme_protect_right_ttl_render_callback() {
	return get_theme_mod( 'softme_protect_right_ttl' );
}

// softme_protect_right_subttl
function softme_protect_right_subttl_render_callback() {
	return get_theme_mod( 'softme_protect_right_subttl' );
}

// softme_protect_right_text
function softme_protect_right_text_render_callback() {
	return get_theme_mod( 'softme_protect_right_text' );
}