<?php
// cosmobit_service_ttl
function cosmobit_service_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_service_ttl' );
}

// cosmobit_service_subttl
function cosmobit_service_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_service_subttl' );
}

// cosmobit_service_text
function cosmobit_service_text_render_callback() {
	return get_theme_mod( 'cosmobit_service_text' );
}

// cosmobit_cta2_text
function cosmobit_cta2_text_render_callback() {
	return get_theme_mod( 'cosmobit_cta2_text' );
}

// cosmobit_cta2_btn_lbl
function cosmobit_cta2_btn_lbl_render_callback() {
	return get_theme_mod( 'cosmobit_cta2_btn_lbl' );
}


// cosmobit_why_choose_left_ttl
function cosmobit_why_choose_left_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_left_ttl' );
}

// cosmobit_why_choose_left_subttl
function cosmobit_why_choose_left_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_left_subttl' );
}

// cosmobit_why_choose_left_text
function cosmobit_why_choose_left_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_left_text' );
}

// cosmobit_why_left_f_ttl
function cosmobit_why_left_f_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_left_f_ttl' );
}

// cosmobit_why_left_f_text
function cosmobit_why_left_f_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_left_f_text' );
}


// cosmobit_why_choose_right_ttl
function cosmobit_why_choose_right_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_right_ttl' );
}

// cosmobit_why_choose_right_subttl
function cosmobit_why_choose_right_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_right_subttl' );
}

// cosmobit_why_choose_right_text
function cosmobit_why_choose_right_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_right_text' );
}

// cosmobit_why_choose_right_f_text
function cosmobit_why_choose_right_f_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_right_f_text' );
}

// cosmobit_why_choose_right_f_btn_lbl
function cosmobit_why_choose_right_f_btn_lbl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose_right_f_btn_lbl' );
}

// cosmobit_blog_ttl
function cosmobit_blog_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog_ttl' );
}

// cosmobit_blog_subttl
function cosmobit_blog_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog_subttl' );
}

// cosmobit_blog_text
function cosmobit_blog_text_render_callback() {
	return get_theme_mod( 'cosmobit_blog_text' );
}

// cosmobit_service2_ttl
function cosmobit_service2_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_service2_ttl' );
}

// cosmobit_service2_subttl
function cosmobit_service2_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_service2_subttl' );
}

// cosmobit_service2_text
function cosmobit_service2_text_render_callback() {
	return get_theme_mod( 'cosmobit_service2_text' );
}

// cosmobit_cta3_text
function cosmobit_cta3_text_render_callback() {
	return get_theme_mod( 'cosmobit_cta3_text' );
}

// cosmobit_cta3_btn_lbl
function cosmobit_cta3_btn_lbl_render_callback() {
	return get_theme_mod( 'cosmobit_cta3_btn_lbl' );
}

// cosmobit_blog2_ttl
function cosmobit_blog2_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog2_ttl' );
}

// cosmobit_blog2_subttl
function cosmobit_blog2_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog2_subttl' );
}

// cosmobit_blog2_text
function cosmobit_blog2_text_render_callback() {
	return get_theme_mod( 'cosmobit_blog2_text' );
}


// cosmobit_why_choose4_left_ttl
function cosmobit_why_choose4_left_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_left_ttl' );
}

// cosmobit_why_choose4_left_subttl
function cosmobit_why_choose4_left_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_left_subttl' );
}

// cosmobit_why_choose4_left_text
function cosmobit_why_choose4_left_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_left_text' );
}

// cosmobit_why4_left_f_ttl
function cosmobit_why4_left_f_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why4_left_f_ttl' );
}

// cosmobit_why4_left_f_text
function cosmobit_why4_left_f_text_render_callback() {
	return get_theme_mod( 'cosmobit_why4_left_f_text' );
}


// cosmobit_why_choose4_right_ttl
function cosmobit_why_choose4_right_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_right_ttl' );
}

// cosmobit_why_choose4_right_subttl
function cosmobit_why_choose4_right_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_right_subttl' );
}

// cosmobit_why_choose4_right_text
function cosmobit_why_choose4_right_text_render_callback() {
	return get_theme_mod( 'cosmobit_why_choose4_right_text' );
}

// cosmobit_blog4_ttl
function cosmobit_blog4_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog4_ttl' );
}

// cosmobit_blog4_subttl
function cosmobit_blog4_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog4_subttl' );
}

// cosmobit_blog4_text
function cosmobit_blog4_text_render_callback() {
	return get_theme_mod( 'cosmobit_blog4_text' );
}


// cosmobit_service4_ttl
function cosmobit_service4_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_service4_ttl' );
}

// cosmobit_service4_subttl
function cosmobit_service4_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_service4_subttl' );
}

// cosmobit_service4_text
function cosmobit_service4_text_render_callback() {
	return get_theme_mod( 'cosmobit_service4_text' );
}

// cosmobit_information3_ttl
function cosmobit_information3_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_information3_ttl' );
}

// cosmobit_information3_subttl
function cosmobit_information3_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_information3_subttl' );
}

// cosmobit_information3_text
function cosmobit_information3_text_render_callback() {
	return get_theme_mod( 'cosmobit_information3_text' );
}

// cosmobit_service3_ttl
function cosmobit_service3_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_service3_ttl' );
}

// cosmobit_service3_subttl
function cosmobit_service3_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_service3_subttl' );
}

// cosmobit_service3_text
function cosmobit_service3_text_render_callback() {
	return get_theme_mod( 'cosmobit_service3_text' );
}

// cosmobit_blog3_ttl
function cosmobit_blog3_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog3_ttl' );
}

// cosmobit_blog3_subttl
function cosmobit_blog3_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog3_subttl' );
}

// cosmobit_blog3_text
function cosmobit_blog3_text_render_callback() {
	return get_theme_mod( 'cosmobit_blog3_text' );
}

// cosmobit_service5_ttl
function cosmobit_service5_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_service5_ttl' );
}

// cosmobit_service5_subttl
function cosmobit_service5_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_service5_subttl' );
}

// cosmobit_service5_text
function cosmobit_service5_text_render_callback() {
	return get_theme_mod( 'cosmobit_service5_text' );
}

// cosmobit_blog5_ttl
function cosmobit_blog5_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog5_ttl' );
}

// cosmobit_blog5_subttl
function cosmobit_blog5_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_blog5_subttl' );
}

// cosmobit_blog5_text
function cosmobit_blog5_text_render_callback() {
	return get_theme_mod( 'cosmobit_blog5_text' );
}

// cosmobit_cta5_text
function cosmobit_cta5_text_render_callback() {
	return get_theme_mod( 'cosmobit_cta5_text' );
}

// cosmobit_cta5_btn_lbl
function cosmobit_cta5_btn_lbl_render_callback() {
	return get_theme_mod( 'cosmobit_cta5_btn_lbl' );
}

// cosmobit_funfact6_right_ttl
function cosmobit_funfact6_right_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_funfact6_right_ttl' );
}

// cosmobit_funfact6_right_subttl
function cosmobit_funfact6_right_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_funfact6_right_subttl' );
}

// cosmobit_about5_right_ttl
function cosmobit_about5_right_ttl_render_callback() {
	return get_theme_mod( 'cosmobit_about5_right_ttl' );
}

// cosmobit_about5_right_subttl
function cosmobit_about5_right_subttl_render_callback() {
	return get_theme_mod( 'cosmobit_about5_right_subttl' );
}

// cosmobit_about5_right_text
function cosmobit_about5_right_text_render_callback() {
	return get_theme_mod( 'cosmobit_about5_right_text' );
}