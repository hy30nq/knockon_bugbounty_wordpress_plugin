<?php

// pretty_log('upgrader 1.0.2.3', 'is running.............');
// pretty_log('JLT_ADMIN_BAR_EDITOR_BASE', JLT_ADMIN_BAR_EDITOR_BASE);
// pretty_log('JLT_ADMIN_BAR_EDITOR_DIR', JLT_ADMIN_BAR_EDITOR_DIR);
