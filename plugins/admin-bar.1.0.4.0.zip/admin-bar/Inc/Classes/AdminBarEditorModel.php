<?php

namespace JewelTheme\AdminBarEditor\Inc\Classes;

use JewelTheme\AdminBarEditor\Inc\Base_Model;

abstract class AdminBarEditorModel extends Base_Model
{
    protected $prefix = '_jltadminbar_settings';
}
