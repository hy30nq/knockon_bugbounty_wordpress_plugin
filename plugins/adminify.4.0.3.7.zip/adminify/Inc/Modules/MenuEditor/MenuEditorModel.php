<?php

namespace WPAdminify\Inc\Modules\MenuEditor;

use WPAdminify\Inc\Base_Model;

abstract class MenuEditorModel extends Base_Model {

	protected $prefix = '_wpadminify_menu_settings';
}
