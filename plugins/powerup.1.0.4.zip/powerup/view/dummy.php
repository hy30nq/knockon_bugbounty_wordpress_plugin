<?php

// This empty file is required for Disable_Comments module