<?php
/*
Plugin Name: Empty Tags Remover
Plugin URI: https://wordpress.org/plugins/empty-tags-remover/
Description: Removes the empty tags, tags with no posts attached.
Version: 1.2.3
Author: Ospitalier Timisoara
Author URI: https://ospitalier.ro/
License: GPLv2 or later
*/

add_action('admin_menu', 'add_empty_tags_page'); // adds the options page

function add_empty_tags_page() {
    if (function_exists('add_posts_page')) {
        add_posts_page('Remove empty tags', 'Remove empty tags', 'edit_posts', 'empty_tags', 'empty_tags_page');
    }
}

function empty_tags_page() { ?>

    <div class="wrap">
        <h2>Remove Empty Tags</h2>

        <?php
        if(empty($_POST['remove_my_empty_tags'])) {

            $tags = $tags = get_terms( array(
                'taxonomy'   => 'post_tag',
                'hide_empty' => false,
            ) );

            $count_tags = count($tags);
            if ($count_tags) {
                echo '<strong>The following tags are empty:</strong><br />';
                echo '<ul>';
                foreach ($tags as $tag) {
                    if ($tag->count == 0) {
                        echo "<li><a href='edit-tags.php?action=edit&amp;taxonomy=post_tag&amp;tag_ID=" . esc_url($tag->term_id) . "'>" . esc_html($tag->name) . "</a></li>\n";
                    }
                }
                echo '</ul>';
            } else {
                echo '<p>No empty tags found!</p>';
            }

            if ($count_tags) {
                ?>
                <form method="post">
                    <label for="remove_my_empty_tags">Do you want to remove now all the empty tags?</label>
                    <input type="submit" name="remove_my_empty_tags" value="Yes" />
                    <?php wp_nonce_field( 'remove_my_empty_tags' ); ?>
                </form>
                <?php
            }
        } else {
            $count_tags = 0;

            if (check_admin_referer( 'remove_my_empty_tags')) {
                $tags = get_terms( array(
                    'taxonomy'   => 'post_tag',
                    'hide_empty' => false,
                ) );
                echo '<ul>';
                foreach ($tags as $tag) {
                    if ($tag->count == 0) {
                        wp_delete_term($tag->term_id,'post_tag');
                        echo "<li>" . esc_html($tag->name) . " deleted</li>";
                        $count_tags++;
                    }
                }
                echo '</ul>';
            }

            echo sprintf("<strong>%s empty tags deleted</strong>", esc_html($count_tags)) ;
        }
        ?>
    </div><!-- //wrap -->
<?php } // function ?>