=== Empty Tags Remover ===
Contributors: de-ce
Tags: tags, remove, admin, edit, posts  
Requires at least: 2.5
Tested up to: 6.7.1
Stable tag: 1.2.3
License: GPLv2 or later

Really simple plugin. It just removes all your empty tags on demand.

== Description ==

Empty Tags Remover adds a page called 'Remove empty tags' under 'Posts' admin menu where you can simply remove all the empty tags with just one click.
