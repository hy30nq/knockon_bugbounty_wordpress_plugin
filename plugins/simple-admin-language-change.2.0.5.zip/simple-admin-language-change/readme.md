# Simple Admin Language Change

[![plugin repository](https://img.shields.io/wordpress/plugin/v/simple-admin-language-change.svg)](https://wordpress.org/plugins/simple-admin-language-change)
![build status](https://travis-ci.com/vyskoczilova/Simple-Admin-Language-Change.svg)

The lightweight plugin extends the default functionality and pulls out the language selection to the admin bar so you can easily switch between them.

![Plugin preview](.wordpress-org/screenshot-1.gif)
