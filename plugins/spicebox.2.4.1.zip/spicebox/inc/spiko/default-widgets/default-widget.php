<?php
/*$activate = array(
        'sidebar-1' => array(
            'search-1',
            'recent-posts-1',
            'archives-1',
        ),
        'footer-sidebar-1' => array(
            'text-1',
        ),
        'footer-sidebar-2' => array(
            'recent-posts-2',
        ),
        'footer-sidebar-3' => array(
            'categories-2'
        ),
        'footer-sidebar-4' => array(
            'search-2'
        ),
    );

  
    update_option('widget_text', array(
        1 => array('title' => '',
        'text'=>'<img src="'.esc_url(SPICEB_PLUGIN_URL).'/inc/spiko/images/logo-footer.png" alt="'.esc_attr("Logo","spicebox").'" />
        <br>
        <p></p>
        <p class="description custom">Lorem ipsum dolor sit amet, ut ius audiam denique tractatos.</p><address>
                                <p><i class="fa fa-phone"></i><a href="tel:+(15) 718-999-3939">+(15) 718-999-3939</a></p>
                                <p><i class="fa fa-envelope"></i><a href="mailto:support@metlux.com">support@spicethemes.com</a></p><p><i class="fa fa-map-marker"></i>152/02 William Streat, NYE</p>
                              </address>'), 
        ));
        
    update_option('widget_recent-posts', array(
        1 => array('title' => 'Recent Posts'), 
        2 => array('title' => 'Recent Posts')));

    update_option('widget_categories', array(
        1 => array('title' => 'Categories'), 
        2 => array('title' => 'Categories')));

    update_option('widget_archives', array(
        1 => array('title' => 'Archives'), 
        2 => array('title' => 'Archives')));
        
    update_option('widget_search', array(
        1 => array('title' => 'Search'), 
        2 => array('title' => 'Search')));

    update_option('sidebars_widgets',  $activate);*/
    
?>