jQuery(document).ready(function ($) {
	$("#wp-version-message").after("<p>The current PHP version is: <b style='color:#f30505;'>" + pvwObj.phpVersion + "</b></p>");
});