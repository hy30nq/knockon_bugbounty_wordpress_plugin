﻿=== PHP Version ===
Contributors: mazedulislam27
Tags: admin, server, support, PHP version, version,  dashboard, widget, displays, show, showing, PHP
Requires at least: 4.0
Tested up to: 6.7.1
Requires PHP: 5.6.0
Stable tag: 1.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

You can able to see the current PHP version in WordPress admin dashboard widget.

== Description ==

"PHP version" is very simple and lightweight plugin that will help you for showing up the current PHP version in WordPress dashboard.


 If you satisfied with this plugin, please <a href="https://wordpress.org/support/view/plugin-reviews/php-version"><strong>rate</strong></a> it. Your rate will encourage to do better in the future. 

== Installation ==

How to install the PHP Version Plugin?

1. Dashboard -> Plugins -> Add New.
2. Write "PHP Version" in the search box and hit enter.
3. Find out the PHP Version plugin from suggested all and click on Install Now .
4. Now click on Activate.
5. Go to your WordPress dashboard page and see the current PHP version is showing.

== Screenshots ==

1. banner-772x250.png
2. icon-256x256.png
3. icon-128x128.png
4. screenshot-1.png
5. screenshot-2.png

== Changelog ==
= 1.0.5  - 18 December, 2024 =

Compatible with Latest WordPress Version

= 1.0.4  - 16 September, 2024 =

Compatible with Latest WordPress Version

= 1.0.3  - 12 June, 2024 =

Compatible with Latest WordPress Version


= 1.0.2  - 18 October, 2023 =

Compatible with Latest WordPress Version


= 1.0.1  - 16 July, 2021 =

Compatible with latest WordPress Version


= 1.0.0  - 16 June, 2019 =

Initial Release

== Upgrade Notice ==

Nothing here