function cp_easyform_insertForm() {
    send_to_editor('[CP_EASY_FORM_WILL_APPEAR_HERE]');
}