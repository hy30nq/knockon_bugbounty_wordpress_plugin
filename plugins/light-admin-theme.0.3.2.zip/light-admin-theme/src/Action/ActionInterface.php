<?php

namespace LightAdminTheme\Action;

interface ActionInterface
{
    public function doAction();
}