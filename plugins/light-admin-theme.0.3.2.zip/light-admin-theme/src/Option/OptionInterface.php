<?php

namespace LightAdminTheme\Option;

interface OptionInterface
{
    public function render($args);
}