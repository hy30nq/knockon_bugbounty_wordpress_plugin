<?php

namespace LightAdminTheme\Field;

class Where
{
    const ADMIN = 1;
    const FRONT = 2;
    const LOGIN = 3;
}