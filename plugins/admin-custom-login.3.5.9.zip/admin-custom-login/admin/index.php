<?php
defined( 'ABSPATH' ) or die();
?>