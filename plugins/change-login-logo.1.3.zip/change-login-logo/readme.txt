=== Change WordPress Login Logo ===
Contributors: boopathi0001
Donate link: https://paypal.me/boopathirajan
Tags: WordPress Logo change, Login Logo, Custom logo, WP admin logo, Change default logo
Requires at least: 4.3
Tested up to: 6.6.1
Requires PHP: 5.2.4
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Upload your logo for WordPress login page instead of the usual WordPress logo with simple settings.

== Description ==

https://www.youtube.com/watch?v=Iu-XlWjyR9o

The Change WordPress Login Logo Plugin is a must-have for anyone looking to add a touch of personalization to their WordPress site. With this plugin, you can easily update your WordPress login page logo with your own customized logo in just a few clicks, without any coding knowledge required. Make your login page truly unique to your brand.

The plugin is incredibly user-friendly, allowing you to upload your logo quickly and easily via the WordPress customizer. It is also fully customizable, allowing you to adjust the logo's size, positioning, and other settings to perfectly match your site's design.

In addition to its ease of use, the Change WordPress Login Logo Plugin is also lightweight and fast-loading, ensuring that it won't slow down your site's performance. Plus, it's compatible with all the latest versions of WordPress, ensuring that you always have access to the latest features and security updates.

<a href="https://www.boopathirajan.com/product/change-wordpress-login-logo-pro/" rel="nofollow ugc" target="_blank">Purchase Premium Plugin</a>

<h4>Premium Features:</h4>

	1. Login Background Color Change
	2. Logn Form Background Color
	3. Form Label Text Color
	4. Login Page Link Color
	
== Installation ==

1. Log in to your WordPress admin panel and go to Plugins -> Add New
2. Type **Change WordPress Login Logo** in the search box and click on search button.
3. Find Change WordPress Login Logo plugin.
4. Then click on Install Now after that activate the plugin.

== Frequently Asked Questions ==

= How to configure Change WordPress Login Logo Plugin? =

1. Click "Settings" tab from left navigation menu:
2. Click "Login Logo" menu under the Settings menu
3. Upload new login logo using WP media uploader.
4. Click "Save Changes" button to save the configuration details.

