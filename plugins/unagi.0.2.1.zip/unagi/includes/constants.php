<?php
/**
 * Plugin constants
 *
 * @package Unagi
 */

namespace Unagi\Constants;

const USER_META_KEY = 'unagi_notices';
