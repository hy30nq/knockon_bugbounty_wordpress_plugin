<?php
/*
Plugin Name: Admin Dashboard RSS Feed
Description: This plugin will display company news in WordPress Admin Dashboard. It uses RSS feed URL as input and display the news synopsis in the Admin Dashboard.
Plugin URI: https://www.webstix.com
Author: Webstix
Version:     3.7
Text Domain: admin-dashboard-rss-feed
Author:      Webstix, Inc.
Author URI:  https://www.webstix.com/wordpress-plugin-development
Domain Path: /languages
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
*/
// Abort, if the plugin file is accessed from outside.

// header ("Content-Type:text/xml");

if (!defined('WPINC'))
{
	die;
}
/**
 * The code that runs during plugin activation.
 */
function wsx_rss_feed_plugin_activate()
{
	/* Create transient data */
	set_transient('wsx-rss-feed-admin-notice', true, 5);
}
/**
 * Admin Notice on Activation.
 */
add_action('admin_notices', 'wsx_rss_feed_active_admin_notice');
function wsx_rss_feed_active_admin_notice()
{
	/* Check transient, if available display notice */
	if (get_transient('wsx-rss-feed-admin-notice'))
	{
?>
        <div class="updated notice is-dismissible">
        <?php
		echo '<p>';
		esc_html_e('Thank you for using the <strong>Admin Rss Feed</strong> plugin! Go to Plugin ', 'admin-dashboard-rss-feed');
		echo '<a href="' . esc_url(get_admin_url(null, 'options-general.php?page=wsx-rss-feed-settings')) . '">' . esc_html_e('Settings Page', 'admin-dashboard-rss-feed') . '</a>';
		echo '</p>';
?>
        </div>
        <?php
		/* Delete transient, only display this notice once. */
		delete_transient('wsx-rss-feed-admin-notice');
	}
}
register_activation_hook(__FILE__, "wsx_rss_feed_plugin_activate");
function wsx_rss_feed_plugin_deactivate()
{
}
register_deactivation_hook(__FILE__, "wsx_rss_feed_plugin_deactivate");
// Settings link on the plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__) , 'wsx_rss_feed_plugin_settings_link');
function wsx_rss_feed_plugin_settings_link($wsx_rss_feed_link)
{
	$wsx_rss_feed_link[] = '<a href="' . esc_url(get_admin_url(null, 'options-general.php?page=wsx-rss-feed-settings')) . '">' . __('Settings', 'admin-dashboard-rss-feed') . '</a>';
	return $wsx_rss_feed_link;
}
// Create custom plugin settings menu
add_action('admin_menu', 'wsx_rss_feed_admin_page');
function wsx_rss_feed_admin_page()
{
	// create new top-level menu
	add_options_page('Admin Dashboard RSS Feed Plugin Settings', 'Admin Dashboard RSS Feed', 'manage_options', 'wsx-rss-feed-settings', 'wsx_rss_feed_admin_settings_page');
	// call register settings function
	add_action('admin_init', 'wsx_rss_feed_admin_settings');
}
function wsx_rss_feed_styles()
{
	wp_register_style('wsx-rss-styles',	plugin_dir_url(__FILE__) . 'admin/css/style.css', array(), 	'3.5');
	wp_enqueue_style('wsx-rss-styles');

	// Enqueue WordPress media uploader
	wp_enqueue_media(); 

	// Load script only on the desired admin page
	wp_enqueue_script(
		'custom-admin-js', 
		plugin_dir_url(__FILE__) . 'admin/js/admin.js', // Adjust path if using a plugin
		array('jquery'), // jQuery dependency
		'3.5', 
		true // Load in footer
	);

	// Pass PHP variables to JavaScript
	wp_localize_script('custom-admin-js', 'rssFeedVars', array(
		'attachment_id' => get_option('wsx_rss_feed_image_attachment_id', 0)
	));

	
}
add_action('admin_enqueue_scripts', 'wsx_rss_feed_styles');
function wsx_rss_feed_admin_settings()
{
    // Check if the request is a POST request
	if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {

		// Validate nonce correctly using $_REQUEST instead of $_POST
		if (!isset($_REQUEST['_wpnonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'wsx_rss_feed_nonce_action')) {			
			wp_die(esc_html__('Security check failed', 'admin-dashboard-rss-feed'));
		}
	
		// Sanitize and save the attachment ID
		if (isset($_POST['image_attachment_id'])) {
			update_option('wsx_rss_feed_image_attachment_id', absint($_POST['image_attachment_id']));
		}
	}

    if (!empty($_GET['page']) && $_GET['page'] == "admin-dashboard-rss-feed/admin-rss-feed.php") {
        wp_enqueue_media();
    }

    // Register settings
    register_setting('wsx-rss-feed-settings-group', 'wsx_logo_title', 'sanitize_text_field');
    register_setting('wsx-rss-feed-settings-group', 'wsx_logo_target_link', 'esc_url_raw');
    register_setting('wsx-rss-feed-settings-group', 'wsx_rss_feed_url', 'esc_url_raw');
    register_setting('wsx-rss-feed-settings-group', 'wsx_rss_feed_count', 'absint');
}

//add_action('admin_init', 'wsx_rss_feed_admin_settings');


function wsx_rss_feed_admin_settings_page() { ?>
<div class="wrap">
<h2>Admin Dashboard RSS Feed Settings </h2>

<form method="post" action="options.php">

	<?php 
		settings_fields('wsx-rss-feed-settings-group'); 
		do_settings_sections('wsx-rss-feed-settings-group');
		wp_nonce_field('wsx_rss_feed_nonce_action', 'wsx_rss_feed_nonce'); 
    ?>
    <table class="form-table">

    	<tr valign="top">
			<th scope="row">Your Company Name:</th>
			<td><input type="text" name="wsx_logo_title" value="<?php
	echo esc_attr(get_option('wsx_logo_title')); ?>" style="width: 450px;" /></td>
        </tr>

		<tr valign="top">
			<th scope="row">Your Company Logo:</th>
			<td>
			<div class='image-preview-wrapper'>
			
			<?php echo wp_get_attachment_image(get_option('wsx_rss_feed_image_attachment_id'), 'thumbnail', false, array('id' => 'image-preview', 'class' =>'clsImagePreview', 'height' => '100')); ?>

		</div>
		<input id="upload_image_button" type="button" class="button" value="<?php esc_attr_e('Upload image', 'admin-dashboard-rss-feed'); ?>" />

	<input id="delete_image_button" type="button" class="button" value="<?php esc_attr_e('Delete image', 'admin-dashboard-rss-feed'); ?>" /><small class="wsx-small">(We suggest 64 pixels wide x 64 pixels high)</small>
		<input type='hidden' name='image_attachment_id' id='image_attachment_id' value='<?php echo esc_attr(get_option('wsx_rss_feed_image_attachment_id')); ?>'>

	</td>
        </tr>

		<tr valign="top">
			<th scope="row">Your Company Website:</th>
			<td><input type="text" name="wsx_logo_target_link" value="<?php
	echo esc_attr(get_option('wsx_logo_target_link')); ?>" style="width: 450px;" /></td>
        </tr>

        <tr valign="top">
			<th scope="row">Your Company RSS Feed URL:</th>
			<td><input class="wsx_rss_feed_url" type="url" name="wsx_rss_feed_url" value="<?php
	echo esc_attr(get_option('wsx_rss_feed_url')); ?>" style="width: 450px;" required /></td>
        </tr>

        <tr valign="top">
			<th scope="row">Number of items to display: <small style="font-weight: normal;">(You can show between 1 to 10)</small></th>
			<td><input type="number" name="wsx_rss_feed_count" value="<?php
	echo esc_attr(get_option('wsx_rss_feed_count')); ?>" required min="1" max="10" /></td>
        </tr>
    </table>
	<input name="wsx-rss-feed-form-submit" id="submit" class="button button-primary wsx-rss-feed-btn" value="Save Changes" type="submit">

</form>
</div>
<?php
}
// Initiate the admin page option here:
function admin_rss_feed_register_widgets()
{
	global $wp_meta_boxes;
	$wsx_company_name = esc_attr(get_option('wsx_logo_title'));
	// Translators: %s will be replaced with the company name.
	wp_add_dashboard_widget('widget_wsx_rss_feed', sprintf(esc_html__('%s News', 'admin-dashboard-rss-feed'), $wsx_company_name),
		'wsx_rss_feed_create_box'
	);
	
}
add_action('wp_dashboard_setup', 'admin_rss_feed_register_widgets');
// Show RSS Feeds on the WP Dashboard page
function wsx_rss_feed_create_box()
{
	// Get RSS Feed(s)
	include_once (ABSPATH . WPINC . '/feed.php');

	// Get the RSS feed URL
	$rss_feed_url = esc_attr(get_option('wsx_rss_feed_url'));
	if ($rss_feed_url <> "")
	{
		$rss_feed_url = esc_attr(get_option('wsx_rss_feed_url'));
	}
	else
	{
		echo "Enter a valid news feed URL.";
	}


	$wsx_logo_url = esc_url(wp_get_attachment_url(get_option('wsx_rss_feed_image_attachment_id')));
	$wsx_logo_title = esc_attr(get_option('wsx_logo_title'));
	$wsx_logo_target_link = esc_attr(get_option('wsx_logo_target_link'));
	$wsx_logo_id = get_option('wsx_rss_feed_image_attachment_id');

	echo '<div class="wsx-rss-feed-widget1">';

		if ($wsx_logo_url <> "" && $wsx_logo_target_link <> "" && $wsx_logo_title <> "")
		{
			$title = 'title="' . $wsx_logo_title . '"';
			$alt = 'alt="' . $wsx_logo_title . '"';
			
			echo "<div class='wsx-log-wrap clearfix'>";
			echo '<a ' . esc_attr($wsx_logo_title ? 'title="' . $wsx_logo_title . '"' : '') . ' href="' . esc_url($wsx_logo_target_link) . '" target="_blank">';
			echo '<img ' . esc_attr($wsx_logo_title ? 'alt="' . $wsx_logo_title . '"' : '') . ' src="' . esc_url($wsx_logo_url) . '">';
			echo '</a>';
			
			echo '<div class="wsx_company_name"><span class="wsx_comp_name">' . esc_attr($wsx_logo_title) . '</span>';
			echo '<a href="' . esc_url($wsx_logo_target_link) . '" target="_blank" title="' . esc_attr($wsx_logo_title) . '"><span class="wsx_company_url">' . esc_url($wsx_logo_target_link) . '</span></a></div></div>';
		}
		else if ($wsx_logo_url <> "" && $wsx_logo_target_link <> "")
		{
			//echo "<div class='wsx-log-wrap clearfix'><a href=" . esc_url($wsx_logo_target_link) . " target='_blank'><img src=" . esc_url($wsx_logo_url) . "></a>";

			if ($wsx_logo_id) {
				echo esc_html("<div class='wsx-log-wrap clearfix'>");
				echo '<a href="' . esc_url($wsx_logo_target_link) . '" target="_blank">';
				echo wp_get_attachment_image($wsx_logo_id, 'full', false, ['alt' => esc_attr__('Logo', 'admin-dashboard-rss-feed')]);
				echo '</a></div>';
			}

			echo '<a href="' . esc_url($wsx_logo_target_link) . '" target="_blank"><span class="wsx_company_url">' . esc_url($wsx_logo_target_link) . '</span></a></div>';
		}
		else if ($wsx_logo_url <> "" && $wsx_logo_title <> "")
		{
			$alt = 'alt="' . $wsx_logo_title . '"';
			echo "<div class='wsx-log-wrap clearfix'><img ".esc_attr($alt)." src=" . esc_url($wsx_logo_url) . ">";
			echo '<div class="wsx_company_name"><span class="wsx_comp_name">' . esc_attr($wsx_logo_title) . '</span></div>';
		}
		else if ($wsx_logo_title <> "" && $wsx_logo_target_link <> "")
		{
			echo '<div class="wsx-log-wrap clearfix"><div style="float: none;" class="wsx_company_name"><span class="wsx_comp_name">' . esc_attr($wsx_logo_title) . '</span></div><br />';
			echo '<a style="float: none;" href="' . esc_url($wsx_logo_target_link) . '" target="_blank" title="' . esc_attr($wsx_logo_title) . '"><span class="wsx_company_url">' . esc_url($wsx_logo_target_link) . '</span></a></div>';
		}
		else
		{
			if ($wsx_logo_url <> "")
			{
				echo "<div class='wsx-log-wrap clearfix'>";
				echo wp_get_attachment_image($wsx_logo_id, 'full', false, ['alt' => esc_attr__('Logo', 'admin-dashboard-rss-feed')]);
				echo "</div>";
			}
			if ($wsx_logo_title <> "")
			{
				echo '<div class="wsx-log-wrap clearfix"><div class="wsx_company_name"><span class="wsx_comp_name">' . esc_attr($wsx_logo_title) . '</span></div></div>';
			}
			if ($wsx_logo_target_link <> "")
			{
				echo "<div class='wsx-log-wrap clearfix'><a href=" . esc_url($wsx_logo_target_link) . " target='_blank'><span class='wsx_company_url'>" . esc_url($wsx_logo_target_link) . "</span></a></div>";
			}
		}

	echo '</div>';

	echo '<ul class="wsx-feed-list">';

	if($rss_feed_url !="http://feeds.feedburner.com/Webstix") {

		$xml = simplexml_load_file($rss_feed_url);

	    $in = 1;

	    $feed_count = esc_attr(get_option('wsx_rss_feed_count'));

	    foreach($xml->channel->item as $entry) {
	    	if($in <= $feed_count) {
	        	echo "<li><a href='".esc_url($entry->link)."' title='".esc_attr($entry->title)."'>" . esc_attr($entry->title) . "</a>";			
				
				echo '<p>' . esc_html(mb_substr(wp_strip_all_tags(html_entity_decode($entry->description, ENT_QUOTES, 'UTF-8')), 0, 120)) . '...</p></li>';

	        	$in++;
	        }

	    }

    } else {
    	$settings = '<a href="' . esc_url(get_admin_url(null, 'options-general.php?page=wsx-rss-feed-settings')) . '">Settings</a>';
		// Translators: %s will be replaced with the feed settings URL.
		echo '<li><strong>' . sprintf(esc_html__('Something went wrong! Please check the Feed URL %s and provide a valid RSS feed URL, then check back on this page.', 'admin-dashboard-rss-feed'),
			esc_url($settings)
		) . '</strong></li>';

    }

    echo '</ul>';

}

?>
