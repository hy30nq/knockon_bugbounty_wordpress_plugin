jQuery(document).ready(function($) {
  console.log("Admin script loaded successfully!");

  var set_to_post_id = rssFeedVars.attachment_id || 0;

  if (set_to_post_id == 0) {
      $('.image-preview-wrapper, .image-preview-wrapper > img#image-preview').hide();
  } else {
      $('.image-preview-wrapper, .image-preview-wrapper > img#image-preview').show();
  }

  $('#upload_image_button').on('click', function(event) {
      event.preventDefault();
      $('.image-preview-wrapper, .image-preview-wrapper > img#image-preview').show();

      var file_frame;
      var wp_media_post_id = wp.media.model.settings.post.id;
      var imageUrl = rssFeedVars.imageUrl;

      if (file_frame) {
          file_frame.uploader.uploader.param('post_id', set_to_post_id);
          file_frame.open();
          return;
      } else {
          wp.media.model.settings.post.id = set_to_post_id;
      }

      file_frame = wp.media.frames.file_frame = wp.media({
          title: 'Select an image to upload',
          button: {
              text: 'Use this image',
          },
          multiple: false
      });

      file_frame.on('select', function() {
          var attachment = file_frame.state().get('selection').first().toJSON();
          $('.image-preview-wrapper #image-preview').hide();

          // Remove any existing preview image before adding a new one
          $('#image-preview').remove();
          //$('.image-preview-wrapper').after('<img id="image-preview"').attr('src', attachment.url).css('width', 'auto');
          if(attachment.url){
            $('.image-preview-wrapper').after('<img id="image-preview" src="' + attachment.url + '" style="width: 150px;height:150px;display: block;">');
          } else {
            $(".clsImagePreview").hide();
          }
          $('#image_attachment_id').val(attachment.id);
          wp.media.model.settings.post.id = wp_media_post_id;
      });

      file_frame.open();
  });

  $('#delete_image_button').on('click', function() {
      $('#image-preview').attr('src', '').hide();
      $('#image_attachment_id').val("");
  });

  $('a.add_media').on('click', function() {
      wp.media.model.settings.post.id = wp_media_post_id;
  });
});
