# wc-product-customer-list
A WordPress plugin that simply displays a list of customers who bought a specific product at the bottom of the WooCommerce product edit page or as a shortcode.
