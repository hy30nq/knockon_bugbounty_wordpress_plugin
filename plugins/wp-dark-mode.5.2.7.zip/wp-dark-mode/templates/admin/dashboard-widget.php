<?php
/**
 * Admin Dashboard Widget for WP Dark Mode
 *
 * @package WP Dark Mode
 * @since 5.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit( 1 );

?>
<div class="wp-dark-mode-dashboard-widget" id="wp-dark-mode-dashboard-widget"></div>