# WPCore

This is a sort of mirror for the WPCore plugin manager for WordPress. Please do not install this version. To install the plugin go to https://wordpress.org/plugins/wpcore/.