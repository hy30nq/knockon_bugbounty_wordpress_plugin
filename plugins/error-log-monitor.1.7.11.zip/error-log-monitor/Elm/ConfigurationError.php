<?php

interface Elm_ConfigurationError {
	/**
	 * @return string
	 */
	public function getHtml();
}