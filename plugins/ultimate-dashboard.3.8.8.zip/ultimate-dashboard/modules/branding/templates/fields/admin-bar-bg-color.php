<?php
/**
 * Admin bar bg color field.
 *
 * @package Ultimate_Dashboard_PRO
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

return function () {

	?>

	<input type="text" name="" value="#1d2327" class="udb-color-field udb-branding-color-field udb-instant-preview-trigger" data-default="#1d2327" data-udb-trigger-name="admin-bar-bg-color" />

	<?php

};
