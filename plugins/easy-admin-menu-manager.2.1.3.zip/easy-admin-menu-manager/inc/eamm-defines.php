<?php
/**
 * Project: WordPress PhpStorm
 * Copyright: (C) 2022 clinton
 * Developer:  clinton
 * Created on 06/03/2022 [11:51]
 *
 * Description: Defines for the ABC Plugin Template Plugin
 *
 * This program is the property of the developer and is not intended for distribution. However, if the
 * program is distributed for ANY reason whatsoever, this distribution is WITHOUT ANY WARRANTEE or even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

