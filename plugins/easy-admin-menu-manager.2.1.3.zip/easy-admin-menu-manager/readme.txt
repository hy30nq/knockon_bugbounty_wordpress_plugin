﻿=== Easy Admin Menu Manager ===
Contributors: creatorseo, clinton101
Tags: Dashboard Menu Manager, Distraction-Free Admin Menu, WordPress Admin, Efficient Admin Workspace, De-clutter
Requires at least: 5.1
Tested up to: 6.7
Stable tag: 2.1.3
Requires PHP: 7.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Take control of your Dashboard Menu with the Easy Admin Menu Manager. Remove the clutter without losing any functionality.

== Description ==

Take control of your Dashboard Menu with the Easy Admin Menu Manager from CreatorSEO. The Easy Admin Menu Manager plugin lets you quickly and easily configure and switch to distraction-free mode by removing the clutter from your admin menu. There is no loss of control of the menus or the functionality provided by any of your plugins.

**Features**

* Removes any clutter from the admin menu
* Does not remove any functionality
* Intuitive and easy to use
* Takes minutes to implement but potentially saves hours when updating your site
* Complies fully with GDPR
* Does not hide the Admin menu you are working on

**Background**

While every plugin that you install adds functionality to your website, these plugins also add items to the admin menu list which are seldom used. Your admin menu consequently becomes cluttered and difficult to navigate. This easy to use plugin removes the clutter without removing any of the functionality in the admin menu. All the commands remain right there for you to use when you need them.
*A tidy workspace allows you to focus on the things that matter*
This plugin is ideal for developers or admins who want the editors or contributors of the website to remain focussed on the elements that they should be using to update or to contribute to the website.

== Installation ==

1. Upload 'Easy Admin Menu Manager' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on 'Easy Admin Menu' in the Admin Dashboard
4. Select which menu items should be hidden
5. Click on 'Save Changes' to update the results
6. Click on 'Dashboard' to view the uncluttered dashboard

== Frequently Asked Questions ==

= Will Easy Admin Menu Manager work with any theme? =
Yes, the plugin is theme independent.
= If an item is switched off is it no longer available? =
All menu items remain available and accessible. However, the dashboard is neatened, so you can focus on the items that matter.
= What happens if I am working on an admin page and this is set to hidden? How do I view the submenu items?
Click the 'Show Full Menu' button and all menu items will be revealed. Select the menu you want to use. Optionally click 'Simplify Menu' if you want top return to distraction-free mode. The menu you are working on will not be hidden.
= Can the Admin menu manager be switched off? =
Easy Admin Menu will display 'Simplify Menu' or 'Show Full Menu' on the admin menu and this will toggle the menu between Normal and Distraction-Free modes.
= Does this plugin change the access level for different roles?
No, the default access for roles remain the same and are not changed. However, Easy Admin Menu Manager ensures that the roles remain focussed on the important menu elements.
= Does this plugin affect the menus on the front end of the website? =
No, this plugin only works on the Admin Menu and has no impact on the front-end menus.
= Does Easy Admin Menu Manager affect the updating of other Plugins?
No, the Admin Menu Manager does not affect other Plugins in any way. Updates continue as normal for hidden items.


== Screenshots ==

1. This shows a typical WordPress Admin menu before 'Easy Admin Menu' is activated. The number of available options in the menu on the left can be overwhelming if many plugins are installed.
2. Once Easy Menu Manager is activated the number of menu items can be reduced allowing users to focus on the important items.
3. Clicking on the Simplify Menu icon hides menu entries that are set to hide. Clicking again on 'Show Full Menu' returns the full menu.
4. Items that should be hidden for distraction free work can be set from the Settings > Easy Admin Menu of the Dashboard Widget.
5. Individual menu items can then be toggled on and off. Save changes after selecting the required menu configuration.
6. You need to press 'Save Changes' at the bottom of the 'Easy Menu Manager' page to implement the selections.
7. The Easy Admin Menu Widget can be switched on or off from the Settings menu. The default is ON.


== Changelog ==
= 2.1.3 =
* Checks and PHP 8+ updates for Compatibility

= 2.1.2 =
* Version check and UI / cosmetic updates

= 2.1.1 =
* Toggle code changed from back-end (PHP) toggle to front-end (JS) for improved speed and a better user experience.
* Compatibility checks and updates.

= 2.0.1 =
* Menu toggled from show to hide and vice-versa with a single click.
* Settings menu moved.
* Icon and menu text changed.

= 1.1.2 =
* Image Swap-out

= 1.1.1 =
* Fix undeclared variable warning

= 1.1.0 =
* Functionality enhancement - the active menu and related submenus remain visible. This allows the user to see the submenus relevant to the item being worked on.

= 1.0.2 =
* Updated default selection of menus

= 1.0.1 =
* Launch of Easy Menu Manager on WordPress

= 0.0.1 =
* Plugin creation, function updates and testing in a Beta environment.

== Upgrade Notice ==

= 1.0.1 =
Tested with WordPress Versions 5.1 and 6.1
