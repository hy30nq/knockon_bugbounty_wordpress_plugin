<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Archives listing page
 *
 * @since    1.1.1
 */
?>
<h2><?php _e('Sticky Notes Archives', 'wb-sticky-notes'); ?></h2>

<div class="wb_stn_archives">

</div>