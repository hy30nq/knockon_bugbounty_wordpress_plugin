=== Wb Sticky Notes ===
Contributors: webbuilder143
Donate link: https://webbuilder143.com/support-our-work/?utm_source=wordpressorg&utm_medium=readme&utm_campaign=donate-link&utm_id=notes-plugin&utm_content=donate
Tags: dashboard, admin, sticky, notes, backend
Requires at least: 3.0.1
Tested up to: 6.7
Requires PHP: 5.6
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily add customizable sticky notes to your WordPress admin dashboard for quick reminders and important information.

== Description ==

Sticky Notes for WordPress lets you create virtual sticky notes in your admin dashboard, similar to desktop sticky notes. With an intuitive interface, you can customize and manage notes easily while controlling their appearance and visibility.

== Features ==

1. Create sticky notes similar to desktop sticky notes
2. Easy-to-use interface for quick note management
3. Customize notes with different themes and fonts
4. Resizable and movable notes for better organization
5. Option to hide notes when not in use
6. Duplicate existing notes with a single click
7. Archive notes for future reference
8. Disable sticky notes on specific admin pages
9. Limit note access by user roles

== Our other free solutions ==
1. [Custom Product Tabs For WooCommerce](https://wordpress.org/plugins/wb-custom-product-tabs-for-woocommerce/)
2. [Wb Mail Logger](https://wordpress.org/plugins/wb-mail-logger/)

== Installation ==

1. In your WordPress admin panel, got to Plugins -> New Plugin, search for "Wb Sticky Notes" and click install now.
2. Activate the plugin

== Frequently Asked Questions ==

= How can I create a new note? =
Any page of admin dashboard. You can find a menu named `Sticky notes` on top bar. There will be an option to create new notes.

= Is the notes are minimizable? =
Yes. But not individually. You can see the option to hide/show notes under `Sticky notes` menu on Admin top bar.

= Can I change the color theme of a note? =
Yes. Each note has its own menu on top left corner to customize.

= Is the notes are resizable? =
Yes.

= Is the notes are movable? =
Yes. Click and drag on the note's head to move.

= Can I disable sticky notes on specific admin screens? =
Yes. Go to the Sticky Notes settings and select the admin screens where you want to hide the notes. If the screen you want to hide the sticky note on is not listed, you can create a code snippet using the wb_stn_hide_on_these_pages filter to hide the sticky note from that screen.

== Screenshots ==

1. Settings page
2. Opened notes
2. Notes archive page

== Changelog ==

= 1.2.0 =
* [New] Added an option to hide sticky notes on specific pages.

= 1.1.7 =
* Tested OK with WordPress 6.7
* [Fix] Undefined variable $wb_stn_action - Thanks @antipole for pointing out the bug.

= 1.1.6 =
* Tested OK with WordPress 6.6

= 1.1.5 =
* Tested OK with WordPress 6.4
* [Add] Option to limit the usage based on user roles

= 1.1.4 =
* Tested OK with WordPress 6.3
* Tested OK with PHP 8.2

= 1.1.3 =
* Tested OK with WordPress 6.2

= 1.1.2 =
* Tested OK with WordPress 6.1.1
* New colour theme added (Grey)

= 1.1.1 =
* [Add] New option to archive the notes 
* Tested OK with WordPress 6.0.1

= 1.1.0 =
* [Bug fix] Undefined variable $state

= 1.0.9 =
* [Bug fix] Positioning issue in WooCommerce product edit pages. Thanks @imborx for pointing out the bug.

= 1.0.8 =
* Tested OK with WordPress 5.9

= 1.0.7 =
* Tested OK with WordPress 5.8

= 1.0.6 =
* Tested OK with WordPress 5.7

= 1.0.5 =
* Tested OK with WordPress 5.6

= 1.0.4 =
* Tested OK with WordPress 5.5
* New colour theme added (Orange)

= 1.0.3 =
* Tested OK with WordPress 5.4

= 1.0.2 =
* Tested OK with WordPress 5.3

= 1.0.1 =
* Added system default font to font list for more readability

= 1.0 =
* Initial Version


== Upgrade Notice ==

= 1.2.0 =
* [New] Added an option to hide sticky notes on specific pages.
