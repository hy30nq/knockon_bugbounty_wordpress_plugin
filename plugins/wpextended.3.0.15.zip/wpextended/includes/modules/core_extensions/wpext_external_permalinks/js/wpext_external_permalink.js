jQuery(document).ready(function() {
    jQuery('.wpext_external_permalink form input').change(function(){
      jQuery('.wpext-white-wrap').removeClass('wpext_hide');
    });
});

