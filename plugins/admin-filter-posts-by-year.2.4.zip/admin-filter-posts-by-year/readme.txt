=== Admin filter posts by year ===
Plugin Name: Admin filter posts by year
Contributors: gilles66
Tags: posts, filter, years, year, admin
Requires at least: 3.8
Tested up to: 6.7.1
Stable tag: 2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

In your admin area, this plugin offers the avaibility to filter your posts by YEARS and not only by MONTHS OF YEARS.

== Description ==

In your admin area, this plugin offers the avaibility to filter your posts by YEARS and not only by MONTHS OF YEARS.

== Installation ==

1. Upload the folder 'admin_filter_posts_by_years' to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the admin page of a list of posts
1. Check the filter by date list, and see that you have now the avaibility of filter them by year !

== Frequently Asked Questions ==

= Is it automatic ? =

Yes, completely !

= For which type of post types does the plugin functions ? =

All types of custom post types : post, page, and your custom post types.

== Screenshots ==

1. The date filter list, with the years.

== Changelog ==

= 2.4 =
* Compatibility with WP 6.7.1

= 2.3 =
* Compatibility with WP 6.3.2

= 2.1.0 =
* Compatibility with WP 5.8

= 2.1 =
* Compatibility with WP 5.4

= 1.1 =
* Compatibility with WP 4.1

= 1.0 =
* First version
