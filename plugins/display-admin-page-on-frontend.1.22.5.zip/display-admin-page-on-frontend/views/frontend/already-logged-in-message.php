
<p><b><?php _e('Note from WP Frontend Admin.', VG_Admin_To_Frontend::$textname); ?></b></p>
<p><?php _e('The login form shortcode will not load for you because you already logged in. The login form will appear when you open this page as a guest user.', VG_Admin_To_Frontend::$textname); ?></p>