=== Captchinoo, admin login page protection with Google recaptcha ===
Contributors: wp-buy, mohmmedalagha
Tags: captcha, firewall, login, protection, recaptcha, Google recaptcha, security, form
Requires at least: 4.6
Tested up to: 6.7.1
Stable tag: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Want to verify that your website users are not bots with a very simple way with one click installation? you need Captchinoo Captcha plugin!!

== Description ==
Captchinoo Captcha plugin is the best security wordpress plugin to protect your login form from robots and spammers.

**FEATURES:**
1. Two simple and beautiful types of captcha
2. Sliding captcha like iphone slide to unlock
3. Icons captcha (Select the different icon to login)
4. Translataion supported
5. Simple
6. Easy to use
7. No conflict with other plugins, specially caching plugins


**SUPPORT:**

If you have any problems, questions or recommendations about Captchinoo Captcha plugin please feel free to contact us directly. We try to answer all questions as fast as possible!
Want to say “thank you”? Please leave a review.

== Screenshots ==
1. Screenshot1

== Installation Guide ==
**Installation steps**
1.Download the package.
2.Extract the contents of the downloaded zip file to wp-content/plugins/ folder  You should get a folder called captchinoo-captcha-free
3.Activate the Plugin in WP-Admin.
4.Goto plugins list > **Captchinoo Captcha** > Settings to configure options.
5.You will find all options there.
Thanks!

== Changelog ==

= 4.2 =
<ul>
<li>hCaptcha Support</li>

</ul>

= 4.1 =
<ul>
<li>Fix some errors with slide captcha</li>
<li>Css fixes</li>
<li>JS fixes</li>
<li>Update google captcha help link</li>
<li>Interface update</li>
<li>check with the latest wordpress update</li>
</ul>

= 3.2 =
<ul>
<li>check with the latest wordpress update</li>
</ul>

= 3.1 =
<ul>
<li>Clean outputs</li>
</ul>

= 3.0 =
<ul>
<li>Code fix & check with the latest wordpress update</li>
</ul>

= 2.5 =
<ul>
<li>Code fix & check with the new wordpress update</li>
</ul>

= 2.4 =
<ul>
<li>Code fix & check with the new 5.7 wordpress update</li>
</ul>

= 2.3 =
<ul>
<li>Important fixing (PHP Short Array Syntax Error) in Google recaptcha</li>
</ul>

= 2.2 =
<ul>
<li>Important fixing (PHP Short Array Syntax Error)</li>
</ul>

= 2.1.1 =
<ul>
<li>Important fix for 1.9 update</li>
<li>Add links to dismiss the new start page links</li>
<li>Change the name of the plugin</li>
</ul>
= 1.9 =
* New advanced and easy to use starting page panel
= 1.8 =
<ul>
<li>Review bar added</li>
</ul>
= 1.7 =
<ul>
<li>Code fix</li>
<li>admin styles fix</li>
<li>Google captcha new option fix</li>
<li>Auto redierct after saving when use google captcha</li>
<li>Help added to enable google captcha simply</li>
</ul>
= 1.6 =
<ul>
<li>Code fix</li>
<li>Add google captcha version 2 new feature</li>
</ul>
= 1.5 =
<ul>
<li>Fix (slider captcha don't touch on mobile devices)</li>
<li>Fix (slider captcha full slide action not doing any action)</li>
<li>Add about new tab</li>
<li>Change the translation text domain to be the same as the plugin main slug captchinoo-captcha-for-login-form-protection</li>
</ul>
= 1.4 =
<ul>
<li>Change dropdown theme chooser to image chooser</li>
<li>Some fixes</li>
</ul>
= 1.3 =
<ul>
<li>Activate function (icon captcha function), error fixed!</li>
</ul>
= 1.2 =
<ul>
<li>Stop the (icon captcha function) because of not loading error</li>
</ul>
= 1.1 =
<ul>
<li>Upload missing files by mistake</li>
</ul>
= 1.0 =
<ul>
<li>initial version</li>
</ul>