<?php
if (! defined('ABSPATH')) exit; // Exit if accessed directly
if (! class_exists('cap_free_ver_admin_setting')) {
	class cap_free_ver_admin_setting
	{

		public function __construct()
		{
			add_action('admin_menu', array($this, 'cap_free_ver_options_page'));
			add_action('admin_init', array($this, 'cap_free_ver_settings_init'));
			add_action('admin_footer', array($this, 'cap_free_ver_hkdc_admin_jQ'), 100);
			add_action('admin_enqueue_scripts', array($this, 'wpdocs_selectively_enqueue_admin_script'));
		}
		public function cap_free_ver_settings_init()
		{
			register_setting('cap_free_ver', 'cap_free_ver_options');
			add_settings_section(
				'cap_free_ver_section_developers',
				__('', 'captchinoo-captcha-for-login-form-protection'),
				array(),
				'cap_free_ver'
			);
			add_settings_field(
				'cap_free_ver_status',
				__('Plugin Status:', 'captchinoo-captcha-for-login-form-protection'),
				array($this, 'cap_free_ver_field_type_checkbox'),
				'cap_free_ver',
				'cap_free_ver_section_developers',
				array(
					'label_for' => 'cap_free_ver_status',
					'class' => 'cap_free_ver_row',
					'cap_free_ver_custom_data' => 'custom',
					'textOn' => 'ON',
					'textOff' => 'OFF',
				)
			);

			add_settings_field(
				'Google_reCAPTHA_site_key',
				__('Google reCAPTHA site key', 'wp-maintenance-mode-site-under-construction'),
				array($this, 'cap_free_ver_field_type_google_api'),
				'cap_free_ver',
				'cap_free_ver_section_developers',
				array(
					'label_for' => 'Google_reCAPTHA_site_key',
					'class' => 'Google_reCAPTHA_row',
				)
			);
			add_settings_field(
				'Google_reCAPTHA_secret_key',
				__('Google reCAPTHA secret key', 'wp-maintenance-mode-site-under-construction'),
				array($this, 'cap_free_ver_field_type_google_api'),
				'cap_free_ver',
				'cap_free_ver_section_developers',
				array(
					'label_for' => 'Google_reCAPTHA_secret_key',
					'class' => 'Google_reCAPTHA_row',
				)
			);

			add_settings_field(
				'cap_free_ver_mode',
				__('Captcha Type', 'captchinoo-captcha-for-login-form-protection'),
				array($this, 'cap_free_ver_field_type_Captcha'),
				'cap_free_ver',
				'cap_free_ver_section_developers',
				array(
					'label_for' => 'cap_free_ver_mode',
					'class' => 'cap_free_ver_row',
					'cap_free_ver_custom_data' => 'custom',
				)
			);
		}
		public function cap_free_ver_field_type_checkbox($args)
		{
			$options = get_option('cap_free_ver_options');

?>
			<span class="on_off off"><?php esc_html_e($args['textOff'], 'captchinoo-captcha-for-login-form-protection'); ?></span>
			<label class="switch">
				<input type="checkbox" value="1" id="<?php echo esc_attr($args['label_for']); ?>" data-custom="<?php echo esc_attr($args['cap_free_ver_custom_data']); ?>" name="cap_free_ver_options[<?php echo esc_attr($args['label_for']); ?>]" <?php echo isset($options[$args['label_for']]) ? (checked($options[$args['label_for']], '1', false)) : (''); ?>>
				<span class="slider round"></span>
			</label>
			<span class="on_off on"><?php esc_html_e($args['textOn'], 'captchinoo-captcha-for-login-form-protection'); ?></span>
			<p class="description">
				<?php esc_html_e('Using this option, you can enable or disable the plugin functionality', 'captchinoo-captcha-for-login-form-protection'); ?>
			</p>

		<?php
		}
		public function cap_free_ver_field_type_google_api($args)
		{
			$options = get_option('cap_free_ver_options');
		?>
			<input type="text" name="cap_free_ver_options[<?php echo esc_attr($args['label_for']); ?>]" id="<?php echo esc_attr($args['label_for']); ?>" value="<?php if (isset($options[$args['label_for']])) {
																																										echo esc_attr($options[$args['label_for']]);
																																									} ?>">
			<p class="description">
				<?php esc_html_e('You must get your own keys ', 'wp-maintenance-mode-site-under-construction'); ?>
				<?php if ($args['label_for'] == 'Google_reCAPTHA_secret_key') { ?>
					<a href="https://www.google.com/recaptcha/admin" target="_blank" style="cursor: pointer;" id="helpBtn"><?php _e('How to get my own keys?', 'captchinoo-captcha-for-login-form-protection'); ?></a>
				<?php } ?>
			</p>

		<?php
		}
		public function cap_free_ver_field_type_Captcha($args)
		{
			$options = get_option('cap_free_ver_options');
		?>
			<div class="radio_sellected">
				<label>
					<input type="radio" class="template_select" name="cap_free_ver_options[<?php echo esc_attr($args['label_for']); ?>]" <?php if (!extension_loaded('gd')) { ?>disabled<?php } ?> value="IconCaptcha" <?php (isset($options[$args['label_for']]) && extension_loaded('gd')) ? checked($options[$args['label_for']], "IconCaptcha") : ''; ?>>
					<img <?php if (!extension_loaded('gd')) { ?>id="notice_feature_btn" <?php } ?> class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/icon.jpg'); ?>">
					<?php if (!extension_loaded('gd')) { ?>
						<div class="disabled_image_chick" id="notice_feature_btn_ink"><?php _e('notice: You cant use this feature', 'captchinoo-captcha-for-login-form-protection'); ?></div>
					<?php } ?>
				</label>
				<label>
					<input type="radio" class="template_select" name="cap_free_ver_options[<?php echo esc_attr($args['label_for']); ?>]" value="Swipecaptcha" <?php isset($options[$args['label_for']]) ? checked($options[$args['label_for']], "Swipecaptcha") : ''; ?>>
					<img class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/slid.jpg'); ?>">
				</label>
				<label>
					<input type="radio" class="template_select" name="cap_free_ver_options[<?php echo esc_attr($args['label_for']); ?>]" value="Google_reCAPTHA" <?php isset($options[$args['label_for']]) ? checked($options[$args['label_for']], "Google_reCAPTHA") : ''; ?>>
					<img class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/recapthav2.jpg'); ?>">
				</label>
				<label>
					<input type="radio" class="template_select" disabled>
					<a href="https://www.wp-buy.com/product/captchinoo-captcha-2fa-pro" target="_blank"><img class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/Google V3.png'); ?>"></a>
				</label>
				<label>
					<input type="radio" class="template_select" disabled>
					<a href="https://www.wp-buy.com/product/captchinoo-captcha-2fa-pro" target="_blank"><img class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/2FA.png'); ?>"></a>
				</label>
				<label>
					<input type="radio" class="template_select" disabled>
					<a href="https://www.wp-buy.com/product/captchinoo-captcha-2fa-pro" target="_blank"><img class="radio_image_slid" src="<?php echo esc_url(cap_free_ver_PLUGIN_URL . '/assets/images/hcaptcha.png'); ?>"></a>
				</label>
			</div>
		<?php
		}
		//---------------------------------------------------------------------------------------------
		// Add a settings link to the WordPress side menue
		//---------------------------------------------------------------------------------------------
		public function cap_free_ver_options_page()
		{
			add_menu_page(
				__('Captcha free', 'captchinoo-captcha-for-login-form-protection'),
				__('Captcha free', 'captchinoo-captcha-for-login-form-protection'),
				'administrator',
				'cap_free_ver_options_page',
				array($this, 'cap_free_ver_options_page_html'),
				'dashicons-update-alt',
				6
			);

			add_submenu_page(
				'_doesnt_exist',
				__('google recaptcha option', 'captchinoo-captcha-for-login-form-protection'),
				'',
				'administrator',
				'cap_free_ver_google_recaptcha_v2',
				array($this, 'cap_free_ver_options_google_recaptcha_v2_html')
			);
		}
		public function cap_free_ver_options_google_recaptcha_v2_html()
		{
			if (! current_user_can('administrator')) {
				return;
			}
			$error = 0;
			$options = get_option('cap_free_ver_options');
			if (isset($_POST) && isset($_POST["g-recaptcha-response"])) {
				$response = sanitize_text_field($_POST["g-recaptcha-response"]);
				if (!$response) {
					$error = 1;
				}

				$secretKey = $options['Google_reCAPTHA_secret_key'];


				$endpoint = 'https://www.google.com/recaptcha/api/siteverify';

				$body = array(
					'secret'  => $secretKey,
					'response' => $response,
					'remoteip' => $_SERVER['REMOTE_ADDR']
				);


				$options = array(
					'body'        => $body,
				);

				$response = wp_remote_post($endpoint, $options);
				$response = json_decode($response['body']);
				if ($response->success == false) {
					$error = 1;
				} else {
					$options = get_option('cap_free_ver_options');
					$options['cap_free_ver_status'] = 1;
					update_option('cap_free_ver_options', $options);
					$error = 2;
				}
			}
			$options = get_option('cap_free_ver_options');
		?>
			<h2><?php _e('Captchinoo Captcha', 'captchinoo-captcha-for-login-form-protection'); ?></h2>

			<?php
			if ($error == 1) {
			?>
				<div class="error  notice">
					<p><?php _e('Sorry! This can not be done, please try again or check your captcha settings again2', 'captchinoo-captcha-for-login-form-protection'); ?></p>
				</div>
			<?php
			} else if ($error == 2) { ?>
				<div class="updated notice">
					<p><?php _e('Great! your settings are now verified & saved successfully', 'captchinoo-captcha-for-login-form-protection'); ?></p>
				</div>
			<?php
			}
			?>
			<div id="">
				<div id="dashboard-widgets" class="metabox-holder">
					<div id="" class="">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<div id="dashboard_quick_press" class="postbox ">
								<h2 class="hndle ui-sortable-handle">
									<span>
										<h2 class="hide-if-no-js"><?php _e('General Options', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
										<h2 class="hide-if-js"><?php _e('General Options', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
									</span>
								</h2>
								<div class="inside">
									<?php
									if ($error == 2) {
									?>
										<script>
											setTimeout(function() {
												window.location.href = '<?php echo esc_js(admin_url('/admin.php?page=cap_free_ver_options_page&message=2')); ?>';
											}, 5000);
										</script>
										<div style="padding:12px;">
											<p></p>
											<p><?php _e('Great! your settings are now verified & saved successfully.', 'captchinoo-captcha-for-login-form-protection'); ?></p>
											<p></p>
											<p><?php _e('Web page redirects after 5 seconds.', 'captchinoo-captcha-for-login-form-protection'); ?></p>
											<p></p>
											<p><a target="_parent" href="<?php echo esc_js(admin_url('/admin.php?page=cap_free_ver_options_page&message=2')); ?>">Go to settings again</a>.</p>
										</div>
									<?php } else { ?>
										<form action="#" method="post">
											<p><?php _e('One more step required before saving, The captcha will not work if you leave this page without action', 'captchinoo-captcha-for-login-form-protection'); ?></p>
											<div class="input-text-wrap cap_free_ver" id="title-wrap">
												<div class="captcha_wrapper">
													<div class="g-recaptcha" data-sitekey="<?php echo esc_attr($options['Google_reCAPTHA_site_key']); ?>"></div>
												</div>
											</div>
											<input type="hidden" name="vertified" value='1'>
											<p class="submit">
												<?php
												submit_button('Verify & save');
												?>
												<br class="clear">
											</p>
										</form>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php

		}
		function wpdocs_selectively_enqueue_admin_script($hook)
		{
			if ('admin_page_cap_free_ver_google_recaptcha_v2' != $hook) {
				return;
			}
			wp_enqueue_script('google_recap_v2', 'https://www.google.com/recaptcha/api.js', array(), '1.0');
		}
		public function cap_free_ver_options_page_html()
		{

			if (! current_user_can('administrator')) {
				return;
			}

			if (isset($_GET['settings-updated'])) {
				add_settings_error('cap_free_ver_messages', 'cap_free_ver_message', __('Settings Saved', 'captchinoo-captcha-for-login-form-protection'), 'updated');
			}
			settings_errors('cap_free_ver_messages');

		?>
			<h2><?php _e('Captchinoo Captcha', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
			<p style="margin: 20px 0 20px;font-size: 16px;font-weight: bold;color: #d63638;">Unlock the full potential of your site's security with the premium version of our Captcha plugin
				<font color="#0909FF"><u>
						<a target="_blank" href="https://www.wp-buy.com/product/captchinoo-captcha-2fa-pro/#title">
							<font color="#0909FF"><?php _e('Buy PRO Now', 'captchinoo-captcha-for-login-form-protection'); ?></font>
						</a></u></font>
			</p>
			<?php
			if (isset($_GET['error']) && $_GET['error'] == 2) {
			?>
				<div class="updated notice">
					<p><?php _e('Great! your settings are now verified & saved successfully', 'captchinoo-captcha-for-login-form-protection'); ?></p>
				</div>
			<?php
			} ?>
			<div id="">
				<div id="dashboard-widgets" class="metabox-holder">
					<div id="" class="">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<div id="dashboard_quick_press" class="postbox ">
								<h2 style="background: currentColor;cursor: auto;" class="hndle ui-sortable-handle">
									<span>
										<h2 style="color: white" class="hide-if-no-js"><?php _e('General Options', 'captchinoo-captcha-for-login-form-protection'); ?> / <a style="color: white" id="myBtn"><?php _e('About', 'captchinoo-captcha-for-login-form-protection'); ?></a></h2>
										<h2 style="color: white" class="hide-if-js"><?php _e('General Options', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
									</span>
								</h2>
								<div class="inside">

									<form action="options.php" method="post">

										<div class="input-text-wrap cap_free_ver" id="title-wrap">
											<?php
											settings_fields('cap_free_ver');
											do_settings_sections('cap_free_ver');
											?>
										</div>
										<p class="submit">
											<?php
											submit_button('Save Settings');
											?>
											<br class="clear">
										</p>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- The Modal -->
			<div id="myModal" class="modal">

				<!-- Modal content -->
				<div class="modal-content">
					<div class="modal-header">
						<span class="modal_close_button" id="close_mod">&times;</span>
						<h2><?php _e('About', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
					</div>
					<div class="modal-body">
						<p> </p>
						<b><?php _e('Captchinoo Captcha for Login Form Protection', 'captchinoo-captcha-for-login-form-protection'); ?></b>
						<p><?php _e('The best security solution that protects your WordPress login form from spam entries', 'captchinoo-captcha-for-login-form-protection'); ?></p>
						<p><?php _e('Developed by: wp-buy team', 'captchinoo-captcha-for-login-form-protection'); ?></p>
					</div>

				</div>

			</div>
			<!-- The Modal -->
			<div id="notice_feature" class="modal">

				<!-- Modal content -->
				<div class="modal-content">
					<div class="modal-header">
						<span class="modal_close_button" id="close_mod_notice_feature">&times;</span>
						<h2><?php _e('notice: You cant use this feature', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
					</div>
					<div class="modal-body">
						<p> </p>
						<b><?php _e('Your web server does not support PHP GD extension, To use this option please go to your server settings and enable it', 'captchinoo-captcha-for-login-form-protection'); ?></b>
					</div>

				</div>

			</div>

			<div id="help_Modal" class="modal">

				<!-- Modal content -->
				<div class="modal-content">
					<div class="modal-header">
						<span class="modal_close_button" id="help_mod">&times;</span>
						<h2><?php _e('How to get my own keys from my google account?', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
					</div>
					<div class="modal-body">
						<p> </p>
						<p><?php _e('You can get the Google reCaptcha API keys by following the three simple steps listed below.', 'captchinoo-captcha-for-login-form-protection'); ?></p>
						<ul>
							<li><?php _e('1. Visit', 'captchinoo-captcha-for-login-form-protection'); ?> <a href="https://www.google.com/recaptcha/intro/v3beta.html" target="_blank"><?php _e('Google reCaptcha home', 'captchinoo-captcha-for-login-form-protection'); ?></a> <?php _e('and click My reCAPTCHA button.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('2. Choose a name for your captcha.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('3. Click the button (Admin console) to register a new site.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('4. Choose the reCAPTCHA type version 2.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('5. Enter your domain name.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('6. Accept the reCAPTCHA Terms of Service.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
							<li><?php _e('7. Copy the Site key and Secret key created for the registered application.', 'captchinoo-captcha-for-login-form-protection'); ?></li>
						</ul>
						<p><?php _e('That\'s all, Thank you', 'captchinoo-captcha-for-login-form-protection'); ?></p>
					</div>

				</div>

			</div>

			<div id="keyBtn" class="modal">

				<!-- Modal content -->
				<div class="modal-content">
					<div class="modal-header">
						<span class="modal_close_button" id="help_mod">&times;</span>
						<h2><?php _e('help m 1', 'captchinoo-captcha-for-login-form-protection'); ?></h2>
					</div>
					<div class="modal-body">
						<p> </p>
						<b><?php _e('Captchinoo Captcha for Login Form Protection', 'captchinoo-captcha-for-login-form-protection'); ?></b>
						<p><?php _e('The best security solution that protects your WordPress login form from spam entries', 'captchinoo-captcha-for-login-form-protection'); ?></p>
						<p><?php _e('Developed by: wp-buy team', 'captchinoo-captcha-for-login-form-protection'); ?></p>
					</div>

				</div>

			</div>
			<script>
				window.onload = function() {
					var modal = document.getElementById("myModal");
					var btn = document.getElementById("myBtn");
					var span = document.getElementById("close_mod");
					btn.onclick = function() {
						modal.style.display = "block";
					}
					span.onclick = function() {
						modal.style.display = "none";
					}

					var notice_feature_btn = document.getElementById("notice_feature_btn");
					var notice_feature_btn_ink = document.getElementById("notice_feature_btn_ink");
					var notice_feature = document.getElementById("notice_feature");
					var span_notice_feature = document.getElementById("close_mod_notice_feature");
					if (notice_feature_btn) {
						notice_feature_btn.onclick = function() {
							if (notice_feature) {
								notice_feature.style.display = "block";
							}
						}
					}

					if (notice_feature_btn_ink) {
						notice_feature_btn_ink.onclick = function() {
							if (notice_feature) {
								notice_feature.style.display = "block";
							}
						}
					}

					if (span_notice_feature) {
						span_notice_feature.onclick = function() {
							if (notice_feature) {
								notice_feature.style.display = "none";
							}
						}
					}

					var helpmodal = document.getElementById("help_Modal");
					var helpbtn = document.getElementById("helpBtn");
					var span = document.getElementById("help_mod");
					helpbtn.onclick = function() {
						helpmodal.style.display = "block";
					}
					span.onclick = function() {
						helpmodal.style.display = "none";
					}

					var modals = [modal, notice_feature, helpmodal];

					window.onclick = function(event) {
						modals.forEach(function(modal) {
							if (event.target == modal) {
								modal.style.display = "none";
							}
						});
					}
				}
			</script>
			<style>
				.dashicons-update-alt:before {
					color: darkorange !important;
				}
			</style>
			<?php
		}

		function cap_free_ver_hkdc_admin_jQ($page)
		{
			if (isset($_GET['page']) && $_GET['page'] == 'cap_free_ver_options_page') {
			?>
				<script type="text/javascript">
					jQuery(document).ready(function() {
						var template = jQuery('input[name="cap_free_ver_options[cap_free_ver_mode]"]:checked').val();

						if (template == 'Google_reCAPTHA') {
							jQuery(".Google_reCAPTHA_row").show();
						} else {
							jQuery(".Google_reCAPTHA_row").hide();
						}
						jQuery(".template_select").click(function() {
							var template = jQuery(this).val();
							if (template == 'Google_reCAPTHA') {
								jQuery(".Google_reCAPTHA_row").show();
							} else {
								jQuery(".Google_reCAPTHA_row").hide();
							}
						});
					});
				</script>
<?php
			}
		}
	}

	new cap_free_ver_admin_setting();
}
if (! function_exists('cap_free_ver_hkdc_admin_styles')) {
	function cap_free_ver_hkdc_admin_styles($page)
	{
		if (isset($_GET['page']) && $_GET['page'] == 'cap_free_ver_options_page') {
			wp_enqueue_style('admin-css', cap_free_ver_PLUGIN_URL . '/assets/css/admin-css.css?ver=5');
		}
	}

	add_action('admin_print_styles', 'cap_free_ver_hkdc_admin_styles');
}
