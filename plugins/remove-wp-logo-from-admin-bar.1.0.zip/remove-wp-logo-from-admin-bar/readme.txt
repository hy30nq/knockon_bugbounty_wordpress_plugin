=== Remove WP Logo from Admin Bar ===
Contributors: tcoder
Tags: remove logo, remove wordpress logo, remove logo from admin bar, remove wordpress logo from admin bar, admin bar
Requires at least: 3.0
Tested up to: 6.5.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will enable remove the WordPress Logo from admin bar.

== Description ==

This plugin will enable remove the WordPress Logo from admin bar.


= Plugin Features =

* Only 1 KB.
* Easy to use.
* One click to install

== Screenshots ==

1. Before Active Plugin.
2. After Active Plugin.

== Installation ==

= Installation =

1. Upload 'remove-wordpress-logo-admin-bar' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently Asked Questions ==

* For more questions or help, [contact me](mailto:info@tcoderbd.com).

== Changelog ==

= 1.0 =
* Initial release

