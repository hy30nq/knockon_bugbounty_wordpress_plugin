=== WP-Admin Search Post Meta ===
Contributors: meloniq
Tags: wp-admin, search, post meta, postmeta, custom fields
Requires at least: 4.9
Tested up to: 6.7
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Enables searching post meta fields on admin pages.

== Description ==

Enables searching post meta fields on admin pages.


== Installation ==

1. Upload the folder 'wp-admin-search-meta' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==

= 0.3 =
* Fixed compatibility with version 4.9 and higher

= 0.2 =
* Fixed issue with displaying multiple times the same post

= 0.1 =
* Initial release


== Upgrade Notice ==


== Frequently Asked Questions ==

= It does not work, what to do? =

Report it with details on [support forum](https://wordpress.org/support/plugin/wp-admin-search-meta/).


== Screenshots ==



