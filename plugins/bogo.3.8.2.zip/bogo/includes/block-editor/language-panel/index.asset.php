<?php

return array(
	'dependencies' => array(
		'react',
		'wp-api-fetch',
		'wp-components',
		'wp-data',
		'wp-edit-post',
		'wp-element',
		'wp-i18n',
		'wp-plugins',
		'wp-url',
	),
	'version' => BOGO_VERSION,
);
