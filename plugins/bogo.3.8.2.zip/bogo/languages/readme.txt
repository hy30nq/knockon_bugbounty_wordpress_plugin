Dear translators,

You can translate this plugin at

https://translate.wordpress.org/projects/wp-plugins/bogo

We appreciate your contribution.
