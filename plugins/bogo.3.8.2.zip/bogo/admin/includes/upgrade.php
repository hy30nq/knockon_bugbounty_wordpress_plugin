<?php

add_action( 'bogo_upgrade', 'flush_rewrite_rules', 10, 0 );
