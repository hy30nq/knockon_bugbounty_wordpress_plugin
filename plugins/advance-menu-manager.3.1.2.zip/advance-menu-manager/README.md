# theDotstore-advance-menu-manager-wordpress
Admin can effectively and easier way to manage the complex menu navigation of your WordPress website. it enhances the productivity of the managers while managing the menus for the website.
