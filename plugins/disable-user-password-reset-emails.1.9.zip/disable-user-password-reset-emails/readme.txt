=== Disable User Password Reset Admin Notifications ===

Contributors: cccamuseme
Tags: emails, admin, notifications
Requires at least: 4.9
Tested up to: 6.7
Stable tag: 1.9
Requires PHP: 7.4
License: GPL v3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Disable User Password Reset Emails

== Description ==

Disable admin email notifications when a user changes their password. Simply activate the plugin and you will no longer receive a email notification when a user resets their password.