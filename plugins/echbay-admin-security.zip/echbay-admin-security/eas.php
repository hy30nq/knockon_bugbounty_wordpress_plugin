<?php
/**
* Plugin Name: EchBay Admin Security
* Description: Set PIN/ Password for access to admin page. Default PIN: 2222 . Please change default PIN after first active this plugin.
* Plugin URI: https://www.facebook.com/groups/wordpresseb
* Plugin Facebook page: https://www.facebook.com/webgiare.org
* Author: Dao Quoc Dai
* Author URI: https://www.facebook.com/ech.bay/
* Version: 1.2.7
* Text Domain: webgiareorg
* Domain Path: /languages/
* License: GPLv2 or later
*/
defined('ABSPATH') or die('Invalid request.');
define('EAS_DF_VERSION', '1.2.7');
define('EAS_THIS_PLUGIN_NAME', 'EchBay Admin Security');
$build_sid = date('YmdH') . $_SERVER['HTTP_HOST'];
define('EAS_SESSION_ID', md5($build_sid . SECURE_AUTH_SALT));
define('EAS_HIDDEN_CAPTCHA', '_' . substr(EAS_SESSION_ID, 0, 12));
define('EAS_ARIA_REQUIRED', [
'name',
'email',
'phone',
'address',
'captcha',
]);
if (!class_exists('EAS_Actions_Module')) {
class EAS_Actions_Module
{
var $eb_plugin_data = '2222';
public $optionName = '_eas_token_for_admin_url';
public $optionGroup = 'eas-options-group';
public $defaultOptions = [];
public $defaultNameOptions = [];
public $my_settings = [];
public $plugin_page = 'echbay-admin-security';
public function __construct()
{
$this->defaultOptions = array(
$this->optionName => $this->eb_plugin_data,
);
$this->defaultNameOptions = array(
$this->optionName => [
'name' => 'PIN/ Password',
'description' => 'Enter a PIN or Password for security your login page. Default PIN: <strong>2222</strong>, please change this PIN to another number.'
],
);
$this->my_settings = $this->get_my_options();
add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_action_links'), 10, 2);
add_action('admin_menu', array($this, 'admin_menu'));
add_action('admin_init', array($this, 'register_my_settings')); }
public function add_action_links($links)
{
if (strpos($_SERVER['REQUEST_URI'], '/plugins.php') !== false) {
$settings_link = '<a href="' . admin_url('options-general.php?page=' . $this->plugin_page) . '" title="Settings">Settings</a>';
array_unshift($links, $settings_link); }
return $links; }
public function admin_menu()
{
add_options_page(
EAS_THIS_PLUGIN_NAME,
EAS_THIS_PLUGIN_NAME,
'manage_options',
$this->plugin_page,
array(
$this,
'main_page'
)
); }
public function register_my_settings()
{
register_setting($this->optionGroup, $this->optionName); }
public function get_my_options()
{
$result = [];
foreach ($this->defaultOptions as $k => $v) {
$a = get_option($k);
if (empty($a)) {
$a = $v; }
$result[$k] = $a; }
return $result; }
public function main_page()
{
$pl_url = plugin_dir_url(__FILE__);
$str_screenshot = '';
foreach (glob(__DIR__ . '/*.jpg') as $filename) {
$filename = basename($filename);
$str_screenshot .= '<h3>' . $filename . '</h3><p><img src="' . $pl_url . $filename . '"></p>'; }
include __DIR__ . '/includes/main_page.php'; }
}
function EAS_admin_notices()
{
echo '<div class="notice notice-warning is-dismissible">'
. sprintf(
'<p>Important: Please <a href="admin.php?page=%s">change default PIN</a> to another number (%s).</p>',
strtolower(str_replace(' ', '-', EAS_THIS_PLUGIN_NAME)),
EAS_THIS_PLUGIN_NAME
)
. '</div>'; }
function EAS_is_action_login()
{
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'login';
if (isset($_GET['key'])) {
$action = 'resetpass'; }
if (isset($_GET['checkemail'])) {
$action = 'checkemail'; }
$default_actions = array(
'confirm_admin_email',
'postpass',
'logout',
'lostpassword',
'retrievepassword',
'resetpass',
'rp',
'register',
'checkemail',
'confirmaction',
'login',
WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED,
);
if (
!in_array($action, $default_actions, true) && false === has_filter('login_form_' . $action)
) {
$action = 'login'; }
return $action; }
function EAS_my_mdnam($str)
{
return md5($str . $_SERVER['HTTP_HOST'] . EAS_SESSION_ID); }
function EBE_show_form_enter_pin($msg = '')
{
ob_end_clean();
$rand_iname = EAS_ARIA_REQUIRED[rand(0, count(EAS_ARIA_REQUIRED) - 1)];
$rand_ivalue = EAS_my_mdnam($rand_iname);
if ($rand_iname == 'email') {
$rand_ivalue .= '@' . $_SERVER['HTTP_HOST']; }
$result = file_get_contents(__DIR__ . '/404.html', 1);
$to = time() + rand(3000, 3600);
foreach (
[
'iname' => EAS_HIDDEN_CAPTCHA,
'to' => $to,
'token' => EAS_my_mdnam($to),
'sid' => substr(EAS_SESSION_ID, rand(0, strlen(EAS_SESSION_ID) - 6), 6),
'rand_iname' => $rand_iname,
'rand_ivalue' => $rand_ivalue,
'ebnonce' => isset($_POST['_ebnonce']) ? $_POST['_ebnonce'] : '',
'msg' => $msg,
'base_url' => get_home_url(),
] as $k => $v
) {
$result = str_replace('{' . $k . '}', $v, $result); }
die($result); }
function EBE_mdnam_guest_token($tk)
{
return md5($tk . $_SERVER['HTTP_HOST'] . SECURE_AUTH_SALT . date('YmdH')); }
if (is_admin()) {
$EAS_func = new EAS_Actions_Module();
if (
strpos($_SERVER['REQUEST_URI'], '/options-') !== false
|| strpos($_SERVER['REQUEST_URI'], '/index.php') !== false
|| strpos($_SERVER['REQUEST_URI'], '/plugins.php') !== false
|| strpos($_SERVER['REQUEST_URI'], '/options.php') !== false
) {
$ebe_admin_token = get_option($EAS_func->optionName);
if (empty($ebe_admin_token) || $ebe_admin_token == $EAS_func->eb_plugin_data) {
add_action('admin_notices', 'EAS_admin_notices'); }
}
}
else if (strpos($_SERVER['REQUEST_URI'], '/wp-login.php') !== false) {
$EAS_func = new EAS_Actions_Module();
$ebe_guest_token = get_option($EAS_func->optionName);
if (empty($ebe_guest_token)) {
$ebe_guest_token = $EAS_func->eb_plugin_data; }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
if (isset($_POST['_ebnonce'])) {
$this_bot = false;
$has_value = 0;
foreach (EAS_ARIA_REQUIRED as $k => $v) {
if (!isset($_POST[EAS_HIDDEN_CAPTCHA . '_' . $v])) {
$this_bot = $v;
break;
} else if (!empty($_POST[EAS_HIDDEN_CAPTCHA . '_' . $v])) {
$has_value++; }
}
foreach (
[
'sid',
'to',
'token',
'fjs',
] as $k => $v
) {
if (!isset($_POST[EAS_HIDDEN_CAPTCHA . '_' . $v])) {
$this_bot = $v;
break; }
}
$sid = $_POST[EAS_HIDDEN_CAPTCHA . '_sid'];
if (empty($sid) || strpos(EAS_SESSION_ID, $sid) === false) {
$this_bot = 'sid';
} else {
$to = $_POST[EAS_HIDDEN_CAPTCHA . '_to'];
$token = $_POST[EAS_HIDDEN_CAPTCHA . '_token'];
if (empty($to) || empty($token) || $to < time() || EAS_my_mdnam($to) != $token) {
$this_bot = 'token';
} else {
$fjs = $_POST[EAS_HIDDEN_CAPTCHA . '_fjs'];
if (empty($fjs) || strpos($fjs, '0.') === false) {
$this_bot = 'fjs'; }
}
}
if ($has_value === 1 && $this_bot === false && $_POST['_ebnonce'] == $ebe_guest_token) {
$redirect_to = (isset($_GET['redirect_to']) ? $_GET['redirect_to'] : '');
$confirm_to = get_home_url() . '/wp-login.php?ebe_token=' . EBE_mdnam_guest_token($ebe_guest_token);
if ($redirect_to != '') {
$confirm_to .= '&redirect_to=' . urlencode($redirect_to); }
die(header('Location: ' . $confirm_to)); }
else {
EBE_show_form_enter_pin('<p style="color: red;">PIN/ Password incorrect! Please try again...</p>'); }
}
}
else if (EAS_is_action_login() == 'login') {
if (!isset($_GET['ebe_token']) || $_GET['ebe_token'] != EBE_mdnam_guest_token($ebe_guest_token)) {
EBE_show_form_enter_pin(); }
}
}
}