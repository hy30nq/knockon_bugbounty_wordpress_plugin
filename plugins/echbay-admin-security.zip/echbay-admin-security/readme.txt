=== EchBay Admin Security ===
Plugin Name: EchBay Admin Security
Plugin URI: https://www.facebook.com/groups/wordpresseb
Plugin Facebook page: https://www.facebook.com/webgiare.org
Author: Dao Quoc Dai
Author URI: https://www.facebook.com/ech.bay
Text Domain: echbayeas
Tags: Protect wordpress admin,Secure Admin,Rename Admin URL, Change wp-admin url,Change Admin URL
Requires at least: 4.8
Tested up to: 6.7
Stable tag: 1.2.7
Version: 1.2.7
Contributors: itvn9online
Donate link: https://paypal.me/itvn9online/5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Protect Your Website Admin Against Hackers & Modify Login Page Design
( Nhiệm vụ: chặn mọi truy cập trực tiếp vào trang quản trị wordpress dưới dạng: /wp-admin/ )

== Description ==
If you run a WordPress website, you should absolutely use echbay-admin-security to secure it against hackers.

Protect WP-Admin fixes a glaring security hole in the WordPress community: the well-known problem of the admin panel URL.
Everyone knows where the admin panel, and this includes hackers as well.

Protect WP-Admin helps solve this problem by allowing webmasters to setup PIN number or password for login page.

The plugin also comes with some access filters, allowing webmasters to restrict guest and registered users access to wp-admin, just in case you want some of your editors to log in the classic way.


**[ Thanks for donate ](https://paypal.me/itvn9online/5)**


== Installation ==
1. Upload `echbay-admin-security` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. After activate, visit https://yourdomain.com/wp-admin for go to admin page.
4. Enter default PIN code: 2222 to continue...
5. Go to menu `Webgiare Plugins` menu and `Admin Security` menu in WordPress for set new admin PIN.

Cài đặt:
1. Upload thư mục `echbay-admin-security` vào trong thư mục `/wp-content/plugins/` trên host của bạn.
2. Kích hoạt `Plugins` trong trang quản trị plugin.
3. Sau khi kích hoạt plugin, bạn tiếp tục vào https://yourdomain.com/wp-admin để tới trang quản trị
4. Nhập mã PIN mặc định là: 2222 để tiếp tục...
5. Để thay đổi số 2222 kia bằng PIN mới -> trong menu admin -> Webgiare Plugins -> Admin Security -> nhập chuỗi ký tự mới rồi cập nhật.


== Frequently Asked Questions ==

== Screenshots ==
1. EchBay Admin Security setting.
2. In login page.

== Changelog ==

= Version 1.2.7 =
* Remove session

= Version 1.2.6 =
* Update anti-spam

= Version 1.2.5 =
* Up wp 6.3

= Version 1.2.4 =
* Add back to home link

= Version 1.2.3 =
* fixed check login action

= Version 1.2.2 =
* fixed block login

= Version 1.2.1 =
* fixed block login

= Version 1.2.0 =
* Edit content for send mail

= Version 1.1.9 =
* Support log for echbaydotcom plugin

= Version 1.1.8 =
* On/ Off send mail warning to admin

= Version 1.1.7 =
* Fixed get current time

= Version 1.1.6 =
* ERROR set cookie

= Version 1.1.5 =
* Fixed token for login by current server time

= Version 1.1.4 =
* Auto whitelist last login IP

= Version 1.1.3 =
* Hide warning text

= Version 1.1.2 =
* Dynamic URL for admin

= Version 1.1.1 =
* Up for WP 4.9

= Version 1.1.0 =
* Visit to for got password page.

= Version 1.0.9 =
* Update content for Email noti.

= Version 1.0.8 =
* Update content for Email noti.

= Version 1.0.7 =
* Fixed for 404 logout and check wp-login via EAS

= Version 1.0.6 =
* Re-install v1.0.5

= Version 1.0.5 =
* Block auto login by bot

= Version 1.0.4 =
* Default disable xmlrpc

= Version 1.0.3 =
* Set timeout to 6 hours

= Version 1.0.2 =
* Send email to admin if visit to /wp-admin

= Version 1.0.1 =
* None

= Version 1.0.0 =
* None

== Upgrade Notice ==

= Version 1.1.2 =
* None

= Version 1.1.1 =
* None

= Version 1.1.0 =
* None

= Version 1.0.9 =
* None

= Version 1.0.8 =
* None

= Version 1.0.7 =
* None

= Version 1.0.6 =
* None

= Version 1.0.5 =
* None

= Version 1.0.4 =
* None

= Version 1.0.3 =
* None

= Version 1.0.2 =
* None

= Version 1.0.1 =
* None

= Version 1.0.0 =
* None
