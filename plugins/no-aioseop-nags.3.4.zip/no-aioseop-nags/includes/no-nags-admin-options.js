jQuery(document).ready(function(){
 jQuery('li a[href*="admin.php?page=aioseo-redirects"]').each(function() {
jQuery(this).css({'visibility':'hidden','display':'none' })
});  
});