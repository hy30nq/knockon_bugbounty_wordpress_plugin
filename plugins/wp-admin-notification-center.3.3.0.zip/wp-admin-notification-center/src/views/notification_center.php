<div id="wanc_container" wanc-data-display="<?php echo esc_html(json_encode($dataView), ENT_QUOTES, 'UTF-8'); ?>">
	<span class="dashicons dashicons-no-alt" id="wanc_container_close"></span>
	<h3><?php echo __('There is no notification to display', 'wanc'); ?></h3>
</div>
