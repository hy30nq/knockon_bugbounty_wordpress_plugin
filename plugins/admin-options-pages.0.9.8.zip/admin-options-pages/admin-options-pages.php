<?php
/**
 * Plugin Name:  Admin Options Pages
 * Plugin URI:   https://adminoptionspages.com
 * Description:  Create and edit your own options pages with ease.
 * Version:      0.9.8
 * Author:       Johannes van Poelgeest
 * Author URI:   https://poolghost.com
 * Requires PHP: 8.0
 * Tested up to: 6.7
 * Text Domain:  admin-options-pages
 * License:      GPL-2.0+
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('WPINC')) {
    die;
}

if (!is_admin()) {
    return;
}

require 'vendor/autoload.php';

include plugin_dir_path(__FILE__) . 'bootstrap/bootstrap.php';
