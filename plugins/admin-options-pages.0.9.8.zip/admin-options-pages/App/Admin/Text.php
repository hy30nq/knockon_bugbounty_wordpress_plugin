<?php

namespace AOP\App\Admin;

class Text
{
    public static function data()
    {
        return [
            'general' => [
                'sidebarTitle' => __('Publish', 'admin-options-pages'),
                'modal' => [
                    'heading' => __('Are you sure?', 'admin-options-pages'),
                    'cancel' => __('Cancel', 'admin-options-pages'),
                    'delete' => __('Delete', 'admin-options-pages')
                ],
                'role' => [
                    'administrator' => _x('Administrator', 'User role', 'admin-options-pages'),
                    'editor' => _x('Editor', 'User role', 'admin-options-pages')
                ]
            ],
            'page' => [
                'create' => [
                    'buttonSave' => __('Save', 'admin-options-pages'),
                    'h1Title' => __('New Pages', 'admin-options-pages')
                ],
                'update' => [
                    'buttonUpdate' => __('Update', 'admin-options-pages'),
                    'linkDelete' => __('Delete', 'admin-options-pages'),
                    'h1Title' => __('Edit Pages', 'admin-options-pages'),
                    'deleteDropdown' => [
                        'cancel' => __('Cancel', 'admin-options-pages'),
                        'delete' => __('Delete', 'admin-options-pages')
                    ]
                ]
            ]
        ];
    }
}
