<?php

namespace AC;

/**
 * @deprecated NEWVERSION
 */
abstract class ListScreenPost extends ListScreen
{

}