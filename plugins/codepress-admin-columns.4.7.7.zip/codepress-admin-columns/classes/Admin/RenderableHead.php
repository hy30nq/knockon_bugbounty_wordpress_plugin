<?php

namespace AC\Admin;

use AC\Renderable;

interface RenderableHead
{

    public function render_head(): Renderable;

}