<?php

namespace AC\Admin;

use AC\Renderable;

abstract class ScreenOption implements Renderable {

}