<?php

namespace AC\Admin;

interface MenuListFactory {

	public function create(): MenuListItems;

}