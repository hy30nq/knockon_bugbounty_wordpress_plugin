<?php

declare(strict_types=1);

namespace AC\ListScreen;

use AC;

interface ListTable
{

    public function list_table(): AC\ListTable;

}