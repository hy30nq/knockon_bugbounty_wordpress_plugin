<?php

declare(strict_types=1);

namespace AC\ListScreen;

use AC;

interface ManageValue
{

    public function manage_value(): AC\Table\ManageValue;

}