<?php

namespace AC;

interface Renderable
{

    public function render(): string;

}