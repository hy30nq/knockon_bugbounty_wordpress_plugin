<?php

declare(strict_types=1);

namespace AC\ListScreenRepository;

interface Types
{

    public const DATABASE = 'ac-database';

}