<?php

namespace AC;

interface Registerable
{

    public function register(): void;

}