<?php
declare(strict_types=1);

namespace AC;

interface RequestAjaxHandler
{

    public function handle(): void;

}