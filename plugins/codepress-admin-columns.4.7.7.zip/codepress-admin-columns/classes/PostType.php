<?php

namespace AC;

interface PostType
{

    public function get_post_type(): string;

}