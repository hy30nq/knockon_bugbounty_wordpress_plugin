<?php

namespace AC\Asset;

interface Enqueueables
{

    public function get_assets(): Assets;

}