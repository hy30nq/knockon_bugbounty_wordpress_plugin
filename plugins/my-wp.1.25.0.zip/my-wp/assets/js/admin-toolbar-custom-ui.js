jQuery(function( $ ) {

});
