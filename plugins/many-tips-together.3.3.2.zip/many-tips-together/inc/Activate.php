<?php 

namespace ADTW;

defined('ABSPATH') || exit;

class Activate {
   
    protected function __construct() { }

    public static function activate() {
    }
}