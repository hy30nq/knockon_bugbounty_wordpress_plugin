<?php 

namespace ADTW;

defined('ABSPATH') || exit;

class Deactivate {
   
    protected function __construct() { }

    public static function deactivate() {
    }
}