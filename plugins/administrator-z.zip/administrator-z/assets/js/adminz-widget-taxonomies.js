document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.adminz_count_transient').forEach(dom => {

        // woocommerce current query
        const woo_tax_query = dom.getAttribute('data-woocommerce-tax_query');
        const woo_meta_query = dom.getAttribute('data-woocommerce-meta_query');
        const woo_date_query = dom.getAttribute('data-woocommerce-date_query');
        const widget = dom.closest('.widget');


        let term_ids = [];
        let children = [];


        // current term ids
        if (dom.tagName == 'FORM') {
            dom.querySelectorAll('option').forEach(item => {
                const value = item.getAttribute('value');
                if (value !== '-1') {
                    term_ids.push(value);
                    children[value] = item;
                }
            });
        } else if (dom.tagName == 'UL') {
            dom.querySelectorAll('li').forEach(item => {
                const classValue = item.getAttribute('class');
                const match = classValue.match(/cat-item-(\d+)/);
                if (match) {
                    const value = match[1];
                    term_ids.push(value);
                    children[value] = item;
                }
            });
        }

        term_ids = JSON.stringify(term_ids);

        (async () => {
            try {
                const url = adminz_js.ajax_url;
                const formData = new FormData();
                formData.append('action', 'adminz_widget_taxonomies_get_count');
                formData.append('term_ids', term_ids);
                formData.append('woo_tax_query', woo_tax_query);
                formData.append('woo_meta_query', woo_meta_query);
                formData.append('woo_date_query', woo_date_query);
                formData.append('nonce', adminz_js.nonce);
                //console.log('Before Fetch:', formData.get('data');

                const _fetch = await fetch(url, {
                    method: 'POST',
                    body: formData,
                });

                if (!_fetch.ok) {
                    throw new Error('Network response was not ok');
                }

                const response = await _fetch.json(); // reponse.text()
                if (response.success) {
                    // items
                    for (const key in response.data) {
                        if (Object.prototype.hasOwnProperty.call(response.data, key)) {

                            if (children.hasOwnProperty(key)) {
                                const value = response.data[key];
                                let item = children[key];
                                // console.log(item); 
                                if (value == "0") {
                                    item.classList.add('adminz_empty_value');
                                } else {
                                    item.classList.add('adminz_has_value');
                                }
                                let target = '';
                                if (item.tagName == 'LI') {
                                    let text = " <span>(" + value + ")</span>";
                                    target = item.querySelector('a');
                                    target.innerHTML += text;
                                }
                                if (item.tagName == 'OPTION') {
                                    let text = " (" + value + ")";
                                    target = item;
                                    target.textContent += text;
                                }
                            }
                        }
                    }
                    // widget 
                    if (response.data.widget_count > 0) {
                        widget.classList.add('adminz_has_value_widget');
                    } else {
                        widget.classList.add('adminz_empty_widget');
                    }
                }

                

            } catch (error) {
                console.error('Fetch error:', error);
            }
        })();
    });
});