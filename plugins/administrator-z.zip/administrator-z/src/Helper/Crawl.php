<?php
namespace Adminz\Helper;

class Crawl {
	public $action;
	public $url, $url_from, $type, $crawl_data;
	public $fixed_terms = [];
	public $images_saved = [];
	public $config = [];
	public $html, $doc;
	public $return_type = 'default'; // default| json | ID
	public $is_cron;
	public $cron_data;
	public $post_exists_on_wpposts; // tempolary to save text note
	public $transient_time = 6 * HOUR_IN_SECONDS;

	function __construct() {

	}

	function set_config( $override = false ) {
		$config = get_option( 'adminz_tools' );
		if ( $override ) {
			$config = $override;
		}
		$this->config = $config;
	}

	function run() {

		// check exists on db
		if ( $post_id = $this->post_exists_on_logs( $this->url, $this->action ) ) {
			$this->after_import( $post_id );
			return $this->report_run_single( $post_id, '[post_exists_on_logs]' );
		}

		$this->doc = new \DOMDocument();
		libxml_use_internal_errors( true );

		$encode = true;
		if ( $this->action == 'run_adminz_import_image' ) {
			$encode = false;
		}

		$this->html = $this->maybe_load_html( false, $encode );
		$return     = call_user_func( [ $this, $this->action ] );
		return $return;
	}

	function set_url( $url ) {
		// $url       = (array) $url; // change to multiple
		$this->url = $url;
	}

	function set_action( $action ) {
		$this->action = $action;
	}

	function set_return_type( $value ) {
		$this->return_type = $value;
	}

	function crawl_post( $data = false ) {
		$data    = $data ? $data : $this->crawl_data;
		$postarr = [ 
			'post_title'  => $data['post_title'],
			'post_status' => 'publish',
			'post_type'   => 'post',
		];

		// Check if a post with the same sanitized title already exists
		if ( $existing_id = $this->post_exists_on_wpposts( $postarr['post_title'], $postarr['post_type'] ) ) {
			$this->post_exists_on_wpposts = true;
			return $existing_id;
		}

		// prepare thumbnail
		if ( isset( $data['post_thumbnail'] ) ) {
			$postarr['_thumbnail_id'] = $this->save_image( $data['post_thumbnail'] );
		}

		// prepare content
		if ( isset( $data['post_content'] ) ) {
			$postarr['post_content'] = $this->prepare_thumbnail_content( $data['post_content'] );
		}

		// make sure at least 1 thumbnail
		if ( !isset( $postarr['_thumbnail_id'] ) and isset( $this->images_saved[0] ) ) {
			$postarr['_thumbnail_id'] = $this->images_saved[0];
		}

		// category
		if ( isset( $data['post_category'] ) ) {
			$postarr['tax_input'] = [ 'category' => $this->save_taxonomy( $data['post_category'] ) ];
		}

		// echo "<pre>"; print_r($postarr); echo "</pre>";die;
		$id = wp_insert_post( $postarr );
		if ( !is_wp_error( $id ) ) {
			return $id;
		}

		return false;
	}

	function crawl_product( $data = false ) {
		$data = $data ? $data : $this->crawl_data;

		// Check if a post with the same sanitized title already exists
		if ( $existing_id = $this->post_exists_on_wpposts( $data['product_title'], 'product' ) ) {
			$this->post_exists_on_wpposts = true;
			return $existing_id;
		}

		switch ( $data['product_type'] ) {
			case 'simple':
				$id = $this->crawl_product_simple( $data );
				break;

			case 'variation':
				$id = $this->crawl_product_variable( $data );
				break;

			case 'grouped':
				$id = $this->crawl_product_grouped( $data );
				break;
		}

		if ( $id ) {
			return $id;
		}
	}

	function crawl_product_simple( $data ) {
		$product    = new \WC_Product_Simple();
		$product    = $this->prepare_product_data( $product, $data );
		$product_id = $product->save();
		return $product_id;
	}

	function crawl_product_grouped( $data ) {
		$product = new \WC_Product_Grouped();
		$product = $this->prepare_product_data( $product, $data );

		// children
		$children = [];
		foreach ( ( $data['grouped_products'] ?? [] ) as $key => $product_child ) {
			$_Crawl = new self();
			$_Crawl->set_return_type( 'ID' );
			$_Crawl->set_config();
			$_Crawl->set_action( 'run_adminz_import_from_product' );
			$_Crawl->set_url( $product_child['url'] );
			$_Crawl->is_cron     = $this->is_cron; // assign luôn khỏi phải truyền sang. 
			$_Crawl->fixed_terms = $this->fixed_terms; // assign luôn khỏi phải truyền sang. 
			$child_product_id    = $_Crawl->run();
			$children[]          = $child_product_id;
		}

		$product->set_children( $children );
		$product_id = $product->save();

		return $product_id;
	}

	function crawl_product_variable( $data ) {
		// Tạo sản phẩm biến thể chính
		$product    = new \WC_Product_Variable();
		$product    = $this->prepare_product_data( $product, $data );
		$product_id = $product->save();

		// prepare attribute
		$prepare_attr = [];
		foreach ( $data['product_variations'] as $key => $value ) {
			$attributes = (array) $value->attributes;
			foreach ( $attributes as $_key => $_value ) {
				$_key = str_replace( 'attribute_pa_', '', $_key );
				$this->create_attribute_if_not_exists( $_key );
				$prepare_attr[ $_key ] = $prepare_attr[ $_key ] ?? [];
				if ( !in_array( $_value, $prepare_attr[ $_key ] ) ) {
					$this->create_attribute_tag_if_not_exists( $_value, $_key );
					$prepare_attr[ $_key ][] = $_value;
				}
			}
		}

		// create attribute
		$atts = [];
		foreach ( $prepare_attr as $name => $attr ) {
			$name      = "pa_$name";
			$attribute = new \WC_Product_Attribute();
			$attribute->set_id( wc_attribute_taxonomy_id_by_name( $name ) );
			$attribute->set_name( $name );
			$attribute->set_options( $attr );
			$attribute->set_position( 0 );
			$attribute->set_visible( true );
			$attribute->set_variation( true );
			$atts[] = $attribute;
		}

		$product->set_attributes( $atts );
		$product->save();

		// create variations
		foreach ( $data['product_variations'] as $key => $value ) {
			$variation = new \WC_Product_Variation();

			// attributes 
			$attributes = (array) $value->attributes;
			$tmp        = [];
			foreach ( $attributes as $key => $_value ) {
				$term_tag         = str_replace( 'attribute_', '', $key );
				$term_value       = $_value;
				$tmp[ $term_tag ] = $_value;
				$this->create_attribute_tag_if_not_exists( $term_value, $term_tag );
			}
			$variation->set_attributes( $tmp );

			$variation->set_parent_id( $product_id );
			$variation->set_sku( $value->sku ?? false );
			$variation->set_image_id( $this->save_image( $value->image->url ) );

			$variation->set_downloadable( $value->is_downloadable ?? false );
			$variation->set_virtual( $value->is_virtual ?? false );

			$variation->set_stock_status( $value->is_in_stock ?? false );
			$variation->set_regular_price( $value->display_regular_price ?? false );
			$variation->set_sale_price( $value->display_price ?? false );
			$variation->set_date_on_sale_from( $value->set_date_on_sale_from ?? false );
			$variation->set_date_on_sale_to( $value->set_date_on_sale_to ?? false );

			$variation->set_description( $value->description ?? false );

			// $variation->set_downloads( $value->is_downloadable ?? false);
			$variation->set_download_limit( $value->download_limit ?? false );
			$variation->set_download_expiry( $value->download_expiry ?? false );

			$variation->save();
		}


		$product->save();
		return $product_id;
	}

	function get_post_data( $html = false ) {
		//start check
		$html = $html ? $html : $this->html;
		$doc  = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $this->html );
		libxml_clear_errors();
		$xpath  = new \DOMXpath( $doc );
		$return = [];

		// title
		$post_title = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_post_title'] ]
			)
		);
		if ( !empty( $post_title ) ) {
			foreach ( $post_title as $element ) {
				$nodes = $element->childNodes;
				foreach ( $nodes as $node ) {
					$return['post_title'] = $node->nodeValue;
				}
			}
		}

		// thumbnail
		$post_thumbnail = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_post_thumbnail'] ]
			)
		);
		if ( !empty( $post_thumbnail ) ) {
			foreach ( $post_thumbnail as $element ) {
				// $nodes = $element->childNodes;
				// foreach ( $nodes as $node ) {
				$return['post_thumbnail'] = $this->get_image_src( $element );
				// }
			}
		}

		// category
		$post_category = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_post_category'] ]
			)
		);
		if ( !empty( $post_category ) ) {
			$return['post_category'] = [];
			foreach ( $post_category as $element ) {
				// $nodes = $element->childNodes;
				// foreach ( $nodes as $node ) {
				$return['post_category'][] = $element->textContent;
				// }
			}
		}

		// content
		$return['post_content'] = "";
		$post_content           = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_post_content'] ]
			)
		);
		if ( !empty( $post_content ) ) {
			$remove_end   = $this->config['adminz_import_content_remove_end'];
			$remove_first = $this->config['adminz_import_content_remove_first'];
			foreach ( $post_content as $element ) {
				$nodes = $element->childNodes;
				foreach ( $nodes as $key => $node ) {
					if ( $key <= ( count( $nodes ) - $remove_end - 1 ) and $key >= ( $remove_first ) ) {
						$return['post_content'] .= $doc->saveHTML( $node );
					}
				}
			}
		}

		$return = apply_filters( 'adminz_crawl_post_data', $return, $xpath, $this );
		return $return;
	}

	function get_product_data( $html = false ) {

		//start check
		$html = $html ? $html : $this->html;
		// echo $html; die;
		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $html );
		// $doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		$xpath  = new \DOMXpath( $doc );
		$return = [ 
			'product_title'   => '',
			'product_type'    => 'simple',
			'product_content' => '',
			'product_meta'    => [],
		];

		// title
		$product_title = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_product_title'] ]
			)
		);
		// echo "<pre>"; print_r($this->config['adminz_import_product_title']); echo "</pre>"; die;
		if ( !empty( $product_title ) ) {
			foreach ( $product_title as $element ) {
				$nodes = $element->childNodes;
				foreach ( $nodes as $node ) {
					$return['product_title'] = $node->nodeValue;
				}
			}
		}

		// price
		$check_price_simple = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_product_prices'] ]
			)
		);
		if ( !empty( $check_price_simple ) ) {
			foreach ( $check_price_simple as $element ) {
				$return['product_price'] = $this->fix_product_price( $element->textContent );
			}
		}

		// variation price
		$check_variations = $xpath->query(
			$this->get_xpath_query(
				[ '.variations_form' ]
			)
		);

		if ( count( $check_variations ) ) {
			$return['product_type'] = 'variation';
			$json                   = ( $check_variations[0]->getAttribute( 'data-product_variations' ) ) ?? false;
			if ( $json ) {
				$return['product_variations'] = json_decode( $json );
			}
		}

		// group type
		$check_group = $xpath->query(
			$this->get_xpath_query(
				[ '.grouped_form' ]
			)
		);
		if ( count( $check_group ) ) {
			$return['product_type'] = 'grouped';
			// query all items product grouped

			$items = $xpath->query(
				$this->get_xpath_query(
					[ '.grouped_form', 'tr', 'a' ]
				)
			);
			if ( !empty( $items ) ) {
				$return['grouped_products'] = [];
				foreach ( $items as $key => $item ) {
					if ( !$item->getAttribute( 'aria-label' ) ) {
						$return['grouped_products'][] = array(
							'title' => $item->textContent,
							'url'   => $item->getAttribute( 'href' ),
						);
					}
				}
			}
		}

		// gallery
		$gallery = $xpath->query(
			$this->get_xpath_query(
				[ 
					$this->config['adminz_import_product_gallery_children_item'],
					'img',
				]
			)
		);
		if ( !empty( $gallery ) ) {
			foreach ( $gallery as $element ) {
				// $nodes = $element->childNodes;
				// foreach ( $nodes as $node ) {
				$return['product_gallery'][] = $this->get_image_src( $element );
				// }
			}
		}

		// short content
		$product_short_description       = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_product_short_description'] ]
			)
		);
		$return['product_short_content'] = '';
		if ( !empty( $product_short_description ) ) {
			foreach ( $product_short_description as $element ) {
				$return['product_short_content'] = $element->textContent;
			}
		}

		// content		
		$product_content = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_product_content'] ]
			)
		);
		if ( !empty( $product_content ) ) {
			$remove_end   = $this->config['adminz_import_content_remove_end'];
			$remove_first = $this->config['adminz_import_content_remove_first'];
			foreach ( $product_content as $element ) {
				$nodes = $element->childNodes;
				foreach ( $nodes as $key => $node ) {
					if ( $key <= ( count( $nodes ) - $remove_end - 1 ) and $key >= ( $remove_first ) ) {
						$return['product_content'] .= $doc->saveHTML( $node );
					}
				}
			}
		}

		// 
		$return['product_meta'] = [];
		$return                 = apply_filters( 'adminz_crawl_product_data', $return, $xpath, $doc, $this );
		return $return;
	}

	function prepare_product_data( $product, $data ) {
		$product->set_name( $data['product_title'] ?? false );
		$product->set_regular_price( $data['product_price'] ?? false );

		// Prepare content
		$data['product_content'] = $this->prepare_thumbnail_content( $data['product_content'] ?? '' );
		// echo "<pre>"; print_r($data); echo "</pre>"; die;

		$images = [];

		// Gallery Images
		if ( !empty( $data['product_gallery'] ) ) {
			foreach ( $data['product_gallery'] as $index => $image_url ) {
				$image_id = $this->save_image( $image_url );
				if ( $image_id ) {
					$images[] = $image_id;
				}
			}
		}

		// Đặt ảnh thumbnail, lấy ảnh đầu tiên từ gallery (nếu có)
		if ( !empty( $images ) ) {
			// Lấy ảnh đầu tiên làm thumbnail và xóa khỏi gallery
			$image_id = array_shift( $images );
			$product->set_image_id( $image_id );
		}

		// Gán các ảnh còn lại vào gallery
		if ( !empty( $images ) ) {
			$product->set_gallery_image_ids( $images );
		}

		$product->set_description( $data['product_content'] ?? '' );
		$product->set_short_description( $data['product_short_content'] ?? '' );
		$product->set_status( 'publish' );

		// Meta
		foreach ( (array) $data['product_meta'] as $key => $value ) {
			$product->update_meta_data( $key, $value );
		}

		$product->save();
		return $product;
	}

	// ----------- Check functions
	function check_adminz_import_from_post() {
		return $this->report_check_single( $this->get_post_data() );
	}

	function check_adminz_import_from_category() {
		//start check
		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $this->html );
		libxml_clear_errors();
		$xpath  = new \DOMXpath( $doc );
		$return = [];

		// posts
		$posts = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_category_post_item'] ]
			)
		);
		if ( !empty( $posts ) ) {
			$seenUrls = [];
			foreach ( $posts as $key => $element ) {
				$item = [ 
					'preview' => preg_replace( '/\s+/', ' ', $element->textContent ),
					'url'     => false,
				];

				$links = $xpath->query(
					$this->get_xpath_query(
						[ $this->config['adminz_import_category_post_item_link'] ]
					),
					$element
				);
				foreach ( $links as $child ) {
					if ( $child->textContent and trim( $child->textContent ) ) {
						if ( $href = $this->fix_href( $child->getAttribute( 'href' ) ) ) {
							$item['url'] = $href;
						}
					}
				}

				if ( $item['url'] && !isset( $seenUrls[ $item['url'] ] ) ) {
					$return[]                 = $item;
					$seenUrls[ $item['url'] ] = true;
				}
			}
		}

		return $this->report_list( $return );
	}

	function check_adminz_import_from_product() {
		return $this->report_check_single( $this->get_product_data() );
	}

	function check_adminz_import_from_product_category() {

		//start check
		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $this->html );
		libxml_clear_errors();
		$xpath  = new \DOMXpath( $doc );
		$return = [];

		// posts
		$posts = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['adminz_import_category_product_item'] ]
			)
		);

		if ( !empty( $posts ) ) {
			$seenUrls = [];
			foreach ( $posts as $key => $element ) {
				$item = [];
				$item = [ 
					'preview' => preg_replace( '/\s+/', ' ', $element->textContent ),
					'url'     => false,
				];

				$links = $xpath->query(
					$this->get_xpath_query(
						[ $this->config['adminz_import_category_product_item_link'] ]
					),
					$element
				);

				// lấy ra item có href hợp lệ cuối cùng. 
				foreach ( $links as $child ) {
					if ( $href = $this->fix_href( $child->getAttribute( 'href' ) ) ) {
						$item['url'] = $href;
					}
				}

				if ( $item['url'] && !isset( $seenUrls[ $item['url'] ] ) ) {
					$return[]                 = $item;
					$seenUrls[ $item['url'] ] = true;
				}
			}
		}

		if ( $this->is_cron ) {
			$this->cron_list( $return );
			return;
		}

		// echo "<pre>"; print_r( $return ); echo "</pre>"; die;
		return $this->report_list( $return );
	}

	function check_adminz_import_images() {

		//start check
		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $this->html );
		libxml_clear_errors();
		$xpath  = new \DOMXpath( $doc );
		$return = [];

		// posts
		$images = $xpath->query(
			$this->get_xpath_query(
				[ $this->config['images_selector'] ]
			)
		);

		if ( !empty( $images ) ) {
			// Sử dụng mảng kết hợp để theo dõi các URL đã gặp
			$seenUrls = [];

			foreach ( $images as $key => $element ) {
				$link = $element->getAttribute( $this->config['images_selector_src'] );
				$link = $this->fix_href( $link );
				if ( $link && !isset( $seenUrls[ $link ] ) ) {
					$return[]          = [ 
						'preview' => $link,
						'url'     => $link,
					];
					$seenUrls[ $link ] = true;
				}
			}
		}

		return $this->report_list( $return );
	}

	// ----------- Run functions
	function run_adminz_import_from_category() {
		return $this->check_adminz_import_from_category();
	}

	function run_adminz_import_from_product_category() {
		return $this->check_adminz_import_from_product_category();
	}

	function run_adminz_import_images() {
		return $this->check_adminz_import_images();
	}

	function run_adminz_import_from_post() {
		if ( !$this->is_enable_cron_log() ) {
			return 'Enable cron log first!';
		}
		$this->crawl_data = $this->get_post_data();
		$post_id          = $this->crawl_post();
		$this->after_import( $post_id );
		$note = $this->post_exists_on_wpposts ? '[exists_on_wpposts]' : '[new]';
		return $this->report_run_single( $post_id, $note );
	}

	function run_adminz_import_from_product() {
		if ( !$this->is_enable_cron_log() ) {
			return 'Enable cron log first!';
		}
		$this->crawl_data = $this->get_product_data();
		$post_id          = $this->crawl_product();
		$this->after_import( $post_id );
		$note = $this->post_exists_on_wpposts ? '[exists_on_wpposts]' : '[new]';
		return $this->report_run_single( $post_id, $note );
	}

	function run_adminz_import_image() {
		if ( !$this->is_enable_cron_log() ) {
			return 'Enable cron log first!';
		}
		$post_id = $this->save_image( $this->url, $this->html );
		$this->after_import( $post_id );
		$note = $this->post_exists_on_wpposts ? ' (post_exists_on_wpposts)' : '[new]';
		return $this->report_run_single( $post_id, $note );
	}

	function get_xpath_query( $selectors = false ) {
		$selectors = is_array( $selectors ) ? implode( " ", $selectors ) : $selectors;
		return new \Adminz\Helper\Xpathtranslator( $selectors );
	}

	function maybe_load_cached( $url ) {
		if ( $this->is_run_on_list() ) {
			$transient_key = 'adminz_crawl_list_' . md5( serialize( $url ) );
			if ( false !== ( $cached_data = get_transient( $transient_key ) ) ) {
				return $cached_data;
			}
		}
		return;
	}

	function maybe_cache_response( $url, $response ) {
		if ( $this->is_run_on_list() ) {
			$transient_key = 'adminz_crawl_list_' . md5( serialize( $url ) );
			set_transient( $transient_key, $response, $this->transient_time );
		}
	}

	function maybe_load_html( $url = false, $encode = true ) {
		$url = $url ? $url : $this->url;
		if ( !$url ) {
			echo 'No URL found';
			die();
		}

		// kiểm tra trong transient
		if ( $cached = $this->maybe_load_cached( $url ) ) {
			return $cached;
		}

		// start curl
		error_log( "LOAD HTML" . ( $this->is_cron ? " CRON" : "" ) . ": $url" );
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); // Theo dõi chuyển hướng
		curl_setopt( $ch, CURLOPT_ENCODING, "" ); // Xử lý nén tự động
		curl_setopt( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3' ); // Giả lập trình duyệt

		$response = curl_exec( $ch );
		if ( $response === false ) {
			$error = "Curl error: " . curl_error( $ch );
			curl_close( $ch );
			echo $error;
			die();
		}

		// Lấy thông tin về mã hóa từ header
		$contentType = curl_getinfo( $ch, CURLINFO_CONTENT_TYPE );
		curl_close( $ch );

		// Xác định mã hóa từ Content-Type header
		$charset = 'UTF-8'; // Mặc định
		if ( preg_match( '/charset=([\w-]+)/i', $contentType, $matches ) ) {
			$charset = strtoupper( $matches[1] );
		}

		// Chuyển đổi mã hóa nếu cần
		if ( $encode ) {
			$response = @mb_convert_encoding( $response, 'HTML-ENTITIES', $charset );
		}

		// Tìm kiếm và thay thế
		$search   = explode( "\r\n", $this->config['adminz_import_content_replace_from'] ?? '' );
		$replace  = explode( "\r\n", $this->config['adminz_import_content_replace_to'] ?? '' );
		$response = str_replace( $search, $replace, $response );

		// lưu lại 
		$this->maybe_cache_response( $url, $response );


		return $response;
	}

	function prepare_thumbnail_content( $html ) {
		if ( !$html ) {
			return '';
		}

		$html = @mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' );
		// $html = htmlentities( $html, ENT_QUOTES, 'UTF-8' );
		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( $html );

		libxml_clear_errors();
		$xpath = new \DOMXpath( $doc );

		// Remove href from all <a> tags
		foreach ( explode( ",", $this->config['adminz_import_content_remove_attrs'] ) as $key => $tag ) {
			$links = $xpath->query( "//{$tag}" );
			if ( !empty( $links ) ) {
				foreach ( $links as $link ) {
					while ( $link->attributes->length ) {
						$link->removeAttribute( $link->attributes->item( 0 )->name );
					}
				}
			}
		}

		// Xóa thẻ <iframe>, <script>, <video>, <audio>
		$tags_to_remove = explode( ",", $this->config['adminz_import_content_remove_tags'] );
		foreach ( $tags_to_remove as $tag ) {
			$nodes = $xpath->query( "//{$tag}" );
			if ( !empty( $nodes ) ) {
				foreach ( $nodes as $node ) {
					$node->parentNode->removeChild( $node );
				}
			}
		}

		// Remove first and last specified number of DOM elements
		$body = $doc->getElementsByTagName( 'body' )->item( 0 );
		if ( $body ) {
			$children = [];
			foreach ( $body->childNodes as $child ) {
				if ( $child->nodeType === XML_ELEMENT_NODE || $child->nodeType === XML_TEXT_NODE ) {
					$children[] = $child;
				}
			}

			// Remove the first specified number of elements
			for ( $i = 0; $i < $this->config['adminz_import_content_remove_first'] && $i < count( $children ); $i++ ) {
				$body->removeChild( $children[ $i ] );
			}

			// Remove the last specified number of elements
			for ( $i = 0; $i < $this->config['adminz_import_content_remove_end'] && count( $children ) - $i - 1 >= 0; $i++ ) {
				$body->removeChild( $children[ count( $children ) - $i - 1 ] );
			}
		}

		// Handle images
		$images = $xpath->query( $this->get_xpath_query( [ 'img' ] ) );
		if ( !empty( $images ) ) {
			foreach ( $images as $key => $img ) {

				$src      = $this->get_image_src( $img );
				$image_id = $this->save_image( $src );
				if ( !is_wp_error( $image_id ) ) {
					$image_html = wp_get_attachment_image( $image_id, 'full', false, [ 'class' => 'adminz_crawl' ] );

					// Create a new DOMDocument to load image HTML
					$img_doc = new \DOMDocument();
					$img_doc->loadHTML( $image_html );
					$new_img = $img_doc->getElementsByTagName( 'img' )->item( 0 );

					// Replace old image with new image
					$imported_img = $doc->importNode( $new_img, true );
					$img->parentNode->replaceChild( $imported_img, $img );
				}
			}
		}

		$body         = $doc->getElementsByTagName( 'body' )->item( 0 );
		$updated_html = '';
		if ( $body ) {
			foreach ( $body->childNodes as $child ) {
				$updated_html .= $doc->saveHTML( $child );
			}
		}
		$updated_html = html_entity_decode( $updated_html, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return $updated_html;
	}

	function save_taxonomy( $data, $taxonomy = 'category' ) {
		$category_ids = array();

		foreach ( $data as $category_name ) {
			$category = get_term_by( 'name', $category_name, $taxonomy );
			if ( $category ) {
				$category_ids[] = (int) $category->term_id;
			}
			else {
				$new_category = wp_insert_term( $category_name, $taxonomy );
				if ( !is_wp_error( $new_category ) ) {
					$category_ids[] = (int) $new_category['term_id'];
				}
			}
		}

		return $category_ids;
	}

	function save_pdf( $pdf_url ) {
		$pdf_url = $this->fix_href( $pdf_url );

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Kiểm tra URL có hợp lệ không
		if ( empty( $pdf_url ) || !filter_var( $pdf_url, FILTER_VALIDATE_URL ) ) {
			// return new \WP_Error( 'invalid_url', __( 'URL không hợp lệ.', 'text-domain' ) );
			return;
		}

		// check exists
		global $wpdb;

		$query = $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type = 'application/pdf' AND post_title = %s LIMIT 1",
			pathinfo( $pdf_url, PATHINFO_FILENAME ) // Lấy tên file không có đuôi mở rộng
		);

		$existing_pdf_id = $wpdb->get_var( $query );
		if ( $existing_pdf_id ) {
			return $existing_pdf_id;
		}


		// Tải file về thư mục tạm thời của WordPress
		$tmp = download_url( $pdf_url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		// Lấy tên file từ URL
		$file_array             = [];
		$file_array['name']     = basename( parse_url( $pdf_url, PHP_URL_PATH ) );
		$file_array['tmp_name'] = $tmp;

		// Kiểm tra lỗi khi tải xuống
		if ( is_wp_error( $file_array['tmp_name'] ) ) {
			@unlink( $file_array['tmp_name'] ); // Xóa file tạm nếu có lỗi
			return $file_array['tmp_name'];
		}

		// Tải file vào thư viện media
		$attachment_id = media_handle_sideload( $file_array, 0 );

		// Xóa file tạm nếu có lỗi
		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $file_array['tmp_name'] );
			return $attachment_id;
		}

		return $attachment_id; // Trả về ID của file PDF đã tải
	}

	function save_image( $image_url, $image_data = false ) {
		$image_url = $this->fix_href( $image_url );

		// Check if file exists
		$filename            = basename( $image_url );
		$upload_dir          = wp_upload_dir();
		$existing_attachment = get_posts( array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'meta_query'  => array(
				array(
					'key'     => '_wp_attached_file',
					'value'   => ltrim( $upload_dir['subdir'] . '/' . $filename, '/' ),
					'compare' => 'LIKE',
				),
			),
		) );

		if ( !empty( $existing_attachment ) ) {
			$attach_id            = $existing_attachment[0]->ID;
			$this->images_saved[] = $attach_id;
			return $attach_id;
		}

		// error_log( "SAVE IMAGE: $image_url" );

		// Check if the image URL is accessible
		$response = wp_remote_get( $image_url );
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			error_log( "Image URL not accessible: $image_url" );
			// return new \WP_Error( 'image_url_not_accessible', 'Image URL is not accessible.' );
			return;
		}

		// Get HTML and import to library
		if ( !$image_data ) {
			$image_data = $this->maybe_load_html( $image_url, false );
			if ( $image_data === false ) {
				// return new \WP_Error( 'image_fetch_failed', 'Failed to fetch image.' );
				return;
			}
		}

		$upload_dir = wp_upload_dir();
		$temp_file  = $upload_dir['path'] . '/' . $filename;
		file_put_contents( $temp_file, $image_data );
		if ( !file_exists( $temp_file ) ) {
			// return new \WP_Error( 'file_save_failed', 'Failed to save image.' );
			return;
		}
		$file_type  = wp_check_filetype( $filename, null );
		$guid       = $upload_dir['url'] . '/' . basename( $filename );
		$attachment = array(
			'guid'           => $upload_dir['url'] . '/' . basename( $filename ),
			'post_mime_type' => $file_type['type'],
			'post_title'     => sanitize_file_name( $filename ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$attach_id  = wp_insert_attachment( $attachment, $temp_file );
		if ( !is_wp_error( $attach_id ) ) {
			$this->images_saved[] = $attach_id;
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
			$attach_data = wp_generate_attachment_metadata( $attach_id, $temp_file );
			wp_update_attachment_metadata( $attach_id, $attach_data );
			$this->save_log( $attach_id, 'done', $image_url, $this->url_from );
			return $attach_id;
		}

		return false;
	}

	// OTHER --------------------------------------------
	function create_attribute_tag_if_not_exists( $attribute_value, $attribute_name ) {
		$taxonomy = 'pa_' . $attribute_name;
		if ( !term_exists( $attribute_value, $taxonomy ) ) {
			wp_insert_term( $attribute_value, 'pa_' . $attribute_name );
		}
	}

	function create_attribute_if_not_exists( $attribute_name, $type = 'select' ) {
		$attribute_id = wc_attribute_taxonomy_id_by_name( $attribute_name );
		if ( !$attribute_id ) {
			// Remove 'pa_' prefix and convert to uppercase
			$label = strtoupper( str_replace( 'pa_', '', $attribute_name ) );

			$attribute_id = wc_create_attribute( [ 
				'name'         => $label,
				'slug'         => $attribute_name,
				'type'         => $type,
				'order_by'     => 'menu_order',
				'has_archives' => false,
			] );
		}

		return $attribute_id;
	}

	function get_image_src( $image ) {
		$src = $image->getAttribute( 'src' );
		if ( $image->hasAttribute( 'data-src' ) ) {
			$src = $image->getAttribute( 'data-src' );
		}

		// Loại bỏ tham số URL
		$parsed_url = parse_url( $src );
		return $parsed_url['scheme'] . '://' . $parsed_url['host'] . $parsed_url['path'];
	}

	// make sure url is correct
	function fix_href( $href ) {
		$base_url = $this->url;

		// Nếu $href là null hoặc rỗng
		if ( empty( $href ) ) {
			return false;
		}

		$href = str_replace( ' ', '', $href );

		// Sử dụng regex để kiểm tra các trường hợp đặc biệt
		if ( preg_match( '/^(#|\?|javascript:|mailto:|tel:|data:)/', $href ) ) {
			return false;
		}

		// Phân tích URL gốc
		$parsed_base_url = parse_url( $base_url );
		if ( !isset( $parsed_base_url['scheme'] ) || !isset( $parsed_base_url['host'] ) ) {
			return false; // Base URL không hợp lệ
		}

		// Phân tích URL cần sửa
		$parsed_href = parse_url( $href );

		// Nếu URL đã có scheme và host
		if ( isset( $parsed_href['scheme'] ) && isset( $parsed_href['host'] ) ) {
			// Chỉ chấp nhận scheme HTTP/HTTPS
			if ( !in_array( $parsed_href['scheme'], [ 'http', 'https' ] ) ) {
				return false;
			}
			// Loại bỏ query string
			$fixed_url = $parsed_href['scheme'] . '://' . $parsed_href['host'] . ( isset( $parsed_href['path'] ) ? $parsed_href['path'] : '' );
			return $fixed_url;
		}

		// Nếu URL bắt đầu bằng '//', thêm scheme từ base URL
		if ( strpos( $href, '//' ) === 0 ) {
			$fixed_url    = $parsed_base_url['scheme'] . ':' . $href;
			$parsed_fixed = parse_url( $fixed_url );
			return $parsed_fixed['scheme'] . '://' . $parsed_fixed['host'] . ( isset( $parsed_fixed['path'] ) ? $parsed_fixed['path'] : '' );
		}

		// Nếu URL bắt đầu bằng '/', thêm scheme và host từ base URL
		if ( strpos( $href, '/' ) === 0 ) {
			return $parsed_base_url['scheme'] . '://' . $parsed_base_url['host'] . $href;
		}

		// Nếu URL là tương đối, thêm scheme, host và path từ base URL
		$fixed_url    = $parsed_base_url['scheme'] . '://' . $parsed_base_url['host'] . '/' . ltrim( $href, '/' );
		$parsed_fixed = parse_url( $fixed_url );

		return $parsed_fixed['scheme'] . '://' . $parsed_fixed['host'] . ( isset( $parsed_fixed['path'] ) ? $parsed_fixed['path'] : '' );
	}

	function fix_product_price( $price ) {
		$price = preg_replace( '/\D/', '', $price );
		// fix for decima
		return (int) $price / pow( 10, (int) $this->config['product_price_decimal_seprator'] );
	}

	function report_check_single( $return ) {
		if ( $this->return_type == 'ID' ) {
			return $return;
		}
		if ( $this->return_type == 'array' ) {
			return $return;
		}
		ob_start();
		?>
		<table class="adminz_table">
			<?php
			foreach ( $return as $key => $value ) {
				?>
				<tr>
					<td>
						<?= esc_attr( $key ) ?>
					</td>
					<td>
						<?php
						if ( is_array( $value ) ) {
							echo "<pre>";
							print_r( $value );
							echo "</pre>";
						}
						else {
							echo wp_kses_post( $value );
						}
						?>
					</td>
				</tr>
				<?php
			}
			?>
		</table>
		<?php
		return ob_get_clean();
	}

	function report_run_single( $post_id, $context = '' ) {

		if ( !get_the_title( $post_id ) ) {
			return 'Post not exists!';
		}

		if ( $this->return_type == 'ID' ) {
			return $post_id;
		}
		if ( $this->return_type == 'json' ) {
			return json_encode( [ $this->url => get_permalink( $post_id ) ] ) . "\r\n";
		}
		ob_start();
		?>
		<a href="<?= get_permalink( $post_id ) ?>" target="_blank">
			<?= esc_attr( $context ) ?>
			<?= get_the_title( $post_id ) ?>
		</a>
		<?php
		return ob_get_clean();
	}

	function cron_list( $return ) {
		$ran = 1;
		ob_start();
		foreach ( $return as $key => $value ) {
			$url      = $value['url'];
			$url_from = '[' . $this->cron_data['fixed_term'] . ']' . $this->url;
			$action   = '';

			// khi kết thức vòng lặp cho 1 category thì out luôn foreach
			if ( $key == ( count( $return ) - 1 ) ) {
				$items = ( $key + 1 );
				$this->save_log( '', 'done', $this->url, $url_from );
				echo "::: CRON DONE WITH $items items and saved log, URL from: $url_from \r\n";
				echo ob_get_clean();
				break;
			}

			// nếu chưa kết thúc nhưng url đã chưa cron thì nhảy sang item tiếp theo
			if ( $this->is_cron_single_done( $url ) ) {
				continue;
			}

			// nếu chưa cron thì crawl nó
			switch ( $this->action ) {
				case 'run_adminz_import_from_category':
					$action = 'run_adminz_import_from_post';
					break;
				case 'run_adminz_import_from_product_category':
					$action = 'run_adminz_import_from_product';
					break;
			}

			$_Crawl = new self();
			$_Crawl->set_return_type( 'json' );
			$_Crawl->set_config();
			$_Crawl->set_action( $action );
			$_Crawl->set_url( $url );
			$_Crawl->set_return_type( 'json' );
			$_Crawl->url_from    = $url_from;
			$_Crawl->is_cron     = $this->is_cron; // assign luôn khỏi phải truyền sang. 
			$_Crawl->fixed_terms = $this->fixed_terms; // assign luôn khỏi phải truyền sang. 
			echo $_Crawl->run();


			// kiểm tra chỉ chạy 1 lần trong cron
			if ( $ran >= ( $this->config['crawl_items_per_time'] ?? 1 ) ) {
				break;
			}

			$ran++;
		}

		echo ob_get_clean();
	}

	function report_list( $return ) {
		if ( $this->return_type == 'ID' ) {
			return $return;
		}
		if ( $this->return_type == 'json' ) {
			$json = '';

			// $ran = 0;
			foreach ( $return as $key => $value ) {

				// change action and url and call again
				$url    = $value['url'];
				$action = '';
				switch ( $this->action ) {
					case 'run_adminz_import_from_category':
						$action = 'run_adminz_import_from_post';
						break;
					case 'run_adminz_import_from_product_category':
						$action = 'run_adminz_import_from_product';
						break;
				}

				// kiểm tra đã có trong log chưa thì trả lại view luôn
				$post_id = $this->post_exists_on_logs( $url, $action );
				if ( $post_id ) {
					continue;
				}


				$_Crawl = new self();
				$_Crawl->set_return_type( 'json' );
				$_Crawl->set_config();
				$_Crawl->set_action( $action );
				$_Crawl->set_url( $url );
				$_Crawl->is_cron     = $this->is_cron; // assign luôn khỏi phải truyền sang. 
				$_Crawl->fixed_terms = $this->fixed_terms; // assign luôn khỏi phải truyền sang. 
				$json .= $_Crawl->run();
			}
			return $json;
		}

		// output
		ob_start();
		?>
		<table class="adminz_table">
			<?php
			foreach ( $return as $key => $item ) {
				?>
				<tr data-url="<?= $item['url'] ?>">
					<td><?= $key + 1 ?></td>
					<td class="result"><?= $item['preview'] ?></td>
					<td><a target="blank" href="<?= $item['url'] ?>">Link</a></td>
					<td><button type="button" class="button run">Run</button></td>
				</tr>
				<?php
			}
			?>
		</table>
		<?php
		return ob_get_clean();
	}

	function set_post_fixed_terms( $post_id ) {
		$fixed_terms = $this->config['fixed_terms'];
		if ( !empty( $this->fixed_terms ) ) {
			$fixed_terms = $this->fixed_terms;
		}

		foreach ( (array) $fixed_terms as $key => $term_id ) {
			adminz_add_post_term( $post_id, $term_id );
		}
	}

	function after_import( $post_id ) {
		// 
		$this->save_log( $post_id, 'done', $this->url, $this->url_from );
		// 
		$this->set_post_fixed_terms( $post_id );
	}

	public $table_name = 'adminz_crawl_logs';
	function create_table_log() {
		global $wpdb;
		$args  = [ 
			'table_name' => $this->table_name,
			'menu_title' => 'Crawl logs',
			'fields'     => [ 
				'id INT(11) NOT NULL AUTO_INCREMENT,',
				'post_id INT(11) NULL,',
				'url varchar(255) NULL,',
				'url_from varchar(255) NULL,',
				'action varchar(255) NULL,',
				'status varchar(255) NULL,',
				'type varchar(255) NULL,',
				'date datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,',
				'PRIMARY KEY (id)',
			],
		];
		$table = \WpDatabaseHelper\Init::WpDatabase();
		$table->init_table( $args );

		// show post_id on table log
		add_filter( "{$wpdb->prefix}{$this->table_name}_post_id", function ($_value) {
			if ( !$_value ) {
				return;
			}

			$post_title = get_the_title( $_value );
			$post_type  = get_post_type( $_value );

			if ( $post_title ) {
				return "<a href=\"" . get_edit_post_link( $_value ) . "\">[$post_type] $post_title</a>";
			}
			else {
				return 'Post not exists';
			}
		}, 10, 1 );

	}

	function delete_table_log() {
		add_action( 'init', function () {
			if ( current_user_can( 'administrator' ) ) {
				global $wpdb;
				require_once( ABSPATH . 'wp-includes/pluggable.php' );
				$table_name      = $wpdb->prefix . $this->table_name;
				$table_name_safe = esc_sql( $table_name );
				$sql             = "DROP TABLE IF EXISTS `{$table_name_safe}`";
				$wpdb->query( $sql );
				die( 'done' );
			}
		} );
	}

	function save_log( $post_id, $status, $url, $url_from ) {
		global $wpdb;

		$data = [ 
			"post_id"  => $post_id,
			'status'   => $status,
			"url"      => $url,
			'url_from' => $url_from,
			"type"     => $this->is_cron ? 'cron' : '',
			"action"   => $this->action,
		];

		$table_name = $wpdb->prefix . $this->table_name;
		$wpdb->insert( $table_name, $data );
	}

	function post_exists_on_logs( $url, $action ) {
		// return 36139;
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( !$this->is_enable_cron_log() ) {
			return false;
		}

		$query = $wpdb->prepare(
			"SELECT post_id FROM $table_name WHERE url = %s AND action = %s ORDER BY id DESC LIMIT 1",
			$url,
			$action
		);

		$post_id = $wpdb->get_var( $query );

		// chỉ return nếu post chưa bị xoá.
		if ( get_post_status( $post_id ) ) {
			return $post_id;
		}

	}

	function post_exists_on_wpposts( $title, $post_type ) {

		// Check if a post with the same sanitized title already exists
		if ( ( $this->config['post_exists_on_wpposts'] ?? '' ) == 'on' ) {
			$sanitized_title = sanitize_title( $title );
			$existing_post   = get_page_by_path( $sanitized_title, OBJECT, $post_type );
			if ( $existing_post ) {
				return $existing_post->ID;
			}
		}

		return false;
	}

	// ----------------------
	function is_enable_cron_log() {
		return ( $this->config['enable_craw_log'] ?? '' ) == 'on';
	}

	function is_run_on_list() {
		$actions = [ 
			'check_adminz_import_from_category',
			'run_adminz_import_from_category',
			'check_adminz_import_from_product_category',
			'run_adminz_import_from_product_category',
			'check_adminz_import_images',
			'run_adminz_import_images',
		];

		if ( in_array( $this->action, $actions ) ) {
			return true;
		}
		return false;

	}

	function is_cron_category_done( $url, $fixed_term, $action ) {
		$fixed_term = (array) $fixed_term;
		$fixed_term = array_map( 'intval', $fixed_term );
		$prefix     = json_encode( $fixed_term ); // [811]
		$url_from   = $prefix . $url;
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;
		$query      = $wpdb->prepare(
			"
			SELECT COUNT(*) FROM $table_name 
			WHERE 
			url_from = %s AND 
			type = %s AND 
			status = %s AND 
			action = %s
			",
			$url_from, 'cron', 'done', $action
		);
		$count      = $wpdb->get_var( $query );
		// var_dump( $count ); die;
		return $count > 0;
	}

	function is_cron_single_done( $url ) {
		global $wpdb;
		$url_from   = '[' . $this->cron_data['fixed_term'] . ']' . $this->url;
		$table_name = $wpdb->prefix . $this->table_name;
		$query      = $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE url = %s AND type = %s AND status = %s AND url_from = %s",
			$url, 'cron', 'done', $url_from
		);
		$count      = $wpdb->get_var( $query );
		return $count > 0;
	}
}