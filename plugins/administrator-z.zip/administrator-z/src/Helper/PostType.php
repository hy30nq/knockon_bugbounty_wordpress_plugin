<?php
namespace Adminz\Helper;

class PostType {
	public $admin_column_key;

	function __construct() {

	}

	function init_thumbnail( $post_type ) {
		if ( $post_type ) {

			// prepare
			$this->admin_column_key = "adminz_{$post_type}_post_id";

			// Add columns and custom content for admin
			add_filter( "manage_{$post_type}_posts_columns", function ($columns) {
				$new_columns = array();
				foreach ( $columns as $key => $value ) {
					if ( $key == 'title' ) {
						$new_columns[ $this->admin_column_key ] = '<span class="dashicons dashicons-format-image"></span>';
					}
					$new_columns[ $key ] = $value;
				}
				return $new_columns;
			} );
			add_action( "manage_{$post_type}_posts_custom_column", function ($column, $post_id) {
				if ( $column === $this->admin_column_key ) {
					$thumbnail = get_the_post_thumbnail( $post_id, 'thumbnail', [ 'style' => 'width: 50px; height: 50px;' ] );
					if ( $thumbnail ) {
						echo $thumbnail;
					}
				}
			}, 10, 2 );
		}
	}

	function init_meta_key_column( $post_type, $meta_key ) {
		if ( $post_type and $meta_key ) {
			$args = [ 
				'post_type'          => $post_type,
				'meta_fields'        => [ 
					[ 
						'meta_key'  => $meta_key,
						'label'     => ucwords( str_replace( '_', ' ', preg_replace( '/[^a-zA-Z0-9_]/', '', $meta_key ) ) ),
						'attribute' => [ 
							'type' => 'text',
						],
					],
				],
				'admin_post_columns' => true,
			];
			$meta = \WpDatabaseHelper\Init::WpMeta();
			$meta->init( $args );
			$meta->init_admin_columns();
		}
	}
}