<?php
namespace Adminz\Helper;

class TermTaxonomy {

	function __construct() {
		//
	}

	function init_meta_key_column( $taxonomy, $meta_key ) {
		if ( $taxonomy and $meta_key ) {
			$args = [ 
				'taxonomy'             => $taxonomy,
				'taxonomy_meta_fields' => [ 
					[ 
						'meta_key'  => $meta_key,
						'label'     => ucwords( str_replace( '_', ' ', preg_replace( '/[^a-zA-Z0-9_]/', '', $meta_key ) ) ),
						'attribute' => [ 
							'type' => 'text',
						],
					],
				],
                'taxonomy_admin_columns'   => true,
			];
			$meta = \WpDatabaseHelper\Init::WpMeta();
			$meta->init( $args );
			$meta->init_admin_term_taxonomy_columns();
		}
	}

	public $metakey;
	public $admin_column_key;
	function init_thumbnail( $taxonomy, $metakey = 'thumbnail_id' ) {
		if ( $taxonomy ) {

			// prepare
			$this->metakey          = $metakey;
			$this->admin_column_key = "adminz_{$taxonomy}_post_id";

			// input
			add_action( $taxonomy . '_add_form_fields', [ $this, 'thumbnail_field_in_add_term' ] );
			add_action( $taxonomy . '_edit_form_fields', [ $this, 'thumbnail_field_in_edit_term' ] );

			// Admin term columns
			add_filter( 'manage_edit-' . $taxonomy . '_columns', [ $this, 'add_term_admin_column' ] );
			add_filter( 'manage_' . $taxonomy . '_custom_column', [ $this, 'add_term_admin_column_value' ], 10, 3 );

			// save if have $_POST
			add_action( 'edit_' . $taxonomy, [ $this, 'save_term_thumbnail_image' ], 10, 1 );
			add_action( 'create_' . $taxonomy, [ $this, 'save_term_thumbnail_image' ], 10, 1 );
		}
	}

	function add_term_admin_column( $columns ) {
		$new_columns = array();
		foreach ( $columns as $key => $value ) {
			if ( $key == 'name' ) {
				$new_columns[ $this->admin_column_key ] = _x( 'Featured image', 'page' );
			}
			$new_columns[ $key ] = $value;
		}
		return $new_columns;
	}

	function add_term_admin_column_value( $content, $column_name, $term_id ) {
		if ( $column_name == $this->admin_column_key ) {
			if ( $thumbnail_id = get_term_meta( $term_id, $this->metakey, true ) ) {
				$content = wp_get_attachment_image(
					$thumbnail_id,
					'post-thumbnail',
					false,
					[ "style" => "width: 50px; height: 50px;" ]
				);
			}
			else {
				$content = "—";
			}
		}
		return $content;
	}

	function save_term_thumbnail_image( $term_id ) {
		if ( isset( $_POST['adminz_thumbnail_image'] ) ) {
			update_term_meta( $term_id, $this->metakey, sanitize_text_field( $_POST['adminz_thumbnail_image'] ) );
		}
	}

	function get_input_image_field( $term ) {
		$value = '';
		if ( $term->term_id ?? '' ) {
			$value = get_term_meta( $term->term_id, $this->metakey, true );
		}

		// field
		return adminz_field( [ 
			'field'     => 'input',
			'attribute' => [ 
				'type' => 'wp_media',
				'name' => 'adminz_thumbnail_image',
			],
			'value'     => $value,
		] );
	}

	function thumbnail_field_in_add_term( $taxonomy ) {
		$string = $this->get_input_image_field( $taxonomy );
		$label  = _x( 'Featured image', 'page' );
		echo <<<HTML
		<div class="form-field">
			<label for="">
				$label
			</label>
			$string
		</div>
		HTML;
	}

	function thumbnail_field_in_edit_term( $taxonomy ) {
		$string = $this->get_input_image_field( $taxonomy );
		$label  = _x( 'Featured image', 'page' );
		echo <<<HTML
		<tr class="form-field">
			<th scope="row" valign="top">
				$label
			</th>
			<td>
				$string
			</td>
		</tr>
		HTML;
	}
}