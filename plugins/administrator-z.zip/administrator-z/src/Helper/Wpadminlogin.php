<?php

namespace Adminz\Helper;

class Wpadminlogin {

    function __construct() {
    }

    function init_quiz() {
        $field = function () {
            $transient_key = 'adminz_quiz_' . md5($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
            $quiz_data = get_transient($transient_key);

            if ($quiz_data === false) {
                // Tạo câu hỏi mới nếu chưa có transient
                $num1 = rand(100, 999);
                $num2 = rand(10, 99);
                $operators = ['+', '-', '*', '^'];
                $operator = $operators[array_rand($operators)];

                switch ($operator) {
                    case '+':
                        $result = $num1 + $num2;
                        break;
                    case '-':
                        $result = $num1 - $num2;
                        break;
                    case '*':
                        $result = $num1 * $num2;
                        break;
                    case '^':
                        $num1 = rand(2, 9);
                        $num2 = rand(2, 4);
                        $result = pow($num1, $num2);
                        break;
                }

                // Lưu câu hỏi và kết quả vào transient
                $quiz_data = [
                    'question' => "$num1 $operator $num2",
                    'answer' => $result
                ];
                set_transient($transient_key, $quiz_data, 5 * MINUTE_IN_SECONDS); // Lưu 5 phút
            }

            // echo "<pre>"; print_r($quiz_data); echo "</pre>";
            $google_calc_link = "https://www.google.com/search?q=" . urlencode($quiz_data['question']);

            // Hiển thị câu hỏi
            echo <<<HTML
            <style>
                #adminz_quiz_login {
                    display: flex;
                    align-items: center;
                    padding: 10px;
                    border: .0625rem solid #8c8f94;
                    border-radius: 5px;
                    background-color: #d6d8d978;
                }
                #adminz_quiz_login strong {
                    width: 100%;
                    font-size:1.3em;
                    text-align: center;
                }
                #adminz_quiz_login input {
                    text-align: center;
                }
                #adminz_quiz_login_helper {
                    margin-bottom: 15px;
                }
            </style>
            <div id="adminz_quiz_login">
                <strong>{$quiz_data['question']} = ?</strong>
                <input type="text" name="quiz_answer" required>
            </div>
            <div id="adminz_quiz_login_helper">
                <small>
                    <a href="$google_calc_link" target="_blank">Search on Google</a>
                </small>
            </div>
            <input type="hidden" name="quiz_key" value="{$transient_key}">
            HTML;
        };

        add_action('login_form', $field);
        add_action('woocommerce_login_form', $field);

        add_filter('authenticate', function ($user, $username, $password) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                if (!isset($_POST['quiz_answer']) || !isset($_POST['quiz_key'])) {
                    return new \WP_Error('quiz_error', __('You need to answer the question before logging in.', 'administrator-z'));
                }

                $quiz_key = 'adminz_quiz_' . md5($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
                $quiz_data = get_transient($quiz_key);

                if ($quiz_data === false) {
                    return new \WP_Error('quiz_error', __('The quiz has expired. Please try again.', 'administrator-z'));
                }

                if (intval($_POST['quiz_answer']) !== $quiz_data['answer']) {
                    return new \WP_Error('quiz_error', __('The answer is incorrect. Please try again.', 'administrator-z'));
                }

                delete_transient($quiz_key);
            }

            return $user;
        }, 30, 3);
    }
}
