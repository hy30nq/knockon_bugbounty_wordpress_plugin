<?php
// hỗ trợ cho việc truyền từ $_POST vào cart item data, order item meta, và email

namespace Adminz\Helper;
class WoocommerceOrderItem {

	public $item_label;
	public $item_key;
	public $validate_text;

	function __construct() {

	}

	function setup( $args = [] ) {
		foreach ( (array) $args as $key => $value ) {
			if ( property_exists( $this, $key ) ) {
				$this->$key = $value;
			}
		}
	}

	function init() {
		$this->raw_woocommerce_add_cart_item_data();
		$this->display_woocommerce_get_item_data();
		$this->raw_woocommerce_checkout_create_order_line_item();
		$this->display_woocommerce_order_item_display_meta_key();
		$this->display_woocommerce_email_order_meta();
	}

	// raw: Thêm data vào mảng $cart_item_data khi add sản phẩm vào giỏ.
	function raw_woocommerce_add_cart_item_data() {
		add_filter( 'woocommerce_add_cart_item_data', function ($cart_item_data) {
			// luôn luôn truyền vào 
			$value                             = $_POST[ $this->item_key ] ?? '';
			$value                             = apply_filters(
				'WoocommerceOrderItem_raw',
				$value,
				$this->item_key,
				$cart_item_data
			);
			$cart_item_data[ $this->item_key ] = $value;
			return $cart_item_data;

		}, 10, 1 );
	}

	// display: Hiển thị data trên giao diện cart (trang giỏ hàng).
	function display_woocommerce_get_item_data() {
		add_filter( 'woocommerce_get_item_data', function ($item_data, $cart_item) {
			// echo "<pre>"; print_r($cart_item); echo "</pre>"; die;
			if ( $this->item_label ) {
				$value   = $cart_item[ $this->item_key ];
				$display = apply_filters(
					'WoocommerceOrderItem_display',
					$value,
					$this->item_key,
					$cart_item
				);
				if ( $display ) {
					$item_data[] = array(
						'key'     => $this->item_label,
						'value'   => $value,
						'display' => $display,
					);
				}

			}
			return $item_data;
		}, 10, 2 );
	}

	// raw: Lưu data từ cart vào order item meta.
	function raw_woocommerce_checkout_create_order_line_item() {
		add_action( 'woocommerce_checkout_create_order_line_item', function ($item, $cart_item_key, $values, $order) {
			if ( $this->item_label ) {
				$value = $values[ $this->item_key ];
				// $value bắt buộc phải có giá trị thì mới dc đưa vào order
				// và phải xử lý từ bước cart 
				$item->add_meta_data(
					$this->item_key,
					$value
				);
			}

		}, 10, 4 );
	}

	// display: Hiển thị data trong trang admin (mục chi tiết order), định dạng key và value để dễ đọc.
	function display_woocommerce_order_item_display_meta_key() {

		add_filter( 'woocommerce_order_item_display_meta_value', function ($value, $meta, $item) {
			if ( $meta->key === $this->item_key ) {
				return apply_filters(
					'WoocommerceOrderItem_display',
					$value,
					$this->item_key,
					$item
				);
			}
			return $value;
		}, 10, 3 );

		add_filter( 'woocommerce_order_item_display_meta_key', function ($display_key, $meta, $item) {
			if ( $meta->key === $this->item_key ) {
				$display_key = $this->item_label;
			}
			return $display_key;
		}, 10, 3 );
	}

	// display: Hiển thị data trong email.
	function display_woocommerce_email_order_meta() {

		add_action( 'woocommerce_email_order_meta', function ($order) {
			if ( $value = $order->get_meta( $this->item_key ) ) {
				echo $value;
			}
		}, 10, 1 );

		add_filter( 'woocommerce_email_order_meta_fields', function ($fields, $sent_to_admin, $order) {
			if ( $this->item_label ) {
				$value                     = $order->get_meta( $this->item_key );
				$fields[ $this->item_key ] = array(
					'label' => $this->item_label,
					'value' => $value,
				);
			}
			return $fields;
		}, 10, 3 );
	}

	// layout
	function init_cart_field() {
		// get form add to cart to loop item
		// add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_single_add_to_cart', 19 );

		// create field on single product
		add_action( 'woocommerce_before_add_to_cart_button', function () {
			?>
			<div class="">
				<label for="<?= esc_attr( $this->item_key ); ?>">
					<?= esc_attr( $this->item_label ) ?>
				</label>
				<input type="text" id="<?= esc_attr( $this->item_key ); ?>" name="<?= esc_attr( $this->item_key ); ?>"
					placeholder="<?= esc_attr( $this->item_label ) ?>" value="<?= esc_attr( $_POST[ $this->item_key ] ?? '' ) ?>"
					maxlength="15">
			</div>
			<?php
		} );


		add_action( 'woocommerce_add_to_cart_validation', function ($result, $product_id, $quantity) {
			$validate_text = $this->item_label . " is required!";
			if ( $this->validate_text ) {
				$validate_text = $this->validate_text;
			}

			if ( empty( $_REQUEST[ $this->item_key ] ) ) {
				wc_add_notice( $validate_text, 'error' );
				return false;
			}
			return $result;
		}, 10, 3 );
	}
}

// // custom line total
// add_action( 'woocommerce_before_calculate_totals', 'custom_price_refresh' );
// function custom_price_refresh( $cart ) {
// 	if ( is_admin() && !defined( 'DOING_AJAX' ) ) {
// 		return;
// 	}
// 	foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
// 		$product = $cart_item['data'];
// 		$product->set_price( 900 );
// 	}
// }



// $a             = new \Adminz\Helper\WoocommerceOrderItem;
// $a->item_label = $label;
// $a->item_key   = $key;
// $a->init();