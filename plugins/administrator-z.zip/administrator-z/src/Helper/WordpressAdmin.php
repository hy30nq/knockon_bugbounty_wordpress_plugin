<?php
namespace Adminz\Helper;

final class WordpressAdmin {

	public $field_group = 'test'; // = param 'page'
	public $page_title = 'Example';
	public $menu_title = 'Example';
	public $menu_slug = 'test';
	public $capability = 'manage_options';
	public $parent_slug = 'options-general.php';
	public $icon_url = 'dashicons-admin-generic';
	public $position = 99;

	function __construct() {

	}

	function add_submenu_page() {
		add_action( 'admin_menu', function () {
			add_submenu_page(
				$this->parent_slug,
				$this->page_title,
				$this->menu_title,
				$this->capability,
				$this->menu_slug,
				[ $this, 'callback' ],
			);
		} );
	}

	function add_menu_page() {
		add_action( 'admin_menu', function () {
			add_menu_page(
				$this->page_title,
				$this->menu_title,
				$this->capability,
				$this->menu_slug,
				[ $this, 'callback' ],
				'dashicons-admin-generic',
				$this->position
			);
		} );
	}

	function callback() {
		?>
		<div class="wrap adminz_wrap">
			<h2> <?= esc_attr( $this->page_title ) ?> </h2>
			<form method="post" action="options.php">
				<?php
				settings_fields( $this->field_group );
				do_settings_sections( $this->field_group );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}
}



// $page              = new \Adminz\Helper\WordpressAdmin();
// $page->field_group = $this->field_group;
// $page->page_title  = 'Crawl Options';
// $page->menu_title  = 'Crawl Options';
// $page->menu_slug   = 'crawl-options';
// $page->add_menu_page();


// add_action( 'admin_init', function () {

// 	// Thêm section
// 	$section_id = 'test_section_id';
// 	add_settings_section(
// 		$section_id,
// 		'Section Example',
// 		function () {
// 			echo '<p>Sed ut perspiciatis unde omnis iste natus...</p>';
// 		},
// 		$this->field_group
// 	);

// 	// Thêm 1 option và 1 field mới
// 	$option_name = 'test_field_1';
// 	register_setting( $this->field_group, $option_name );
// 	add_settings_field(
// 		wp_rand(),
// 		'Field Example 1',
// 		function () use ($option_name) {
// 			$value = get_option( $option_name );
// 			echo <<<HTML
// 					<input type="text" name="$option_name" value="$value">
// 					HTML;
// 		},
// 		$this->field_group,
// 		$section_id
// 	);

// 	// Thêm 1 option và 2 field mới
// 	$option_name = 'test_field_2';
// 	register_setting( $this->field_group, $option_name );
// 	add_settings_field(
// 		wp_rand(),
// 		'Field Example 2',
// 		function () use ($option_name) {
// 			$value = get_option( $option_name )['xxx'] ?? '';
// 			echo <<<HTML
// 					<input type="text" name="{$option_name}[xxx]" value="$value">
// 					HTML;
// 		},
// 		$this->field_group,
// 		$section_id
// 	);
// 	add_settings_field(
// 		wp_rand(),
// 		'Field Example 2.2',
// 		function () use ($option_name) {
// 			$value = get_option( $option_name )['yyy'] ?? '';
// 			echo <<<HTML
// 					<input type="text" name="{$option_name}[yyy]" value="$value">
// 					HTML;
// 		},
// 		$this->field_group,
// 		$section_id
// 	);
// } );