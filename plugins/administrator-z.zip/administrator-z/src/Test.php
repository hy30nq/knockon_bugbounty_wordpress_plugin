<?php 
namespace Adminz;
class Test {
    
    function __construct() {
        echo '<pre>'; print_r(9999); echo '</pre>';
        die;
    }
}