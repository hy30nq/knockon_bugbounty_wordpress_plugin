<?php
function adminz_is_woocommerce() {
	return class_exists( 'WooCommerce' );
}

// Ex: \wp-content\plugins\administrator-z\src\Widget\Adminz_Taxonomies.php
function adminz_term_count( $term, $taxonomy = '', $woo_tax_query = [], $woo_meta_query = [], $woo_date_query = []) {

	// Tạo một key duy nhất cho transient dựa trên term và query vars
	$transient_key  = 'adminz_term_count_' . md5( serialize( [ $term, $taxonomy, $woo_tax_query ] ) );
	$transient_time = 6 * HOUR_IN_SECONDS;

	// clear 
	if ( current_user_can( 'administrator' ) ) {
		delete_transient( $transient_key );
	}

	// Trả về dữ liệu đã lưu nếu tồn tại
	$cached_count = get_transient( $transient_key );
	if ( $cached_count !== false ) {
		return $cached_count;
	}

	// Kiểm tra và lấy term đúng
	$_term = adminz_get_term( $term, $taxonomy );

	if ( is_wp_error( $_term ) || !$_term ) {
		return 0;
	}

	$args = [ 
		'tax_query'      => $woo_tax_query,
		'meta_query'     => $woo_meta_query,
		'date_query'     => $woo_date_query,
		'posts_per_page' => -1,
		'nopaging'       => true,
	];

	// kiểm tra và xoá hết các taxonomy tồn tại trong tax_query
	foreach ( (array) $args['tax_query'] as $key => $condition ) {
		if ( ( $condition['taxonomy'] ?? '' ) == $_term->taxonomy ) {
			unset( $args['tax_query'][ $key ] );
		}
	}

	// thêm vào lại 1 lần nữa hoặc thêm mới
	$args['tax_query'][] = [ 
		'taxonomy'         => $_term->taxonomy,
		'terms'            => [ $_term->slug ],
		'field'            => 'slug',
		'operator'         => 'IN',
		'include_children' => 1,
	];

	$query      = new \WP_Query( $args );
	$post_count = $query->post_count;

	// Reset query
	wp_reset_postdata();

	// luôn luôn set transient
	set_transient( $transient_key, $post_count, $transient_time );

	return $post_count;
}

/**
 * Hỗ trợ lấy term từ nhiều kiểu đầu vào khác nhau.
 *
 * @param mixed  $term     Slug, term_id, hoặc đối tượng WP_Term.
 * @param string $taxonomy Taxonomy (nếu cần).
 * @return WP_Term|WP_Error
 */
function adminz_get_term( $term, $taxonomy = '' ) {
	if ( $term instanceof WP_Term ) {
		// Nếu $term là đối tượng WP_Term, trả về luôn
		return $term;
	}

	// Kiểm tra nếu $term là chuỗi số (ví dụ: "100")
	if ( is_string( $term ) && ctype_digit( $term ) ) {
		$term = (int) $term; // Chuyển đổi thành số nguyên
	}

	if ( is_int( $term ) ) {
		// Nếu $term là term_id
		return get_term( $term, $taxonomy );
	}

	if ( is_string( $term ) ) {

		if ( empty( $taxonomy ) ) {
			return new WP_Error( 'invalid_taxonomy', 'Taxonomy is requied!.' );
		}
		// Nếu $term là slug
		return get_term_by( 'slug', $term, $taxonomy );
	}

	return new WP_Error( 'invalid_term', 'Invalid term.' );
}