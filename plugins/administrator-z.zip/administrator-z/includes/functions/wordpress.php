<?php
function adminz_get_all_child_pages($parent_id) {
    $args = [
        'post_type'      => 'page',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'post_parent'    => $parent_id,
        'fields'         => 'ids'
    ];

    $child_pages = get_posts($args);

    foreach ($child_pages as $child_id) {
        $child_pages = array_merge($child_pages, adminz_get_all_child_pages($child_id));
    }

    return $child_pages;
}