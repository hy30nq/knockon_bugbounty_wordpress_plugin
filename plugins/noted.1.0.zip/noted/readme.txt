=== Noted! ===
Contributors: @skvandeusen
Tags: notes, admin, productivity
Requires at least: 5.3
Tested up to: 6.7
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple, lightweight, and user-friendly note-taking system within the WordPress admin.

== Description ==

Noted! is a user-friendly note-taking plugin that allows Admin users to create and manage notes directly in WordPress. 

https://youtu.be/w8L9smQBA6k

*Your Project Memory Bank*
Store project-specific notes, instructions, and reminders all in one place — no more searching through old emails or docs.

*Always One-Click Away*
Access Noted! from the front-end, back-end, or any screen — only visible to site administrators.

*Lightweight and Clutter-Free*
No over-the-top features or extras. Noted! is there when you need it and gone when you don’t.


== Installation ==

1. Upload the `noted` directory to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Access your notes via the Noted! button in the admin bar.

== Screenshots ==

1. Adding a new note
2. Viewing existing notes

== Changelog ==

= 1.0 =
* Initial release of the Noted! plugin.

== Frequently Asked Questions ==

= How do I add a note? =
To add a note, click on the Noted! button in the admin bar, fill in the title and description, and click "Add Note".

= Can I edit or delete a note? =
Yes! You can easily edit or delete any note by clicking on the respective action links.

== Upgrade Notice ==

= 1.0 =
Initial release.
