<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
} ?>

<h1 class="wps-title">
   <div class="wps-logo-img">
       <a href="https://www.wpserveur.net/?refwps=14&campaign=wpsbidouille" target="_blank">
           <img src="<?php echo WPS_BIDOUILLE_URL . 'assets/img/check-and-tools-logo-in-plugin.png'; ?>" alt="WPServeur" />
       </a>
   </div>
</h1>