( function($) {

	$( document ).ready(function () {

		$( '.typography-select' ).fontSelect();

	} );

} )( jQuery );