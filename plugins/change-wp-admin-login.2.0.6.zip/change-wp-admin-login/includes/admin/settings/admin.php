<?php
/**
 * Admin settings
 *
 * @package Change_WP_Admin_Login
 */

defined( 'ABSPATH' ) || die();

?>

<div id="aio-login__app">
    <aio-login-app></aio-login-app>
</div>
