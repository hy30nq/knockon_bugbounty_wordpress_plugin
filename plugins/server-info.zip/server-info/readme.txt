=== Server Info ===
Contributors: usmanaliqureshi
Tags: admin, dashboard, widget, server, info, PHP, version, operating system, wordpress, database
Requires at least: 4.9
Tested up to: 6.7.1
Stable tag: 5.0
Requires PHP: 7.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will show you very useful information about your hosting server such as PHP version, Server OS, Server IP etc.

== Description ==

This plugin will show you useful information about the hosting server you are using e.g. PHP version, MySQL version, Server OS, Server Protocol, Server IP and other useful information. You can use the information displayed by this plugin to update any settings which is crucial for your website performance and other aspects.

You will see the information about:

* PHP Version
* Operating System
* Server IP
* Server Hostname
* MySQL Version
* System Uptime
* Active Theme
* Active Plugins
* Database Name
* Database Username
* Database Hostname
* Database Charset
* Database Collate
* WordPress Debugging (Enabled/Disabled)
* WordPress Memory Limit

Please rate the Plugin if you find it useful, thanks.

== Installation ==

Instructions for installing the Server Info Plugin.

1. In your WordPress admin go to Plugins -> Add New.
2. Enter Server Info in the text box and click Search Plugins.
3. In the list of Plugins click Install Now next to the Server Info Plugin.
4. Once installed click to activate.
5. Now go to your WordPress dashboard and you will have a new menu option called Server Info.

== Frequently Asked Questions ==

= Does this plugin works with all major PHP versions? =

Yes, it works with all major PHP versions and I have tested it with PHP version 5.3, 5.4, 5.5, 5.6, 7.0, 7.1, 7.2 7.4, 8.0 and 8.1.

= Is Server Info Plugin GDPR compliant? =

Yes, absolutely.

== Screenshots ==

1. WordPress Dashboard Widget.

2. Separate Page for Detailed Server Information.

== Changelog ==

### 0.0.1
* Plugin Core Restructured Completely