<?php
/*
Plugin Name: ACF Admin Flexible Content Collapse
Plugin URI:  https://wordpress.org/plugins/acf-admin-flexible-content-collapse/
Description: Make Flexible Content field layouts collapsible in the field group editor.
Version: 1.3.2
Author: Thomas Meyer
Author URI: https://dreihochzwo.de
Text Domain: acf-admin-flex-collapse
Domain Path: /languages
License: GPLv2 or later.
Copyright: Thomas Meyer
*/

// exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

// check if class already exists
if( !class_exists('DHZ_ACF_ADMIN_FEX_COLLAPSE') ) :

class DHZ_ACF_ADMIN_FEX_COLLAPSE {

	public $settings;

	function __construct() {

		// vars
		$this->settings = array(
			'plugin'			=> 'ACF Admin Flexible Content Collapse',
			'this_acf_version'	=> 0,
			'min_acf_pro_version'	=> '5.5.0',
			'max_acf_pro_version'	=> '5.99.0',
			'min_acf_free_version'	=> '5.7.0',
			'version'			=> '1.3.2',
			'url'				=> plugin_dir_url( __FILE__ ),
			'path'				=> plugin_dir_path( __FILE__ ),
			'plugin_path'		=> 'https://wordpress.org/plugins/acf-admin-flexible-content-collapse/'
		);

		// set text domain
		load_plugin_textdomain( 'acf-admin-flex-collapse', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );

		// check for ACF and min version
		add_action( 'admin_init', array($this, 'acf_or_die'), 11);

		// enqueue scripts and styles
		add_action( 'acf/field_group/admin_head', array($this, 'acf_admin_flex_collapse_enqueue'), 11 );

	}

	/**
	 * Let's make sure ACF Pro is installed & activated
	 * If not, we give notice and kill the activation of ACF RGBA Color Picker.
	 * Also works if ACF Pro is deactivated.
	 */
	function acf_or_die() {

		if ( !class_exists('acf') ) {
			$this->kill_plugin();
		} else if ( !acf_get_setting('pro') == 1 && ( !class_exists('acf_plugin_repeater') && !class_exists('acf_plugin_flexible_content') ) ) {
			$this->kill_plugin();
		} else {
			$this->settings['this_acf_version'] = acf()->settings['version'];
			if ( version_compare( $this->settings['this_acf_version'], $this->settings['min_acf_pro_version'], '<' ) ) {
				$this->kill_plugin();
			} else if ( version_compare( $this->settings['this_acf_version'], $this->settings['max_acf_pro_version'], '>' ) ) {
				$this->kill_plugin_is_v6();
			}
		}
	}

	function kill_plugin () {
		deactivate_plugins( plugin_basename( __FILE__ ) );
			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}
		add_action( 'admin_notices', array($this, 'acf_dependent_plugin_notice') );
	}

	function kill_plugin_is_v6 () {
		deactivate_plugins( plugin_basename( __FILE__ ) );
			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}
		add_action( 'admin_notices', array($this, 'acf_bigger_v6_plugin_notice') );
	}

	function acf_dependent_plugin_notice() {
		echo '<div class="error"><p>' . sprintf( __('%1$s requires ACF PRO v%2$s or higher or ACF v%3$s or higher with either the Repeater or Flexible Content plugin to be installed and activated.', 'acf-collapse-fields'), $this->settings['plugin'], $this->settings['min_acf_pro_version'], $this->settings['min_acf_free_version']) . '</p></div>';
	}

	function acf_bigger_v6_plugin_notice() {
		echo '<div class="error"><p>' . __('ACF Admin Flexible Content Collapse does not support ACF PRO v6.0 or higher', 'acf-collapse-fields') . '</p></div>';
	}

	/*
	*  Load the javascript and CSS files on the ACF admin pages
	*/
	function acf_admin_flex_collapse_enqueue() {


		if ( class_exists('acf') ) {

			if ( version_compare( $this->settings['this_acf_version'], $this->settings['min_acf_pro_version'], '>=' ) ||
				!acf_get_setting('pro') == 1 && ( class_exists('acf_plugin_repeater') || class_exists('acf_plugin_flexible_content') )
				) {

				$url = $this->settings['url'];
				$version = $this->settings['version'];

				// Localize the script
				$translation_array = array(
					'reorder'		=> __( 'Reorder Layout', 'acf-admin-flex-collapse' ),
					'delete'		=> __( 'Delete Layout', 'acf-admin-flex-collapse' ),
					'copy'			=> __( 'Duplicate Layout', 'acf-admin-flex-collapse' ),
					'addnew'		=> __( 'Add New Layout', 'acf-admin-flex-collapse' ),
					'toggle'		=> __( 'Click to toggle', 'acf-admin-flex-collapse' ),
					'collapseAll'	=> __( 'Collapse all Layouts', 'acf-admin-flex-collapse' ),
					'expandAll'		=> __( 'Expand all Layouts', 'acf-admin-flex-collapse' )
				);

				if ( version_compare(acf()->settings['version'], '5.7.0', '>=' ) ) {
					wp_register_style (
						'acf_admin_flex_collapse_css',
						"{$url}assets/css/acf-admin-flexible-content-collapse.css",
						false,
						$version
					);
					wp_register_script(
						'acf_admin_flex_collapse_script',
						"{$url}assets/js/acf-admin-flexible-content-collapse.js",
						false,
						$version
					);
				}

				wp_localize_script( 'acf_admin_flex_collapse_script', 'acf_flex_collapse', $translation_array );

				wp_enqueue_style( 'acf_admin_flex_collapse_css' );
				wp_enqueue_script( 'acf_admin_flex_collapse_script' );
			}

		}

	}
}
// initialize
new DHZ_ACF_ADMIN_FEX_COLLAPSE();

// class_exists check
endif;

?>
