<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Deprecated. Moved to /3rd-party/ directory.
 *
 * @package automattic/jetpack
 */

// See 3rd-party/class.jetpack-bbpress-json-api.compat.php.
