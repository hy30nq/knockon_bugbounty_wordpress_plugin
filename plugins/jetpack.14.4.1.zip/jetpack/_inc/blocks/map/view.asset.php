<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'dfc681a21a84794fc490');
