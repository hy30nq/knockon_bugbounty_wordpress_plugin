<?php return array('dependencies' => array(), 'version' => '01d8248d02f84edd7490');
