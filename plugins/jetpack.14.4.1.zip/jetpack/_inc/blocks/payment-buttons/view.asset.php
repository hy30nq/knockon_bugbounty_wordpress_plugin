<?php return array('dependencies' => array(), 'version' => '1fdfa4fe6240a9ab1ba5');
