<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'c8230bb7c29b8fc20084');
