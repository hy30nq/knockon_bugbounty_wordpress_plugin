<?php return array('dependencies' => array(), 'version' => 'f5d909aa24252e5fac84');
