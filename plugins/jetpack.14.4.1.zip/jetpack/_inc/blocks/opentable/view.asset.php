<?php return array('dependencies' => array(), 'version' => '6643e334b11a15caaede');
