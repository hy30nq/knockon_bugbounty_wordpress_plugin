<?php return array('dependencies' => array(), 'version' => 'f138e69f038a6a5048ab');
