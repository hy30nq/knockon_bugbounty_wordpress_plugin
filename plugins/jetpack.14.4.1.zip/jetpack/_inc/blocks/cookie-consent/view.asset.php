<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '62af1bb0e3146219a513');
