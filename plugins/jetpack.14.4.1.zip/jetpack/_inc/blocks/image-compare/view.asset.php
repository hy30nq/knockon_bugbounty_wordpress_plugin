<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '52db62d48c395da47325');
