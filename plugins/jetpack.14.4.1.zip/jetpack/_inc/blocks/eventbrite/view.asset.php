<?php return array('dependencies' => array(), 'version' => 'c5e107f1cd1575a2bcc9');
