<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '88226a8f030758e90dfb');
