<?php return array('dependencies' => array(), 'version' => '015c90376027208061a7');
