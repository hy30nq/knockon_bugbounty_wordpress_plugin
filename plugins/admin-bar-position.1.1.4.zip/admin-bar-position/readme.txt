=== Admin Bar Position  ===
Contributors: kanakogi
Donate link: http://www.amazon.co.jp/registry/wishlist/2TUGZOYJW8T4T/?_encoding=UTF8&camp=247&creative=7399&linkCode=ur2&tag=wpccc-22
Tags: admin, category
Requires at least: 3.0 or higher
Tested up to: 6.2.0
Stable tag: 1.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin can change bottom to "Admin Bar".
It also can change Admin Bar position with "shift + up" or "shift + down".

管理バーの位置を下に表示することが出来ます。
また、「Shift + ↑」「Shift + ↓」で上下に位置を変えることも可能です。

== Installation ==

1. Upload the `adminbar-position` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.0 =
* Initial release
