=== Debug Bar - Enable WP_DEBUG from admin dashboard ===

Tags			 : enable,wp_debug,wp,debug,admin,dashboard, debug bar,
Stable tag		 : 1.93
WordPress URI	 : https://wordpress.org/plugins/enable-wp-debug-from-admin-dashboard/
Plugin URI		 : https://puvox.software/software/wordpress-plugins/?plugin=enable-wp-debug-from-admin-dashboard
Contributors	 : puvoxsoftware,ttodua
Author			 : Puvox.software
Author URI		 : https://puvox.software/
Donate link		 : https://paypal.me/puvox
License			 : GPL-3.0
License URI		 : https://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 6.0
Tested up to	 : 6.5.3

[ ✅ 𝐒𝐄𝐂𝐔𝐑𝐄 𝐏𝐋𝐔𝐆𝐈𝐍𝐒 b𝓎 𝒫𝓊𝓋𝑜𝓍] 
You can easily enable WP_DEBUG using a toolbar button. READ DESCRIPTION!

== Description ==
= [ ✅ 𝐒𝐄𝐂𝐔𝐑𝐄 𝐏𝐋𝐔𝐆𝐈𝐍𝐒 b𝓎 𝒫𝓊𝓋𝑜𝓍] : =
> • Revised for security to be reliable and free of vulnerability holes.
> • Efficient, not to add any extra load/slowness to site.
> • Don't collect private data.
= Plugin Description =
READ DESCRIPTION BEFORE INSTALLING!
Easily enable/disable WP_DEBUG with one single click from Admin Toolbar. What's more, this plugin is failsafe & clever - in case of errors, it automatically exits the WP_DEBUG mode, thus, you won't face any problems.

* Works with `Debug Bar` plugin. 

= NOTE =
Plugin modifies `wp-config.php`. However, on some sites, this might cause some conflict with existing wp-config, causing to interfere the page-load. So, use at your own responsibility. If unsure, use on test site.

= Available Options =
See all available options and their description on plugin's settings page.


== Screenshots ==
1. screenshot


== Installation ==
A) Enter your website "Admin Dashboard > Plugins > Add New" and enter the plugin name
or
B) Download plugin from WordPress.org , Extract the zip file and upload the container folder to "wp-content/plugins/"


== Frequently Asked Questions ==
- More at <a href="https://puvox.software/software/wordpress-plugins/">our WP plugins</a> page.


== Changelog ==
= 1.35 =
* Updates & BugFixes

= 1.0 =
* First release.