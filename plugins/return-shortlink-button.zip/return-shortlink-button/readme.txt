=== Return shortlink button ===
Contributors: CheGevara29
Tags: edit, shortlink, admin, link
Requires at least: 4.4
Tested up to: 6.7.1
Stable tag: 0.3
Donate link: http://chegevara29.ru/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Return "shortlink" button on edit page

== Description ==

Return "shortlink" button on edit page

= Features =
Return "shortlink" button on edit page

== Installation ==

1. Upload `tags-to-meta-keywords` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==
= 0.1 =
* It work
= 0.2 =
* It still work 
= 0.3 =
* Testing with WP 5.7
= 0.4 =
* Testing with WP 5.7.2
= 1.0 =
* Testing with WP 5.9