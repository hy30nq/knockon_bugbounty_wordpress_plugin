<?php
/*
	This function modifies the button list for the DFWM.  We don't use the button array passed by WordPress at all so it's just a throw away variable.
	
	$oldbuttons = the button array passed to us by WordPress.
 */
function JustWriting( $buttons )
	{
	return $buttons;
	}
?>