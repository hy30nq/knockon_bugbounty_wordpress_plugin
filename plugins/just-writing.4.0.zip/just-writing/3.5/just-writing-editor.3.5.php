<?php 

function JustWritingEditorPage()
	{
	}
	
?>