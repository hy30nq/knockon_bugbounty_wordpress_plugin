<?php
/**
 * Loader for the ThemeIsle\ContentForms feature
 *
 * @package     ThemeIsle\ContentForms
 */

require_once __DIR__ . '/form_manager.php';
