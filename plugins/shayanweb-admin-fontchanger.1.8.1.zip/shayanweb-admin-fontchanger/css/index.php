<?php
// Silence is Golden - ShayanWeb.com
