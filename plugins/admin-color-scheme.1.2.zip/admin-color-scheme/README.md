# ACOS

**ACOS** is a WordPress plugin that allows you to change the admin color scheme of your WordPress dashboard with custom colors using color picker.

Download the latest version from the [WordPress Plugin Directory](https://wordpress.org/plugins/admin-color-scheme/).


### Preparing the project

Run ```yarn init``` to install dependencies.

### Building the project

Run ```yarn packit``` to build the project. The project will be available in export folder.

### Disclaimer
Use at your own risk. This plugin is provided as-is, without any warranty or guarantee of its functionality or effectiveness. While we have made every effort to ensure that this plugin is safe and reliable, we cannot be held responsible for any damages or losses caused by its use. Please use this plugin at your own discretion and responsibility.