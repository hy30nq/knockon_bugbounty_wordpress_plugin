# Security

## Reporting Security Issues

**Please do not report security vulnerabilities through public GitHub issues.**

Instead, please report them directly to the plugin author at [security@simple-history.com](mailto:security@simple-history.com]).

