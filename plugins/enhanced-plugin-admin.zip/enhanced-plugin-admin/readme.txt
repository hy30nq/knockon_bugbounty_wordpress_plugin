=== Enhanced Plugin Admin ===
Contributors: Marios Alexandrou
Donate link: https://infolific.com/technology/software-worth-using/enhanced-plugin-admin-for-wordpress/
Tags: plugin info, plugin admin, plugin management
Requires at least: 5.0
Tested up to: 6.7
License: GPLv2 or later

At-a-glance diagnostic and security info displayed on your site's plugin page about the plugins you have installed (both active and inactive).

== Description ==

The Enhanced Plugin Admin plugin aims to save you time and warn you about potential compatibility and security problems for installed plugins right from the plugin admin screen. Information includes:

1. last update date
2. overall rating
3. number of votes
4. WordPress version compatibility range
5. WordPress plugin repository status i.e. in repository, removed from repository, never in repository

You can also hide (disable) individual plugin update notifications for when you don't want to upgrade. These can be unhidden (re-enabled) at any time.

= Planned Features =

These are features I've been considering. Let me know if they're of interest or if you have other ideas.

1. Schedule checks so that information is up to date without having to wait for plugin admin page to refresh.
2. Email notifications when thresholds are first exceeded or when vulnerability discovered.
3. Keep track of when a plugin was originally and most recently activated / deactivated.

== Installation ==

1. Upload the enhanced-plugin-admin folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to your site's plugins page

== Frequently Asked Questions ==

= Can I set thresholds? =

Yes. Check the settings page

= Can I get information about commercial plugins? =

Unfortunately, commercial plugins house their information an their own sites and don't provide this information in a consistent manner.

= I have an idea for an enhancement? =

Feel free to suggest ideas on the support page.

== Screenshots ==

1. Alerts on plugin page shown in red. Line wrapping exaggerated due to screenshot size.
2. Plugin update notification is visible with option to hide it.
3. Plugin update notification is hidden with option to unhide it. Note that notifications elsewhere in interface are hidden too.

== Changelog ==

= 1.17 =
* Security issue (cross-site scripting) fix updated.

= 1.16 =
* Security issue (cross-site scripting) fix applied.

= 1.15 =
* Additional error checking when identifying plugin names.

= 1.14 =
* Removed some debugging info that might break output.

= 1.13 =
* Fixed issue with lookup of plugin against the WordPress SVN repository.

= 1.12 =
* Improved caching of data to speed up the loading of plugin page.

= 1.11 =
* Fixed the check for whether a plugin was ever in the WordPress plugin repository.

= 1.10 =
* Now alerts if current version of WordPress outside of range of what plugin expects.
* Switch from using cURL to the WordPress HTTP API.

= 1.9.3 =
* Can now force data refresh by setting refresh rate to 0.

= 1.9.2 =
* Bug fix for svn check.

= 1.9.1 =
* Performance improvements for how info related to plugins removed from WP repository is gathered.

= 1.9 =
* Added the ability to disable individual plugin update notifications.
* Reworked plugin info to make it easier to read.

= 1.8 =
* Syncing version numbers.

= 1.7 =
* Show WordPress version compatibility range.
* Show if plugin is in WP repository, was REMOVED from WP repository, or was never in WP repository
* Tweaks to documentation including the readme.txt.

= 1.6 =
* User can now specify last update threshold, rating threshold, alert styling, and refresh rate.
* Change default alert formatting so it's more visible.

= 1.5 =
* Bug fixed with how date differences are determined. Thanks to Li-An.

= 1.4 =
* Additional security to prevent direct access of plugin file.

= 1.3 =
* Improved logic for determining when to include supporting WordPress core files.

= 1.2 =
* Removed unnecessary declarations that were preventing the View Details links from working.

= 1.1 =
* Data from WordPress plugin API now cached with transients that will expire after 24 hours. This speeds up repeated views of the plugin admin page.

= 1.0 =
* Initial release.
