<?php
/*
Plugin Name: Enhanced Plugin Admin
Version: 1.17
Plugin URI: http://infolific.com/technology/software-worth-using/enhanced-plugin-admin/
Description: At-a-glance info (last update date, rating, votes, compatibility, repository status) on your site's plugin page about the plugins you have installed (both active and inactive). Easily spot potential problems due to plugins no longer being supported or that have received low ratings. Can also hide/unhide plugin update notifications.
Author: Marios Alexandrou
Author URI: http://infolific.com/technology/
License: GPLv2 or later
Text Domain: enhanced-plugin-admin
*/

/*
Copyright 2015 Marios Alexandrou

Some functionality and code inspired by Plugin Update Hider by Jason Newman that was once housed in the WordPress Plugin Repository.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

//Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( FALSE !== strpos( $_SERVER['PHP_SELF'], '/wp-admin/plugins.php') ) {
	if ( ! function_exists( 'plugins_api' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/plugin-install.php' );
	}
}

define('epa_pn_loaded', 1);

add_filter( 'plugin_row_meta', 'epa_plugin_meta', 10, 2 );
add_filter( 'site_transient_update_plugins', 'epa_pn_hide_update_notifications' );

add_action( 'admin_menu', 'epa_add_pages' );
add_action( 'init','epa_pn_get' );
add_action( 'init','epa_pn_add_filters' );

//if ( ! function_exists( 'get_plugins' ) ) {
//	require_once ABSPATH . 'wp-admin/includes/plugin.php';
//}

/**
 * Calculate the difference in months between two dates (v1 / 18.11.2013)
 *
 * @param \DateTime $date1
 * @param \DateTime $date2
 * @return int
 */
function epa_diff_in_months( DateTime $date1, DateTime $date2 ) {
    $diff =  $date1->diff($date2);
    $months = $diff->y * 12 + $diff->m + $diff->d / 30.416;
    return (int) round($months);
}

function epa_plugin_meta( $links, $file ) { // add some links to plugin meta row

	if ( strpos( $file, 'enhanced-plugin-admin.php' ) !== false ) {
		$links = array_merge( $links, array( '<a href="' . esc_url( get_admin_url(null, 'options-general.php?page=enhanced-plugin-admin') ) . '">Settings</a>' ) );
	}

	if ( FALSE !== strpos( $_SERVER['PHP_SELF'], '/wp-admin/plugins.php') ) {
		$file_parts = explode( '/', $file );

		if ( count( $file_parts ) > 1 ) {
			$file = $file_parts[0];
		} else {
			echo "<!-- epa: can't explode file " . $file . " -->";
			$file = str_replace( '.php', '', $file );
		}

//		$file = str_replace( '.php', '', $file );
//		$file = basename( $file, '.php');
//		echo '<!-- epa current file is: ' . $file . ' -->';
		$links = array_merge( $links, array( epa_get_plugin_info($file) ) );
	}

	return $links;
}

function epa_get_plugin_info( $file ) {

	$epa_settings = get_option( 'epa_plugin_settings' );

	if( isset( $epa_settings['epa_rating_threshold'] ) ) {
		$epa_rating_threshold = $epa_settings['epa_rating_threshold'];
	} else {
		$epa_rating_threshold = 75;
	}

	if( isset( $epa_settings['epa_last_update_threshold'] ) ) {
		$epa_last_update_threshold = $epa_settings['epa_last_update_threshold'];
	} else {
		$epa_last_update_threshold = 24;
	}

	if( isset( $epa_settings['epa_refresh_rate'] ) ) {
		$epa_refresh_rate = $epa_settings['epa_refresh_rate'];
	} else {
		$epa_refresh_rate = 24;
	}

	if( isset( $epa_settings['epa_alert_html_start'] ) && strlen( trim ( $epa_settings['epa_alert_html_start'] ) ) > 0 ) {
		$epa_alert_html_start = stripslashes( $epa_settings['epa_alert_html_start'] );
	} else {
		$epa_alert_html_start = "<span style='background: red; color: white; font-weight: bold;'>&nbsp;";
	}

	if( isset( $epa_settings['epa_alert_html_end'] ) && strlen( trim ( $epa_settings['epa_alert_html_end'] ) ) > 0 ) {
		$epa_alert_html_end = stripslashes( $epa_settings['epa_alert_html_end'] );
	} else {
		$epa_alert_html_end = "&nbsp;</span>";
	}
	
	//Refresh rate is 0 so clear transients to force data refresh
	if ( 0 == $epa_refresh_rate ) {
		delete_transient( 'epa_' . $file );
		delete_transient( 'epa_' . $file . '_in_wp_plugin_svn' );
		//After clearing transient, set refresh rate to 1 day so that new transients aren't set to 0 (never expire)
		$epa_refresh_rate = 24;
	}
	
	if ( false === ( $call_api = get_transient( 'epa_' . $file ) ) ) {
		$call_api = plugins_api( 'plugin_information', array( 'slug' => $file ) );
		set_transient( 'epa_' . $file, $call_api, $epa_refresh_rate * HOUR_IN_SECONDS );
		echo "<!-- epa: data from call_api -->";
	} else {
		echo "<!-- epa: data from transient -->";
	}
	
	if ( is_wp_error( $call_api ) ) {
		echo "<!-- epa: call_api error ";
		//print_r ( $call_api->get_error_messages() );
		echo " -->";
		$elapsed_months = 'n/a';
		$rating = '0';
		$num_ratings = '0';
		$wp_version_min = 'n/a';
		$wp_version_max = 'n/a';
		$in_wp_plugin_repo = false;
		
		if ( false === ( $in_wp_plugin_svn = get_transient( 'epa_' . $file . '_in_wp_plugin_svn' ) ) ) {
			echo "<!-- epa: checking svn url a -->";
			if (check_wp_plugin_svn ( $file ) ) {
				echo "<!-- epa: in plugin svn a -->";
				$in_wp_plugin_svn = true;
			} else {
				echo "<!-- epa: not in plugin svn a -->";
				$in_wp_plugin_svn = false;
			}
			set_transient( 'epa_' . $file . '_in_wp_plugin_svn', $in_wp_plugin_svn, $epa_refresh_rate * HOUR_IN_SECONDS );
		}
		
	} else {
		//print_r($call_api) ;
		
		echo "<!-- epa: call_api successful -->";
		if ( !empty( $call_api->last_updated ) ) {
			$last_updated = new DateTime( $call_api->last_updated );
			$current_date = new DateTime();

			$elapsed_months = epa_diff_in_months( $current_date, $last_updated );

			if ( $elapsed_months > $epa_last_update_threshold ) {
				if ( $elapsed_months == 1) {
					$elapsed_months = $epa_alert_html_start . $elapsed_months . " month ago" . $epa_alert_html_end;
				} else {
					$elapsed_months = $epa_alert_html_start . $elapsed_months . " months ago" . $epa_alert_html_end;
				}
			} else {
				if ( $elapsed_months == 1) {
					$elapsed_months = $elapsed_months . " month ago";				
				} else {
					$elapsed_months = $elapsed_months . " months ago";				
				}
			}

		} else {
			$elapsed_months = 'n/a';
		}

		if ( !empty( $call_api->rating ) ) {
			$rating = $call_api->rating;
			if ( $rating < $epa_rating_threshold ) {
				$rating = $epa_alert_html_start . $rating . $epa_alert_html_end;
			}
		} else {
			$rating = 0;
		}

		if ( !empty( $call_api->num_ratings ) ) {
			$num_ratings = $call_api->num_ratings;
		} else {
			$num_ratings = 0;
		}

		if ( !empty( $call_api->requires ) ) {
			$wp_version_min = $call_api->requires;
		} else {
			$wp_version_min = 'n/a';
		}

		if ( !empty( $call_api->tested ) ) {
			$wp_version_max = $call_api->tested;
		} else {
			$wp_version_max = 'n/a';
		}

		if ( !empty( $call_api->requires ) && !empty( $call_api->tested ) ) {

			$wp_version_current = get_bloginfo('version');
			
			//Min version greater than current WP version
			if ( version_compare( $wp_version_current, $wp_version_min ) == -1 ) {
				$wp_version_min = $epa_alert_html_start . $wp_version_min . $epa_alert_html_end;
			}

			//Max version less than current WP version
			if ( version_compare( $wp_version_current, $wp_version_max ) == 1 ) {
				$wp_version_max = $epa_alert_html_start . $wp_version_max . $epa_alert_html_end;
			}
		}

		if ( false === ( $in_wp_plugin_svn = get_transient( 'epa_' . $file . '_in_wp_plugin_svn' ) ) ) {
			echo "<!-- epa: checking svn url b -->";
			if (check_wp_plugin_svn ( $file ) ) {
				echo "<!-- epa: in plugin svn b -->";
				$in_wp_plugin_svn = true;
			} else {
				echo "<!-- epa: not in plugin svn b -->";
				$in_wp_plugin_svn = false;
			}
			set_transient( 'epa_' . $file . '_in_wp_plugin_svn', $in_wp_plugin_svn, $epa_refresh_rate * HOUR_IN_SECONDS );
		}
		
		if ($in_wp_plugin_svn) {
			echo "<!-- epa: in plugin repo -->";
			$in_wp_plugin_repo = true;
		} else {
			echo "<!-- epa: not in plugin repo -->";
			$in_wp_plugin_repo = false;
		}
		
	}

	if ( $in_wp_plugin_repo ) {
		$wp_plugin_repo_status = 'Currently in WP repo.';

		$epa_plugin_output = '<br/>' . 
		'Last updated ' . $elapsed_months . '. ' .
		'Has a rating of ' . $rating . '/100 with ' . $num_ratings . ' votes. ' .
		'Expects WP version ' . $wp_version_min . ' to ' . $wp_version_max . '. ' .
		$wp_plugin_repo_status;

	} else if ( !$in_wp_plugin_repo && $in_wp_plugin_svn ) {
		$wp_plugin_repo_status = $epa_alert_html_start . 'Removed from WP repo.' . $epa_alert_html_end;

		$epa_plugin_output = '<br/>' . 
		$wp_plugin_repo_status;		
		
	} else if ( !$in_wp_plugin_svn ) {
		$wp_plugin_repo_status = 'Was never in WP repo.';

		$epa_plugin_output = '<br/>' . 
		$wp_plugin_repo_status;
	}
	
	return( $epa_plugin_output );
}

function check_wp_plugin_svn($file) {
	$args = array(
		'timeout'     => 5,
		'redirection' => 5,
		'httpversion' => '1.0',
		'user-agent'  => 'WordPress Enhanced Plugin Admin',
		'blocking'    => true,
		'headers'     => array(),
		'cookies'     => array(),
		'body'        => null,
		'compress'    => false,
		'decompress'  => true,
		'sslverify'   => true,
		'stream'      => false,
		'filename'    => null
	);	
	
	//Example URL http://svn.wp-plugins.org/wordpress-seo/ of the following
	$response = wp_remote_get( "http://svn.wp-plugins.org/" . $file . "/", $args );

	if( is_wp_error( $response ) ) {
		echo "<!-- epa: svn response error messages ";
		//print_r ( $call_api->get_error_messages() );
		echo " -->";
		return false;
	} else {
		$response_code = wp_remote_retrieve_response_code( $response );
		echo "<!-- epa: svn response code " . $response_code . " -->";
		if( '200' == $response_code ) {
			return true;
		} else {
			echo "<!-- epa: svn response error code response messages ";
			//print_r ( $call_api->get_error_messages() );
			echo " -->";
			return false;
		}
	}
}

/*
* Add a submenu under Tools
*/
function epa_add_pages() {
	$page = add_submenu_page( 'options-general.php', 'Enhanced Plugin Admin', 'Enhanced Plugin Admin', 'activate_plugins', 'enhanced-plugin-admin', 'epa_options_page' );
	add_action( "admin_print_scripts-$page", "epa_admin_scripts" );
}

/*
* Scripts needed for the admin side
*/
function epa_admin_scripts() {
	wp_enqueue_style( 'epa_styles', plugins_url() . '/enhanced-plugin-admin/css/epa.css' );
}

function epa_options_page() {
	if ( isset($_POST['form_nonce']) && wp_verify_nonce($_POST['form_nonce'],'epa_nonce') && isset( $_POST['setup-update'] ) ) {	
		unset( $_POST['setup-update'] );
		update_option( 'epa_plugin_settings', $_POST );
		echo '<div id="message" class="updated fade">';
			echo '<p><strong>Options Updated</strong></p>';
		echo '</div>';
	}
?>
<div class="wrap" style="padding-bottom: 5em;">
	<h2>Enhanced Plugin Admin</h2>
	<p>Set the thresholds and styling here. Clearing a field will reset the value to the defaults.
	<div id="epa-items">

		<form method="post" action="<?php echo esc_url( $_SERVER["REQUEST_URI"] ); ?>">
			<ul id="epa_itemlist">
				<li>
				<?php
				$epa_settings = get_option( 'epa_plugin_settings' );

				if( isset( $epa_settings['epa_rating_threshold'] ) && strlen( trim ( $epa_settings['epa_rating_threshold'] ) ) > 0 ) {
					$epa_rating_threshold = $epa_settings['epa_rating_threshold'];
				} else {
					$epa_rating_threshold = '75';
				}

				if( isset( $epa_settings['epa_last_update_threshold'] ) && strlen( trim ( $epa_settings['epa_last_update_threshold'] ) ) > 0 ) {
					$epa_last_update_threshold = $epa_settings['epa_last_update_threshold'];
				} else {
					$epa_last_update_threshold = '24';
				}

				if( isset( $epa_settings['epa_refresh_rate'] ) && strlen( trim ( $epa_settings['epa_refresh_rate'] ) ) > 0 ) {
					$epa_refresh_rate = $epa_settings['epa_refresh_rate'];
				} else {
					$epa_refresh_rate = '24';
				}

				if( isset( $epa_settings['epa_alert_html_start'] ) && strlen( trim ( $epa_settings['epa_alert_html_start'] ) ) > 0 ) {
					$epa_alert_html_start = stripslashes( $epa_settings['epa_alert_html_start'] );
				} else {
					$epa_alert_html_start = '<span style="background: red; color: white; font-weight: bold;">&nbsp;';
				}

				if( isset( $epa_settings['epa_alert_html_end'] ) && strlen( trim ( $epa_settings['epa_alert_html_end'] ) ) > 0 ) {
					$epa_alert_html_end = stripslashes( $epa_settings['epa_alert_html_end'] );
				} else {
					$epa_alert_html_end = "&nbsp;</span>";
				}
				
				echo "<div>";
					echo "<label class='side-label' for='epa_last_update_threshold'>Last Update Threshold (months):</label>";
					echo "<input class='textbox' type='text' name='epa_last_update_threshold' id='epa_last_update_threshold' value='$epa_last_update_threshold' />";
					echo "<br />";

					echo "<label class='side-label' for='epa_rating_threshold'>Rating Threshold (out of 100)</label>";
					echo "<input class='textbox' type='text' name='epa_rating_threshold' id='epa_rating_threshold' value='$epa_rating_threshold' />";
					echo "<br />";

					echo "<label class='side-label' for='epa_refresh_rate'>Alert Styling Start:</label>";
					echo "<input class='textbox-long' type='text' name='epa_alert_html_start' id='epa_alert_html_start' value='" . htmlentities( $epa_alert_html_start ) . "' />";
					echo "<br />";

					echo "<label class='side-label' for='epa_refresh_rate'>Alert Styling End:</label>";
					echo "<input class='textbox-long' type='text' name='epa_alert_html_end' id='epa_alert_html_end' value='" . htmlentities( $epa_alert_html_end ) . "'/>";
					echo "<br />";

					echo "<label class='side-label' for='epa_refresh_rate'>Refresh Rate (hours):</label>";
					echo "<input class='textbox' type='text' name='epa_refresh_rate' id='epa_refresh_rate' value='$epa_refresh_rate' />";
					echo "<br />";

				echo "</div>";
				?>
				</li>
			</ul>
			<div id="divTxt"></div>
		    <div class="clearpad"></div>
			<input type="submit" class="button left" value="Update Settings" />
			<input type="hidden" name="setup-update" />
			<input name="form_nonce" type="hidden" value="<?=wp_create_nonce('epa_nonce')?>" />
		</form>
	</div>

	<div id="epa-sb">
		<div class="postbox" id="epa-sbone">
			<h3 class='hndle'><span>Documentation</span></h3>
			<div class="inside">
				<strong>Instructions</strong>
				<p>This plugin adds additional info about your installed plugins.</p>
				<ol>
					<li>Last Update Threshold: A plugin that hasn't been updated in this many months will be highlighted.</li>
					<li>Rating Threshold: A plugin with a rating lower than this value will be highlighted.</li>
					<li>Alert Styling: When a threshold is not met, a plugin will be highlighted using this HTML code.</li>
					<li>Refresh Rate: Controls how often data is retrieved from WordPress for each plugin. Set to 0 if you want fresh data all of the time (may be slow).</li>
				</ol>
			</div>
		</div>
		<div class="postbox"  id="epa-sbtwo">
			<h3 class='hndle'><span>Support</span></h3>
			<div class="inside">
				<p>Your best bet is to post on the <a href="https://wordpress.org/support/plugin/enhanced-plugin-admin">plugin support page</a> for the pro version.</p>
				<p>Please consider supporting me by <a href="https://wordpress.org/support/view/enhanced-plugin-admin">rating this plugin</a>. Thanks!</p>
			</div>
		</div>
		<div class="postbox" id="epa-sbthree">
			<h3 class='hndle'><span>Other Plugins</span></h3>
			<div class="inside">
				<ul>
					<li><a href="https://wordpress.org/plugins/real-time-find-and-replace/">Real-Time Find and Replace</a>: Set up find and replace rules that are executed AFTER a page is generated by WordPress, but BEFORE it is sent to a user's browser.</li>
					<li><a href="https://wordpress.org/plugins/republish-old-posts/">Republish Old Posts</a>: Republish old posts automatically by resetting the date to the current date. Puts your evergreen posts back in front of your users.</li>
					<li><a href="https://wordpress.org/extend/plugins/rss-includes-pages/">RSS Includes Pages</a>: Modifies RSS feeds so that they include pages and not just posts. My most popular plugin!</li>
					<li><a href="https://wordpress.org/extend/plugins/add-any-extension-to-pages/">Add Any Extention to Pages</a>: Add any extension of your choosing (e.g. .html, .htm, .jsp, .aspx, .cfm) to WordPress pages.</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php } 

/* START - Enable and Disabled Plugin Notifications */

if( defined( 'epa_pn_loaded' ) ) {
	return;
}

function epa_pn_add_filters() {
	if( !current_user_can( 'update_plugins' ) ) {
		return;
	}

	$plugins = get_site_transient( 'update_plugins' );
	$to_hide = get_option( 'epa_pn_hidden' );

	if( isset( $plugins->response ) ) {
		// loop through all of the plugins with updates available and attach the appropriate filter
		foreach( $plugins->response as $filename => $plugin ) {
			// check that the version is the version we want to hide updates to
			$s = 'after_plugin_row_' . $filename;
			//in_plugin_update_message-
			add_action( $s, 'epa_pn_hide_link', -1, 1 );
		}
	}

	if( isset( $plugins->epa_pn ) ) {
		foreach( $plugins->epa_pn as $filename => $plugin ) {
			// check that the version is the version we want to hide updates to
			$s = 'after_plugin_row_' . $filename;
			add_action( $s, 'epa_pn_unhide_link', 2, 1 );
		}
	}
}

function epa_pn_get() {

	if( !current_user_can( 'update_plugins' ) ) {
		return;
	}

	// see if there are actions to process
	if( !isset($_GET['epa_pn'] ) || !isset( $_GET['_wpnonce'] ) ) {
		return;
	}

	if( !wp_verify_nonce( $_GET['_wpnonce'], 'epa_pn' ) ) {
		return;
	}

	$hidden = get_option( 'epa_pn_hidden' );
	$plugins = get_site_transient( 'update_plugins' );

	// hide action
	if( isset( $_GET['hide'] ) && isset( $plugins->response ) && isset( $plugins->response[$_GET['hide']] ) ) {
		$p = $plugins->response[$_GET['hide']];
		$hidden[$_GET['hide']] = array( 'slug' => $p->slug, 'new_version' => $p->new_version );
	}

	if( isset( $_GET['unhide'] ) ) {
		unset( $hidden[$_GET['unhide']] );
	}

	update_option( 'epa_pn_hidden', $hidden );
}

function epa_pn_hide_update_notifications( $plugins ) {
	if( !isset($plugins->response ) || count( $plugins->response ) == 0 ) {
		return $plugins;
	}

	$to_hide = (array)get_option( 'epa_pn_hidden' );

	foreach( $to_hide as $filename => $plugin ) {
		if( isset( $plugins->response[$filename] ) && $plugins->response[$filename]->new_version == $plugin['new_version'] ) {
			$plugins->epa_pn[$filename] = $plugins->response[$filename];
			unset( $plugins->response[$filename] );
		}
	}
	return $plugins;
}

function epa_pn_unhide_link($filename) {
	epa_pn_link_start();
	echo 'This plugin\'s update notifications are hidden. <a href="plugins.php?_wpnonce=' . wp_create_nonce( 'epa_pn' ) . '&epa_pn&unhide=' . $filename . '">Unhide Now</a>.</div></td></tr>';
}

function epa_pn_hide_link($filename) {
	epa_pn_link_start();
	echo ' <a href="plugins.php?_wpnonce=' . wp_create_nonce( 'epa_pn' ) . '&epa_pn&hide=' . $filename . '">Hide this plugin\'s update notifications</a>.</div></td></tr>';
}

function epa_pn_link_start() {
	$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );
	echo '<tr class="plugin-update-tr"><td colspan="' . $wp_list_table->get_column_count() . '" class="plugin-update colspanchange"><div class="update-message">';
}

/* END - Enable and Disabled Plugin Notifications */
?>