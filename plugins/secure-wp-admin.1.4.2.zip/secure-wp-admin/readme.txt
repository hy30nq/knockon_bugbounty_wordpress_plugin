=== Secure WP Admin ===
Contributors: wpexpertsio, saadiqbal
Tags: Site security , Secure admin, Secure WP Admin
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=pay@objects.ws&item_name=Donation For Plugin
Requires at least: 4.0
Tested up to: 6.6
Stable tag: 1.4.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Want to lock your WP-admin login screen with some PIN to make it more secure? Then this is the right plugin.

== Description ==
Want to lock your WP-admin login screen with some PIN to make it more secure? Then this is the right plugin. Using Secure WP Admin you can lock your wp-admin login form with a seceret PIN just to make it little more secure.

= Features: =
- Set password to protect your wp-admin login screen.
- Set your own logo or use default logo.
- Change placeholder text for Secure WP Admin login form.
- Change Submit button label for Secure WP Admin's login form.
- Change Error text for Secure WP Admin's login form.

= Docs & Support =

Will be available soon.

**If you are looking for WordPress Securtiy Maintenace, use our Free WP SECURE MAINTENANCE plugin.**
[WP SECURE MAINTENANCE](https://wordpress.org/plugins/wp-secure-maintainance/)

**Interested in contributing to Secure WP Admin?**	
Head over to the [Secure WP Admin **GitHub Repository**](https://github.com/wpexpertsio/Secure-WP-Admin) to find out how you can pitch in ;)

== Installation ==
1. Go to Plugins > Add New.
2. Under Search, type Secure WP Admin
3. Find Secure WP Admin and click Install Now to install it
2. If successful, click Activate Plugin to activate it and you  are ready to go.

== Frequently Asked Questions ==

= How to Use Secure WP Admin =
Just after activting set password from Secure WP Admin Settings tab and enable it and you are done.

== Screenshots ==
1. Screenshot of Secure WP Admin Settings.
2. Screenshot of Secure WP Admin's form asking for PIN.


== Changelog ==

= 1.4.2 =
- Tested up to WordPress v6.6.x
- Transfer plugin ownership

= 1.4.1 =
- Added compatibility with WordPress 5.0.3

= 1.4 =
- Added compatibility with 4.9.2

= 1.2 =
* Add Carbon Fields.
= 1.1.2 =
* Fixed backend issues

= 1.0 =
* Initial release
== Upgrade Notice ==
Always try to keep your plugin update so that you can get the improved and additional features added to this plugin till the moment.