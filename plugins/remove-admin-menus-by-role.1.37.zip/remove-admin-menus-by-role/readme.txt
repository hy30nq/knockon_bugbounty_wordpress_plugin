=== Remove admin menus by role ===
Contributors: manu225
Donate link: http://www.info-d-74.com
Tags: remove, menu, hide, role, admin
Requires at least: 3.5
Tested up to: 6.6
Stable tag: 1.37
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Select easily which admin menus to remove for which roles.

== Description ==

Select easily which admin menus to remove for which roles.
A Pro version with more options is available: [https://www.info-d-74.com/en/produit/remove-admin-menus-by-role-pro-plugin-wordpress-2/](https://www.info-d-74.com/en/produit/remove-admin-menus-by-role-pro-plugin-wordpress-2/)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to the Remove admin menus by role

== Frequently Asked Questions ==

== Screenshots ==

assets/screenshot-1.png

== Changelog ==